/**
 * @(#)LinkedListDriver.java
 *
 *
 * @author 
 * @version 1.00 2017/10/12
 */


public class LinkedListDriver {

    public LinkedListDriver() {
    }
    
    public static boolean checkIfCircularSettingIsCorrectAfterRemove(myLinkedList<?> list)
    {
    	System.out.println("isCircular = " + list.isCircular());
    	System.out.println("isMultilinked = " + list.isMultilinked());
    	System.out.println("head.next.previous = " + list.getNode(0).getPrevious());
    	System.out.println("tail.next = " + list.getTail().getNext());
    	System.out.println("tail.next.next = " + list.getTail().getNext().getNext());
    	if (list.isCircular())
    	{
    		if (list.isMultilinked())
    		{
	    		if ((list.getNode(0).getPrevious() == list.getTail().getNext()) &&
	    			(list.getTail().getNext().getNext() == list.getNode(0)))
	    		{
	    			return true;
	    		}
	    		else return false;
    		}
    		else
    		{
    			if (list.getTail().getNext().getNext() == list.getNode(0))
	    		{
	    			return true;
	    		}
	    		else return false;
    		}
    	}
    	else
    	{
    		if (list.isMultilinked())
    		{
	    		if (list.getTail().getNext().getNext() == null && list.getNode(0).getPrevious() == null)
	    		{
	    			return true;
	    		}
	    		else return false;
    		}
    		else
    		{
    			if (list.getTail().getNext().getNext() == null)
	    		{
	    			return true;
	    		}
	    		else return false;
    		}
    	}
    }
    
    public static boolean doTheListsHaveTheSameData(myLinkedList<?> list1,
    	myLinkedList<?> list2, boolean checkPropertiesAlso)
    {
    	if (list1.size() != list2.size()) return false;
    	if (checkPropertiesAlso == true && (list1.isCircular() != list2.isCircular() ||
    		list1.isMultilinked() != list2.isMultilinked())) return false;
    	else
    	{
    		Node current1 = null;
    		Node current2 = null;
    		for (int i = 0; i < list1.size(); i++)
    		{
    			if (i == 0)
    			{
    				current1 = list1.getNode(0);
    				current2 = list2.getNode(0);
    			}
    			else
    			{
    				current1 = current1.getNext();
    				current2 = current2.getNext();
    			}
    			
    			if (((Object)(current1.getData())).equals((Object)(current2.getData())));//do nothing
    			else return false;
    		}//end of i for loop
    		return true;
    	}
    }
    public static boolean doTheListsHaveTheSameData(myLinkedList<?> list1,
    	myLinkedList<?> list2)
    {
    	return doTheListsHaveTheSameData(list1, list2, false);
    }
    
    public static void main(String[] args)
    {
    	//test the program by having it just be null
    	//only one element
    	//and at least three elements
    	//then print out all elements in the list forwards, backwards, and evenly numbered
    	
    	int failingCount = 0;
    	int passingCount = 0;
    	
    	final int numTotalTests = 46;
    	boolean[] testResults = new boolean[numTotalTests];
    	for (int i = 0; i < numTotalTests; i++) testResults[i] = false;//initialization code
    	
    	//i = 0
    	System.out.println("Test 1: Printing an empty list:");
    	myLinkedList<Integer> m0 = new myLinkedList();//test case 1
    	m0.printList(true, 0);//true forwards, 0 all, 1 only odd, or 2 only even
    	testResults[failingCount + passingCount] = (m0.size() == 0);
    	if (m0.size() == 0)
    	{
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	System.out.println();
    	
    	//i = 1
    	//by the way grey code order of cases for Test 2 unless I change it
    	System.out.println("Test 2: Testing add() and get and set data methods: CASE 01");
    	myLinkedList<Integer> m1 = new myLinkedList();//test case 2
    	m1.setCircular(false);
    	//multilinked is true, circular false by default
    	Node<Integer> n = new Node();
    	//n.setData(0);
    	//m1.add(0, n);//works
    	//m1.add(4, n);//does not work
    	m1.add();
    	m1.getHead().getNext().setData(3);//works when they don't equal null
    	//m1.getNode(0).setData(3);//works when they don't equal null
    	//m1.add(n);
    	//Node n1 = null;
    	//m1.add(n1);//does not work
    	m1.printList(true, 0);//forwards
    	if (m1.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m1))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 2
    	System.out.println("Test 2: Testing add() and get and set data methods: CASE 00");
    	myLinkedList<Integer> m8 = new myLinkedList();//test case 2
    	m8.setCircular(false);
    	m8.setMultilinked(false);
    	n = new Node();
    	m8.add();
    	m8.getHead().getNext().setData(3);//works when they don't equal null
    	m8.printList(true, 0);//forwards
    	if (m8.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m8))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 3
    	System.out.println("Test 2: Testing add() and get and set data methods: CASE 10");
    	myLinkedList<Integer> m9 = new myLinkedList();//test case 2
    	m9.setCircular(true);
    	m9.setMultilinked(false);
    	n = new Node();
    	m9.add();
    	m9.getHead().getNext().setData(3);//works when they don't equal null
    	m9.printList(true, 0);//forwards
    	if (m9.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m9))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 4
    	System.out.println("Test 2: Testing add() and get and set data methods: CASE 11");
    	myLinkedList<Integer> m10 = new myLinkedList();//test case 2
    	m10.setCircular(true);
    	m10.setMultilinked(true);
    	n = new Node();
    	m10.add();
    	m10.getHead().getNext().setData(3);//works when they don't equal null
    	m10.printList(true, 0);//forwards
    	if (m10.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m10))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 5
    	//testing add(Node<T> n) method here
    	System.out.println("Test 2: Testing add(Node<T> n) and get and set data methods: CASE 01");
    	myLinkedList<Integer> m11 = new myLinkedList();//test case 2
    	m11.setCircular(false);
    	//multilinked is true, circular false by default
    	n = new Node(3);
    	m11.add(n);
    	m11.printList(true, 0);//forwards
    	if (m11.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m11))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 6
    	System.out.println("Test 2: Testing add(Node<T> n) and get and set data methods: CASE 00");
    	myLinkedList<Integer> m12 = new myLinkedList();//test case 2
    	m12.setCircular(false);
    	m12.setMultilinked(false);
    	m12.add(new Node(3));
    	m12.printList(true, 0);//forwards
    	if (m12.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m12))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 7
    	System.out.println("Test 2: Testing add(Node<T> n) and get and set data methods: CASE 10");
    	myLinkedList<Integer> m13 = new myLinkedList();//test case 2
    	m13.setCircular(true);
    	m13.setMultilinked(false);
    	m13.add(new Node(3));
    	m13.printList(true, 0);//forwards
    	if (m13.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m13))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 8
    	System.out.println("Test 2: Testing add(Node<T> n) and get and set data methods: CASE 11");
    	myLinkedList<Integer> m14 = new myLinkedList();//test case 2
    	m14.setCircular(true);
    	m14.setMultilinked(true);
    	m14.add(new Node(3));
    	m14.printList(true, 0);//forwards
    	if (m14.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m14))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 9
    	//testing add(int index, Node<T> element)
    	System.out.println("Test 2: Testing add(int index, Node<T> element) and get and set data methods: CASE 01");
    	myLinkedList<Integer> m15 = new myLinkedList();//test case 2
    	m15.setCircular(false);
    	//multilinked is true, circular false by default
    	m15.add(0, new Node(3));
    	m15.getHead().getNext().setData(3);//works when they don't equal null
    	m15.printList(true, 0);//forwards
    	if (m15.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m15))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 10
    	System.out.println("Test 2: Testing add(int index, Node<T> element) and get and set data methods: CASE 00");
    	myLinkedList<Integer> m16 = new myLinkedList();//test case 2
    	m16.setCircular(false);
    	m16.setMultilinked(false);
    	m16.add(0, new Node(3));
    	m16.printList(true, 0);//forwards
    	if (m16.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m16))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 11
    	System.out.println("Test 2: Testing add(int index, Node<T> element) and get and set data methods: CASE 10");
    	myLinkedList<Integer> m17 = new myLinkedList();//test case 2
    	m17.setCircular(true);
    	m17.setMultilinked(false);
    	m17.add(0, new Node(3));
    	m17.printList(true, 0);//forwards
    	if (m17.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m17))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 12
    	System.out.println("Test 2: Testing add(int index, Node<T> element) and get and set data methods: CASE 11");
    	myLinkedList<Integer> m18 = new myLinkedList();//test case 2
    	m18.setCircular(true);
    	m18.setMultilinked(true);
    	m18.add(0, new Node(3));
    	m18.printList(true, 0);//forwards
    	if (m18.getHead().getNext().getData() == 3 && checkIfCircularSettingIsCorrectAfterRemove(m18))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	//test 2 is: 0 through 12
    	
    	System.out.println("Test 3: Tests Node Constructors, and setting the data of a Node");
    	myLinkedList<Integer> m2 = new myLinkedList();//test case 3
    	m2.setCircular(false);
    	m2.setMultilinked(false);
    	n = new Node();
    	n.setData(5);
    	m2.add(n);
    	n = new Node(6);
    	m2.add(n);
    	m2.add(new Node(8));
    	m2.printList(true, 0);
    	System.out.println("Test Past!");
    	
    	
    	//i = 13
    	System.out.println("Test 4: GetNode(index) method, setting data, and inserting objects at the beginning");
    	myLinkedList<Integer> m3 = new myLinkedList();//test case 3
    	m3.setCircular(false);
    	m3.setMultilinked(false);
    	int secondElement = 4;
    	m3.add(new Node(secondElement));
    	m3.add();
    	int ThreeOfNum = 5;
    	m3.getNode(1).setData(ThreeOfNum);
    	n = new Node();
    	n.setData(ThreeOfNum);
    	m3.add(n);
    	m3.add(new Node(ThreeOfNum));
    	n = new Node(6);
    	m3.add(n);
    	m3.add(new Node(8));
    	int secondToLastElement = 9;
    	m3.add(new Node(secondToLastElement));
    	int lastElement = 10;
    	m3.add(new Node(lastElement));
    	System.out.println("Test 4 Original List:");
    	m3.printList(true, 0);
    	int newFirstNum = 3; 
    	n = new Node(newFirstNum);
    	m3.add(0, n);
    	System.out.println("Test 4 After Insertion of " + newFirstNum + " to the beginning of the list:");
    	m3.printList(true, 0);
    	n = new Node(7);
    	m3.add(6, n);
    	System.out.println("Test 4 After Inserting 7 into the middle of the list:");
    	m3.printList(true, 0);
    	System.out.println("The ORIGINAL list should look like this: 3,4,5,5,5,6,7,8,9,10");
    	
    	//create a copy of the list but first change the properties like: circular and multiplylinked or not
    	//create a normal copy constructor in the linkedlist class, then one that takes in the properties
    	//if multiply linked to singularly linked set every previous node value to null (moving forward in the list)
    	//if not circular, remove the previous node value that points to tail and remove
    	//the next of tail's next and have that point to null instead.
    	myLinkedList<Integer> m4 = new myLinkedList(m3);
    	System.out.println("Test 4 Testing Copying Constructor: m3:");//i = 13
    	m3.printList(true, 0);//this call is the same as: m4.printList(); or m4.printList(true);
    	System.out.println("New List: m4:");
    	m4.printList(true, 0);
    	System.out.print("The list should look like: 3,4,5,5,5,6,7,8,9,10 ");
    	if (doTheListsHaveTheSameData(m3, m4, true))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//test the remove methods here for case 00 (singly linked and not circular)
    	System.out.println("CASE 00: (NOT Circular and NOT Multilinked)");
    	int oldSize = m4.size();
    	int ocount = m4.containsCount(new Node(ThreeOfNum));
    	m4.remove(new Node(ThreeOfNum));
    	System.out.println("Test 4 Testing Remove One of a Certain Element (" + ThreeOfNum + "):");//i = 14
    	m4.printList();
    	//the memory addresses should skip over this element
    	if ((m4.containsCount(new Node(ThreeOfNum)) == (ocount - 1)) && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 15
    	oldSize = m4.size();
    	ocount = m4.containsCount(new Node(ThreeOfNum));
    	m4.remove(new Node(ThreeOfNum), true);
    	System.out.println("Test 4 Testing Remove All of a Certain Element (" + ThreeOfNum + "):");
    	m4.printList();
    	if (m4.contains(new Node(ThreeOfNum)) == false && (m4.size() == (oldSize - ocount)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 16
    	System.out.println("Test 4 Testing Remove Element (it will be the first one) (" + newFirstNum + "):");
    	oldSize = m4.size();
    	ocount = m4.containsCount(new Node(newFirstNum));
    	m4.remove(new Node(newFirstNum));
    	m4.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m4) &&
    		(m4.containsCount(new Node(newFirstNum)) == (ocount - 1)) && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 17
    	System.out.println("Test 4 Testing Remove Element (it will be the last one) (" + lastElement + "):");
    	oldSize = m4.size();
    	ocount = m4.containsCount(new Node(lastElement));
    	m4.remove(new Node(lastElement));
    	m4.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m4) &&
    		(m4.containsCount(new Node(lastElement)) == (ocount - 1)) && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 18
    	//the list should not contain 5 here at all a List.contains(Node n) should return false, false on null.
    	//the memory addresses should skip over this element;
    	//4.next should point to 6 (6. previous should point to 4)
    	n = m4.getNode(0);
    	oldSize = m4.size();
    	ocount = m4.containsCount(n);
    	m4.remove(0);//removes the first element (DID NOT WORK FOR CASE 00: NOT CIRCULAR NOR DOUBLY-LINKED)
    	//partially worked for CASE 10 Circular and NOT DOUBLY-Linked (the next address was wrong)
    	System.out.println("Test 4 Testing Remove The First Element (" + secondElement + "):");
    	m4.printList();
    	//check if still circular by checking: 1. if tail.next.next is equal to head.next AND
    	//2. head.next.previous = tail.next
    	if (checkIfCircularSettingIsCorrectAfterRemove(m4) &&
    		(m4.containsCount(n) == (ocount - 1)) && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 19
    	n = m4.getNode(m4.size() - 1);
    	oldSize = m4.size();
    	ocount = m4.containsCount(n);
    	m4.remove(m4.size() - 1);//removes the last element (DID NOT WORK)
    	System.out.println("Test 4 Testing Remove The Last Element (" + secondToLastElement + "):");
    	m4.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m4) &&
    		m4.containsCount(n) == ocount - 1 && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 20
    	n = m4.getNode(1);
    	oldSize = m4.size();
    	ocount = m4.containsCount(n);
    	m4.remove(1);//removes a middle element (DID NOT WORK)
    	//this worked on Circularly and NOT DOUBLY-LINKED.
    	System.out.println("Test 4 Testing Remove a Middle Element (6):");
    	m4.printList();
    	if (m4.containsCount(n) == ocount - 1 && (m4.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	//test 4 is: 13 through 20
    	
    	//i = 21
    	//create a new list for the new case
    	myLinkedList<Integer> m5 = new myLinkedList(m3, false, true);
    	System.out.println("Test 5 Testing other copy constructor m3:");
    	m3.printList(true, 0);//this call is the same as: m4.printList(); or m4.printList(true);
    	System.out.println("TEST 5 New List: m5:");
    	m5.printList(true, 0);
    	System.out.print("The list should look like: 3,4,5,5,5,6,7,8,9,10 ");
    	if (doTheListsHaveTheSameData(m3, m5, false))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 22
    	//test the remove methods here for case 01 (multi-linked and not circular)
    	System.out.println("CASE 01: (NOT Circular and Multilinked)");
    	ocount = m5.containsCount(new Node(ThreeOfNum));
    	oldSize = m5.size();
    	m5.remove(new Node(ThreeOfNum));
    	System.out.println("Test 5 Testing Remove One of a Certain Element (" + ThreeOfNum + "):");
    	m5.printList();
    	//the memory addresses should skip over this element
    	if (m5.containsCount(new Node(ThreeOfNum)) == ocount - 1 && (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 23
    	oldSize = m5.size();
    	ocount = m5.containsCount(new Node(ThreeOfNum));
    	m5.remove(new Node(ThreeOfNum), true);
    	System.out.println("Test 5 Testing Remove All of a Certain Element (" + ThreeOfNum + "):");
    	m5.printList();
    	if (m5.contains(new Node(ThreeOfNum)) == false && (m5.size() == (oldSize - ocount)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 24
    	System.out.println("Test 5 Testing Remove Element (it will be the first one) (" + newFirstNum + "):");
    	oldSize = m5.size();
    	ocount = m5.containsCount(new Node(newFirstNum));
    	m5.remove(new Node(newFirstNum));
    	m5.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m5) &&
    		(m5.containsCount(new Node(newFirstNum)) == ocount - 1) && (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 25
    	System.out.println("Test 5 Testing Remove Element (it will be the last one) (" + lastElement + "):");
    	oldSize = m5.size();
    	ocount = m5.containsCount(new Node(lastElement));
    	m5.remove(new Node(lastElement));
    	m5.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m5) &&
    		(m5.containsCount(new Node(lastElement)) == ocount - 1) && (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 26
    	//the list should not contain 5 here at all a List.contains(Node n) should return false, false on null.
    	//the memory addresses should skip over this element;
    	//4.next should point to 6 (6. previous should point to 4)
    	n = m5.getNode(0);
    	oldSize = m5.size();
    	ocount = m5.containsCount(n);
    	m5.remove(0);
    	System.out.println("Test 5 Testing Remove The First Element (" + secondElement + "):");
    	m5.printList();
    	//check if still circular by checking: 1. if tail.next.next is equal to head.next AND
    	//2. head.next.previous = tail.next
    	if (checkIfCircularSettingIsCorrectAfterRemove(m5) && m5.containsCount(n) == ocount - 1
    		&& (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 27
    	n = m5.getNode(m5.size() - 1);
    	oldSize = m5.size();
    	ocount = m5.containsCount(n);
    	m5.remove(m5.size() - 1);//removes the last element (DID NOT WORK)
    	System.out.println("Test 5 Testing Remove The Last Element (" + secondToLastElement + "):");
    	m5.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m5) && m5.containsCount(n) == ocount - 1
    		 && (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 28
    	n = m5.getNode(1);
    	ocount = m5.containsCount(n);
    	oldSize = m5.size();
    	m5.remove(1);//removes a middle element (DID NOT WORK)
    	//this worked on Circularly and NOT DOUBLY-LINKED.
    	System.out.println("Test 5 Testing Remove a Middle Element (6):");
    	m5.printList();
    	if (m5.containsCount(n) == ocount - 1 && (m5.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	//test 5 is: 21 through 28
    	
    	//i = 29
    	//create a new list for the new case
    	myLinkedList<Integer> m6 = new myLinkedList(m3, true, false);
    	System.out.println("TEST 6 New List: m6:");
    	m6.printList(true, 0);
    	System.out.print("The list should look like: 3,4,5,5,5,6,7,8,9,10 ");
    	if (doTheListsHaveTheSameData(m3, m6, false))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 30
    	//test the remove methods here for case 10 (singly-linked and circular)
    	System.out.println("CASE 10: (Circular and NOT Multilinked)");
    	oldSize = m6.size();
    	ocount = m6.containsCount(new Node(ThreeOfNum));
    	m6.remove(new Node(ThreeOfNum));
    	System.out.println("Test 6 Testing Remove One of a Certain Element (" + ThreeOfNum + "):");
    	m6.printList();
    	//the memory addresses should skip over this element
    	if (m6.containsCount(new Node(ThreeOfNum)) == ocount - 1 && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 31
    	oldSize = m6.size();
    	ocount = m6.containsCount(new Node(ThreeOfNum));
    	m6.remove(new Node(ThreeOfNum), true);
    	System.out.println("Test 6 Testing Remove All of a Certain Element (" + ThreeOfNum + "):");
    	m6.printList();
    	if (m6.contains(new Node(ThreeOfNum)) == false && (m6.size() == (oldSize - ocount)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 32
    	System.out.println("Test 6 Testing Remove Element (it will be the first one) (" + newFirstNum + "):");
    	oldSize = m6.size();
    	ocount = m6.containsCount(new Node(newFirstNum));
    	m6.remove(new Node(newFirstNum));
    	m6.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m6) &&
    		(m6.containsCount(new Node(newFirstNum)) == ocount - 1) && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 33
    	System.out.println("Test 6 Testing Remove Element (it will be the last one) (" + lastElement + "):");
    	ocount = m6.containsCount(new Node(lastElement));
    	oldSize = m6.size();
    	m6.remove(new Node(lastElement));
    	m6.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m6) &&
    		(m6.containsCount(new Node(lastElement)) == ocount - 1) && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 34
    	//the list should not contain 5 here at all a List.contains(Node n) should return false, false on null.
    	//the memory addresses should skip over this element;
    	//4.next should point to 6 (6. previous should point to 4)
    	n = m6.getNode(0);
    	oldSize = m6.size();
    	ocount = m6.containsCount(n);
    	m6.remove(0);
    	System.out.println("Test 6 Testing Remove The First Element (" + secondElement + "):");
    	m6.printList();
    	//check if still circular by checking: 1. if tail.next.next is equal to head.next AND
    	//2. head.next.previous = tail.next
    	if (checkIfCircularSettingIsCorrectAfterRemove(m6) && m6.containsCount(n) == ocount - 1
    		 && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 35
    	n = m6.getNode(m6.size() - 1);
    	oldSize = m6.size();
    	ocount = m6.containsCount(n);
    	m6.remove(m6.size() - 1);//removes the last element (DID NOT WORK)
    	System.out.println("Test 6 Testing Remove The Last Element (" + secondToLastElement + "):");
    	m6.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m6) && m6.containsCount(n) == ocount - 1
    		 && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 36
    	n = m6.getNode(1);
    	oldSize = m6.size();
    	ocount = m6.containsCount(n);
    	m6.remove(1);//removes a middle element (DID NOT WORK)
    	//this worked on Circularly and NOT DOUBLY-LINKED.
    	System.out.println("Test 6 Testing Remove a Middle Element (6):");
    	m6.printList();
    	if (m6.containsCount(n) == ocount - 1 && (m6.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	//test 6 is: 29 through 36
    	
    	
    	//i = 37
    	//create a new list for the new case
    	myLinkedList<Integer> m7 = new myLinkedList(m3, true, true);
    	System.out.println("TEST 7 New List: m7:");
    	m7.printList(true, 0);
    	System.out.print("The list should look like: 3,4,5,5,5,6,7,8,9,10 ");
    	if (doTheListsHaveTheSameData(m3, m7, false))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 38
    	//test the remove methods here for case 11 (multi-linked and circular)
    	System.out.println("CASE 11: (Circular and Multilinked)");
    	ocount = m7.containsCount(new Node(ThreeOfNum));
    	oldSize = m7.size();
    	m7.remove(new Node(ThreeOfNum));
    	System.out.println("Test 7 Testing Remove One of a Certain Element (" + ThreeOfNum + "):");
    	m7.printList();
    	//the memory addresses should skip over this element
    	if (m7.containsCount(new Node(ThreeOfNum)) == ocount - 1 && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 39
    	oldSize = m7.size();
    	ocount = m7.containsCount(new Node(ThreeOfNum));
    	m7.remove(new Node(ThreeOfNum), true);
    	System.out.println("Test 7 Testing Remove All of a Certain Element (" + ThreeOfNum + "):");
    	m7.printList();
    	if (m7.contains(new Node(ThreeOfNum)) == false && (m7.size() == (oldSize - ocount)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 40
    	System.out.println("Test 7 Testing Remove Element (it will be the first one) (" + newFirstNum + "):");
    	oldSize = m7.size();
    	ocount = m7.containsCount(new Node(newFirstNum));
    	m7.remove(new Node(newFirstNum));
    	m7.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m7) &&
    		(m7.containsCount(new Node(newFirstNum)) == ocount - 1) && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 41
    	System.out.println("Test 7 Testing Remove Element (it will be the last one) (" + lastElement + "):");
    	oldSize = m7.size();
    	ocount = m7.containsCount(new Node(lastElement));
    	m7.remove(new Node(lastElement));
    	m7.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m7) &&
    		(m7.containsCount(new Node(lastElement)) == ocount - 1) && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 42
    	//the list should not contain 5 here at all a List.contains(Node n) should return false, false on null.
    	//the memory addresses should skip over this element;
    	//4.next should point to 6 (6. previous should point to 4)
    	n = m7.getNode(0);
    	oldSize = m7.size();
    	ocount = m7.containsCount(n);
    	m7.remove(0);
    	System.out.println("Test 7 Testing Remove The First Element (" + secondElement + "):");
    	m7.printList();
    	//check if still circular by checking: 1. if tail.next.next is equal to head.next AND
    	//2. head.next.previous = tail.next
    	if (checkIfCircularSettingIsCorrectAfterRemove(m7) && m7.containsCount(n) == ocount - 1
    		 && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 43
    	n = m7.getNode(m7.size() - 1);
    	oldSize = m7.size();
    	ocount = m7.containsCount(n);
    	m7.remove(m7.size() - 1);//removes the last element (DID NOT WORK)
    	System.out.println("Test 7 Testing Remove The Last Element (" + secondToLastElement + "):");
    	m7.printList();
    	if (checkIfCircularSettingIsCorrectAfterRemove(m7) && m7.containsCount(n) == ocount - 1
    		 && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	//i = 44
    	n = m7.getNode(1);
    	ocount = m7.containsCount(n);
    	oldSize = m7.size();
    	m7.remove(1);//removes a middle element (DID NOT WORK)
    	//this worked on Circularly and NOT DOUBLY-LINKED.
    	System.out.println("Test 7 Testing Remove a Middle Element (6):");
    	m7.printList();
    	if (m7.containsCount(n) == ocount - 1 && (m7.size() == (oldSize - 1)))
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	//test 7 is: 37 through 44
    	
    	//System.out.println("After Removal Test");
    	//m7.printList(true, 0);//forwards, all
    	//m7.printList(true, 2);//forwards, evens only
    	//m7.printList(true, 1);//forwards, odds only
    	//System.out.println("TEST 8: TEST 3 Backwards:");
    	//m7.printList(false, 0);//backwards, all
    	//m7.printList(false, 2);//backwards, evens only
    	//m7.printList(false, 1);//backwards, odds only
    	
    	
    	//i = 45
    	m7.clear();
    	System.out.println("Test 8 Testing Remove all from the list:");
    	m7.printList(true, 0);
    	if (m7.size() == 0)
    	{
    		testResults[failingCount + passingCount] = true;
    		System.out.println("Test Past!");
    		passingCount++;
    	}
    	else 
    	{
    		testResults[failingCount + passingCount] = false;
    		System.out.println("Test Failed!");
    		failingCount++;
    	}
    	
    	
    	myLinkedList<String> m30 = new myLinkedList<String>();
    	Node<String> n30 = new Node("howdy");
    	m30.add(n30);
    	m30.add(1, new Node("hello"));
    	m30.add();
    	m30.getNode(2).setData("hi");
    	m30.add(new Node("world"));
    	m30.add(2, new Node("Chris Kelly"));
    	m30.add(new Node("Chris Kelly"));
    	m30.add(new Node("Chris Kelly"));
    	m30.add(new Node(""));
    	m30.add(new Node(null));
    	m30.printList();
    	m30.printList(true, 2);
    	m30.printList(true, 1);
    	m30.remove(3);
    	m30.remove(new Node("hello"));
    	m30.printList();
    	m30.remove(new Node("Chris Kelly"), true);
    	m30.remove(m30.size() - 1);
    	m30.printList();
    	
    	//prints all of the test results here
    	System.out.println("\n\nResults:\n");
    	
    	int x = 0;
    	for (int i = 0; i < numTotalTests; i++)
    	{
    		//test 2 is 0 through 12
    		//test 4 is 13 through 20
    		//test 5 is 21 through 28
    		//test 6 is 29 through 36
    		//test 7 is 37 through 44
    		
    		//System.out.println("i = " + i);
    		if (i == 1 || i == 14)
    		{
    			System.out.println("The first number corresponds to if the list is: Circular, " +
    				"and the second to Multilinked.");
    		}
    		//else;//do nothing
    		
    		System.out.print("Test ");
    		if (i == 0) System.out.print("1: Testing printing an empty list");
    		else if (i < 13 && i > 0)
    		{
    			System.out.print("2 Testing add(");
    			if (i > 4 && i < 9)
    			{
    				x = 1;
    				System.out.print("Node<T> n");
    			}
    			else if (i > 8 && i < 13)
    			{
    				x = 2;
    				System.out.print("int index, Node<T> element");
    			}
    			//else if (i > 0 && i < 5) x = 0;
    			else x = 0;//reset the x variable
    			
    			System.out.print(") and get and set data methods: CASE ");
    			//grey code order 01,00,10,11
    			if ((i == ((4 * x) + 1)) && x > -1 && x < 4) System.out.print("01");
    			else if ((i == ((4 * x) + 2)) && x > -1 && x < 4) System.out.print("00");
    			else if ((i == ((4 * x) + 3)) && x > -1 && x < 4) System.out.print("10");
    			else if ((i == ((4 * x) + 4)) && x > -1 && x < 4) System.out.print("11");
    			//else;//do nothing
    		}
    		else if (i > 12 && i < 45)
    		{
    			if (i > 12 && i < 21)
    			{
    				x = 0;
    				System.out.print("4");
    			}
    			else if (i > 20 && i < 29)
    			{
    				x = 1;
    				System.out.print("5");
    			}
    			else if (i > 28 && i < 37)
    			{
    				x = 2;
    				System.out.print("6");
    			}
    			else if (i > 36 && i < 45)
    			{
    				System.out.print("7");
    				x = 3;
    			}
    			else break;//error
    			System.out.print(" Testing ");
    			if (i == (13 + 8 * x))
    			{
    				if (x == 1 || x == 2 || x == 3) System.out.print("Other ");
    				if (x > -1 && x < 4) System.out.print("Copy Constructor");
    				else break;//on error
    			}
    			else if ((i == (14 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove One of a Certain Element");
    			}
    			else if ((i == (15 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove All of an Element");
    			}
    			else if ((i == (16 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove Element 3 (the first one in the list)");
    			}
    			else if ((i == (17 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove Element 10 (the last one in the list)");
    			}
    			else if ((i == (18 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove The First Element in the List");
    			}
    			else if ((i == (19 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove The Last Element in the List");
    			}
    			else if ((i == (20 + 8 * x)) && x > -1 && x < 4)
    			{
    				System.out.print("Remove a Middle Element in the List");
    			}
    			else break;//error should never make it here
    		}
    		else if (i == 45) System.out.print("8 Testing Remove all from the list");
    		//else;//do nothing
    		
    		//System.out.println("x = " + x);
    		System.out.println(": " + testResults[i]);
    		if (i == 0 || i == 13 || (i == (20 + 8 * x) && x > -1 && x < 4)) System.out.println();
    		else if (i == 12) System.out.println("\n");
    		//we need one after i == 0, i == 12, i == 20, i == 28, i == 36, i == 44
    		
    	}//end of i for loop
    	
    	System.out.println("\nSummary:");
    	System.out.println("FailingCount = " + failingCount);
    	System.out.println("PassingCount = " + passingCount);
    	System.out.println("Total Tests = " + (failingCount + passingCount));
    	
    	System.gc();
    }
}