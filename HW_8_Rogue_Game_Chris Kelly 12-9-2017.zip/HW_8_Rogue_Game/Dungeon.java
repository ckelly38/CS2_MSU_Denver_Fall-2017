/*************************************************************************
 *  Compilation:  javac Dungeon.java
 *
 *************************************************************************/

//package HW_8_Rogue_Game;
public class Dungeon {
    private boolean[][] isRoom = null;         // is v-w a room site?
    private boolean[][] isWall = null;         // is v-w a corridor site?
    private boolean[][] isInaccessible = null; // is a blank space?
    private boolean[][] isSkinnyPath = null;   // tell if a path is semi-isolated 1 to 3 neighbors only
    private int[][] areaNum = null;            // needed for platform count and a quick path from room to room
    private boolean[][] isPlatform = null;     // checks if this is a platform and used to get the count.
    private int N = 0;                         // dimension of dungeon is in N by N (this is just N).
    private Game game = null;                  // the game needed for wall check and part locs mainly

    // initialize a new dungeon based on the given board
    public Dungeon(char[][] board, Game g) {
        game = g;
        N = board.length;
        isRoom         = new boolean[N][N];
        isWall         = new boolean[N][N];
        isInaccessible = new boolean[N][N];
        isSkinnyPath   = new boolean[N][N];
        isPlatform     = new boolean[N][N];
        areaNum        = new int[N][N];
        //initialize everything
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		isRoom[r][c]         = false;
        		isWall[r][c]         = false;
        		isInaccessible[r][c] = false;
        		isSkinnyPath[r][c]   = false;
        		isPlatform[r][c] = false;
        		areaNum[r][c] = -1;
        	}
        }
        //set the obvious information
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                if      (board[i][j] == '.') isRoom[i][j] = true;
                else if (board[i][j] == '+') isWall[i][j] = true;
                else if (board[i][j] == ' ') isInaccessible[i][j] = true;
            }
        }
        //determine if it is a skinny path or not
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		Site s = new Site(r, c);
        		Site[] locs = getNeighbors(s);
		        if (isInaccessible[r][c]) isSkinnyPath[r][c] = false;
        		else
        		{
        			if (locs.length < 3) isSkinnyPath[r][c] = true;
	        		else
	        		{
	        			//one above and one below then it is a skinny path or
	        			//one on either side...
	        			if ((c > 0 && c + 1 < N && isInaccessible[r][c - 1] && isInaccessible[r][c + 1]) ||
	        				(r > 0 && r + 1 < N && isInaccessible[r - 1][c] && isInaccessible[r + 1][c]))
	        			{
	        				isSkinnyPath[r][c] = true;
	        			}
	        			else if (c == 0 && c + 1 < N && isInaccessible[r][c + 1]) isSkinnyPath[r][c] = true;
	        			else if (r == 0 && r + 1 < N && isInaccessible[r + 1][c]) isSkinnyPath[r][c] = true;
	        			else if (r == N - 1 && r - 1 > -1 && isInaccessible[r - 1][c]) isSkinnyPath[r][c] = true;
	        			else if (c == N - 1 && c - 1 > -1 && isInaccessible[r][c - 1]) isSkinnyPath[r][c] = true;
	        			else isSkinnyPath[r][c] = false;//most likely not anyway, but there are some we have to
	        			//catch afterwards.
	        		}
        		}
        	}
        }
        //apply sandwich therome for the skinny paths
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		if (isSkinnyPath[r][c] == false)
        		{
        			if (r == 0)
        			{
        				if (c == 0)
        				{
        					//top-left corner
        					if (N > 1 && isSkinnyPath[r][c + 1] && isSkinnyPath[r + 1][c] &&
        						!isSkinnyPath[r + 1][c + 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c == N - 1)
        				{
        					//top-right corner
        					if (N > 1 && isSkinnyPath[r][c - 1] && isSkinnyPath[r + 1][c] &&
        						!isSkinnyPath[r + 1][c - 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c > 0 && c < N - 1)
        				{
        					if (c + 1 < N && c > 0 && r + 1 < N && isSkinnyPath[r][c - 1] &&
		        				isSkinnyPath[r][c + 1] && isSkinnyPath[r + 1][c])
		        			{
		        				isSkinnyPath[r][c] = true;
		        			}
		        			//else;//do nothing
        				}
        				else break;//should not happen
        			}
        			else if (r == N - 1)
        			{
        				if (c == 0)
        				{
        					//bottom-left corner
        					if (N > 1 && isSkinnyPath[r - 1][c] && isSkinnyPath[r][c + 1] &&
        						!isSkinnyPath[r - 1][c + 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c == N - 1)
        				{
        					//bottom-right corner
        					if (N > 1 && isSkinnyPath[r][c - 1] && isSkinnyPath[r - 1][c] &&
        						!isSkinnyPath[r - 1][c - 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c > 0 && c < N - 1)
        				{
        					//somewhere along the bottom row
        					if (c + 1 < N && c > 0 && r < N && isSkinnyPath[r][c - 1] &&
        						isSkinnyPath[r][c + 1] && isSkinnyPath[r - 1][c])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else break;//should not happen
        			}
        			else if (r > 0 && r < N - 1)
        			{
        				if (c == 0)
        				{
        					//10...
        					//x1..
        					//10..
        					//x is the current location
        					
        					if (r > 0 && N > 2 && r + 1 < N - 1 && c + 1 < N - 1 &&
        						isSkinnyPath[r - 1][c] && isSkinnyPath[r + 1][c] &&
        						isSkinnyPath[r][c + 1] && !isSkinnyPath[r - 1][c + 1] &&
        						!isSkinnyPath[r + 1][c + 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c == N - 1)
        				{
        					//...01
        					//...1x
        					//...01
        					//x is the current location
        					
        					if (r > 0 && c > 0 && r + 1 < N - 1 && isSkinnyPath[r - 1][c] &&
        						isSkinnyPath[r][c - 1] && isSkinnyPath[r + 1][c] &&
        						!isSkinnyPath[r - 1][c - 1] && !isSkinnyPath[r + 1][c - 1])
        					{
        						isSkinnyPath[r][c] = true;
        					}
        					//else;//do nothing
        				}
        				else if (c > 0 && c < N - 1)
        				{
	        				if (N > 2 && r > 0 && c > 0 && r + 1 < N - 1 && c + 1 < N - 1 &&
	        					isSkinnyPath[r - 1][c] && isSkinnyPath[r][c - 1] && isSkinnyPath[r][c + 1] &&
	        					isSkinnyPath[r + 1][c] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r - 1][c + 1] && !isSkinnyPath[r + 1][c - 1] &&
	        					!isSkinnyPath[r + 1][c + 1])
	        				{
	        					//010
		        				//1x1
		        				//010
		        				//x is the current location 1s are at r-1, c; r+1,c; r, c-1; and r, c+1;
		        				//the 0s are at r-1, c-1; r-1, c+1; r+1, c-1; r+1, c+1
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c >  0 && r + 1 < N && c + 1 < N &&
	        					isSkinnyPath[r - 1][c] && isSkinnyPath[r][c - 1] &&
	        					isSkinnyPath[r + 1][c + 1] && isInaccessible[r][c + 1] &&
	        					!isSkinnyPath[r - 1][c - 1] && !isSkinnyPath[r - 1][c + 1] &&
	        					!isSkinnyPath[r][c + 1] && !isSkinnyPath[r + 1][c - 1] &&
	        					!isSkinnyPath[r + 1][c + 1])
	        				{
	        					//acts like against the right wall
		        				//010
		        				//1xn
		        				//010
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r - 1][c] &&
	        					isSkinnyPath[r][c + 1] && isSkinnyPath[r + 1][c] &&
	        					!isSkinnyPath[r - 1][c - 1] && !isSkinnyPath[r][c - 1] &&
	        					!isSkinnyPath[r + 1][c - 1] && isInaccessible[r][c - 1])
	        				{
	        					//acts like against left wall
		        				//010
		        				//nx1
		        				//010
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
		        				isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N &&
	        					isSkinnyPath[r - 1][c] && isSkinnyPath[r][c - 1] && isSkinnyPath[r][c + 1] &&
	        					!isSkinnyPath[r + 1][c - 1] && !isSkinnyPath[r + 1][c] &&
	        					!isSkinnyPath[r + 1][c + 1] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r - 1][c + 1] && isInaccessible[r + 1][c])
	        				{
	        					//acts like against bottom wall
		        				//010
		        				//1x1
		        				//0n0
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r][c - 1] &&
	        					isSkinnyPath[r][c + 1] && isSkinnyPath[r + 1][c] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r - 1][c] && !isSkinnyPath[r - 1][c + 1] &&
	        					!isSkinnyPath[r + 1][c - 1] && !isSkinnyPath[r + 1][c + 1] &&
	        					isInaccessible[r - 1][c])
	        				{
	        					//acts like against top wall
		        				//0n0
		        				//1x1
		        				//010
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r][c + 1] &&
	        					isSkinnyPath[r + 1][c] && !isSkinnyPath[r - 1][c - 1] && !isSkinnyPath[r - 1][c] &&
	        					!isSkinnyPath[r - 1][c + 1] && !isSkinnyPath[r][c - 1] &&
	        					!isSkinnyPath[r + 1][c - 1] && !isSkinnyPath[r + 1][c + 1] &&
	        					isInaccessible[r - 1][c] && isInaccessible[r][c - 1])
	        				{
	        					//top-left corner-like
		        				//0n0
		        				//nx1
		        				//010
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r - 1][c] &&
	        					isSkinnyPath[r][c + 1] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r][c - 1] && !isSkinnyPath[r + 1][c - 1] &&
	        					!isSkinnyPath[r + 1][c] && !isSkinnyPath[r + 1][c + 1] &&
	        					isInaccessible[r][c - 1] && isInaccessible[r + 1][c])
	        				{
	        					//bottom-left corner-like
		        				//010
		        				//nx1
		        				//0n0
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r - 1][c] &&
	        					isSkinnyPath[r][c - 1] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r - 1][c + 1] && !isSkinnyPath[r][c + 1] &&
	        					!isSkinnyPath[r + 1][c + 1] && !isSkinnyPath[r + 1][c - 1] &&
	        					!isSkinnyPath[r + 1][c] && isInaccessible[r + 1][c] && isInaccessible[r][c + 1])
	        				{
	        					//bottom-right corner-like
		        				//010
		        				//1xn
		        				//0n0
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible.
	        					isSkinnyPath[r][c] = true;
	        				}
	        				else if (r > 0 && c > 0 && r + 1 < N && c + 1 < N && isSkinnyPath[r][c - 1] &&
	        					isSkinnyPath[r + 1][c] && !isSkinnyPath[r - 1][c - 1] &&
	        					!isSkinnyPath[r - 1][c] && isSkinnyPath[r - 1][c + 1] &&
	        					!isSkinnyPath[r][c + 1] && !isSkinnyPath[r + 1][c + 1] &&
	        					isInaccessible[r][c + 1] && isInaccessible[r + 1][c])
	        				{
	        					//top-right corner-like
		        				//0n0
		        				//1xn
		        				//010
		        				//x is the current location and n is a location that is not accessible to either
		        				//part. We also know that skinny path is false at n, but at x it needs to be true
		        				//we need to check for all zeros of the side of n and if n is not accessible
	        					isSkinnyPath[r][c] = true;
	        				}
	        				//else;//do nothing
        				}
        				else break;
        			}
        			else break;
        		}
        		//else;//do nothing
        	}
        }
        //get isPlatform status for numbering
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		if (isSkinnyPath[r][c]) isPlatform[r][c] = false;
        		else if (isInaccessible[r][c]) isPlatform[r][c] = false;
        		else if (isRoom[r][c] || isWall[r][c])
        		{
        			//we need to check to see if there are 4 next to each other and that none of them belong to a path
        			//the four can be:
        			//..
        			//.. any number of them can be plusses; we need to use the get neighbors and check all around for these
        			//OR: ... 3 in a row and 1 in one of the cols, all of them must not be on a path
        			//     .
        			//we also know that NEW row must start one row above and one col left of the location, and we end on the
        			//col immediately to the right of us and the row below use
        			//NOTE: max num accessed will be 9 because it counts the current location
        			int wallRoomCount = 0;
        			int numAccessed = 0;
        			int wallRoomOnPathCount = 0;
        			int row = r - 1;
        			if (row < 0) row = 0;
        			for (row = row; row > -1 && row < r + 2 && row < N; row++)
        			{
        				int col = c - 1;
        				if (col < 0) col = 0;
        				for (col = col; col > -1 && col < c + 2 && col < N; col++)
        				{
        					if (isRoom[row][col] || isWall[row][col])
        					{
        						if (isSkinnyPath[row][col]) wallRoomOnPathCount++;
        						wallRoomCount++;
        					}
        					//else;//do nothing
        					numAccessed++;
        				}//end of col for loop
        			}//end of row for loop
        			if (numAccessed > 3)
        			{
        				if (wallRoomCount - wallRoomOnPathCount > 3)
        				{
        					isPlatform[r][c] = true;
        				}
        				else isPlatform[r][c] = false;
        			}
        			else isPlatform[r][c] = false;
        		}
        		else isPlatform[r][c] = false;
        		//System.out.println("isPlatform[" + r + "][" + c + "] = " + isPlatform[r][c]);
        	}//end of c for loop
        }//end of r for loop
        
        //get area number information
        int areaCount = 0;
        boolean changeOfAreaFound = false;
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		if (isSkinnyPath[r][c])
        		{
        			areaNum[r][c] = 0;
        			changeOfAreaFound = true;
        		}
        		else if (isInaccessible[r][c])
        		{
        			areaNum[r][c] = -1;
        			changeOfAreaFound = true;
        		}
        		else if (isRoom[r][c] || isWall[r][c])
        		{
        			if (isPlatform[r][c])
        			{
	        			if (changeOfAreaFound)
	        			{
	        				//check to see if there is one near this one that is already numbered
	        				//and use that number else incrementCounter.
	        				if (r > 0)
	        				{
	        					if (areaNum[r - 1][c] > 0) areaNum[r][c] = areaNum[r - 1][c];
	        					else
	        					{
	        						areaCount++;
	        						areaNum[r][c] = areaCount;
	        					}
	        				}
	        				else
	        				{
	        					if (c > 0)
	        					{
	        						if (areaNum[r][c - 1] > 0) areaNum[r][c] = areaNum[r][c - 1];
	        						else
	        						{
	        							areaCount++;
	        							areaNum[r][c] = areaCount;
	        						}
	        					}
	        					else
	        					{
	        						if (areaCount < 1) areaCount = 1;
	        						areaNum[r][c] = areaCount;
	        					}
	        				}
	        				changeOfAreaFound = false;
	        			}
	        			else
	        			{
	        				if (r > 0)
	        				{
	        					if (areaNum[r - 1][c] > 0) areaNum[r][c] = areaNum[r - 1][c];
	        					else areaNum[r][c] = areaCount;
	        				}
	        				else
	        				{
	        					if (c > 0)
		        				{
		        					if (areaNum[r][c - 1] > 0) areaNum[r][c] = areaNum[r][c - 1];
		        					else areaNum[r][c] = areaCount;
		        				}
		        				else
	        					{
	        						if (areaCount < 1) areaCount = 1;
	        						areaNum[r][c] = areaCount;
	        					}
	        				}
	        			}
        			}
        			else
        			{
        				areaNum[r][c] = 0;
        				changeOfAreaFound = true;
        			}
        		}
        		//if (areaNum[r][c] > -1 && areaNum[r][c] < 10) System.out.print(" ");
        		//else if (areaNum[r][c] > 0 && areaNum[r][c] > 9 && areaNum[r][c] < 100) System.out.print("  ");
        		//else;//do nothing
        		//System.out.print(areaNum[r][c]);
        	}
        	//System.out.println();
        }
    }

    
	//is the point on an N*N grid starting at N = 0?
	//if loc is null return false.
	public boolean isSiteValidForAnNByNGridStartingAt0(Site loc)
	{
		if (loc == null) return false;
		if (loc.col() < 0 || loc.row() < 0 || loc.row() > N - 1 || loc.col() > N - 1) return false;
		return true;
	}
    
    // return dimension of dungeon
    public int size() { return N; }

    // does v correspond to a wall site? 
    public boolean isWall(Site v) {
        int i = v.i();
        int j = v.j();
        if (i < 0 || j < 0 || i >= N || j >= N) return false;
        return isWall[i][j];
    }

    // does v correspond to a room site?
    public boolean isRoom(Site v) {
        int i = v.i();
        int j = v.j();
        if (i < 0 || j < 0 || i >= N || j >= N) return false;
        return isRoom[i][j];
    }

    //can either piece not get to it
    public boolean isInaccessible(Site v)
    {
    	if (v == null) return true;//cannot access null
    	
    	int i = v.i();
        int j = v.j();
        if (i < 0 || j < 0 || i >= N || j >= N) return false;
        else return isInaccessible[i][j];
    }
    
    //returns a number 1 or greater unless there was an error (on error it returns -2)
    //value of 0 indicates that it could not even find one platform, but that the board was valid
    //value of 0 indicates that there were only skinny paths found on the board.
    //value of -1 is all inaccessible locations.
    public int getMaxPlatformNumber()
    {
    	int max = -2;
    	for (int r = 0; r < N; r++)
    	{
    		for (int c = 0; c < N; c++)
    		{
    			if (areaNum[r][c] > max) max = areaNum[r][c];
    		}//end of c for loop
    	}//end of r for loop
    	return max;
    }
    
    //method returns -1 in error
    public int getNumLocsInRoom(int n)
    {
    	int maxNumPlats = getMaxPlatformNumber();
    	if (n < 1 || n > maxNumPlats || maxNumPlats < 1) return -1;
    	int count = 0;
    	for (int r = 0; r < N; r++)
    	{
    		for (int c = 0; c < N; c++)
    		{
    			if (areaNum[r][c] == n) count++;
    		}//end of c for loop
    	}//end of r for loop
    	return count;
    }
    
    public Site[] getListOfLocsInRoom(int n)
    {
    	int numLocsInRoom = getNumLocsInRoom(n);
    	Site[] mlist = null;
    	if (numLocsInRoom < 1) mlist = new Site[0];
    	else
    	{
    		mlist = new Site[numLocsInRoom];
    		int index = 0;
    		for (int r = 0; r < N; r++)
    		{
    			if (index < numLocsInRoom);//do nothing
    			else break;
    			
    			for (int c = 0; c < N; c++)
    			{
    				if (index < numLocsInRoom);//do nothing
    				else break;
    				
    				if (areaNum[r][c] == n)
    				{
    					mlist[index] = new Site(r, c);
    					index++;
    				}
    				//else;//do nothing
    			}//end of c for loop
    		}//end of r for loop
    	}
    	return mlist;
    }
    
    public boolean isLocInRoom(int n, Site loc)
    {
    	if (!isSiteValidForAnNByNGridStartingAt0(loc)) return false;
    	
    	for (int r = 0; r < N; r++)
    	{
    		for (int c = 0; c < N; c++)
    		{
    			if (areaNum[r][c] == n && loc.row() == r && loc.col() == c) return true;
    		}//end of c for loop
    	}//end of r for loop
    	return false;
    }
    
    
	//does a neighbor check to determine if the path is narrow or not.
	//narrow paths only have at max 3 neighbors but normally only 2
	//3 are found at corners only.
	public boolean isSkinnyPath(Site v)
	{
		if (v == null || v.row() < 0 || v.col() < 0 || v.row() > N - 1 ||
			v.col() > N - 1) return false;
		return isSkinnyPath[v.row()][v.col()];
	}
	
	//This method checks to see if a valid spot cannot be accessed by someone not on it
	//if it cannot be accessed at all, you are isolated and the method returns 1.
	//if you are semi-isolated, meaning you can't move in all directions or your options
	//are limited to say 3 including this location, then you are semi isolated -1;
	//otherwise, this returns 0 for not being isolated at all.
	//This will return -2 if the data passed in was not valid.
	public int isIsolated(Site loc)
	{
		//1 is totally true
		//-1 is semi-true
		//0 is not true at all
		
		//null is a spot that cannot be gotten to by any piece
		//check if the spot is not valid on a grid that is only positive
		if (!isSiteValidForAnNByNGridStartingAt0(loc)) return -2;
		
		//check if every spot around it is inaccessible
		//if it has all neighbors, it is completely accessible
		//if it only has some, then it is semi-accessible
		//else it it cut off
		
		int countNumInaccessible = 0;
		int numSquaresVisited = 0;
		int wallCount = 0;
		//conditions to make sure the square for loop runs
		int r = loc.i() - 1;
		int c = loc.j() - 1;
		if (r < 0) r = 0;
		if (c < 0) c = 0;
		for (r = r; r > loc.i() - 2 && r < loc.i() + 2 && r > -1 && r < size(); r++)
		{
			//System.out.println("r = " + r);
			c = loc.j() - 1;
			if (c < 0) c = 0;
			for (c = c; c > loc.j() - 2 && c < loc.j() + 2 && c > -1 && c < size(); c++)
			{
				//System.out.println("c = " + c);
				if (isInaccessible(new Site(r, c))) countNumInaccessible++;
				else if (isWall(new Site(r, c))) wallCount++;
				numSquaresVisited++;
			}//end of c for loop
		}//end of r for loop
		
		//System.out.println("countNumInaccessible = " + countNumInaccessible);
		//System.out.println("numSquaresVisited = " + numSquaresVisited);
		//System.out.println("wallCount = " + wallCount);
		if (countNumInaccessible == numSquaresVisited - 1)
		{
			return 1;//isolated
		}
		else if (wallCount == numSquaresVisited - 1)
		{
			//case for isolation
			//+++
			//+@+ the @ is isolated because it can't get out
			//+++
			//if the center is a room -> true for isolated 1
			//else if it is a wall -> false for isolated 0
			
			//case for not
			// +
			//++ The bottom right corner (could be a wall or a room) is not isolated
			//because we can move to the plusses on either side. It has limited options
			//and is semi-isolated (-1) however.
			
			//-Since there is one that is inaccessible, we know that this will be
			//either totally isolated (1) or semi-isolated (-1).
			//-Further more, we are not surrounded by walls and in the center
			//if the center were a wall itself, then that case above would not be true.
			
			if (isWall(loc)) return 0;
			else
			{
				//center is a room
				if (numSquaresVisited > 8) return 1;//if num squares visited is 9
				else
				{
					if (countNumInaccessible > 0) return -1;
					else return 0;
				}
			}
		}
		else if (countNumInaccessible == 0) return 0;//not isolated
		else return -1;//semi-isolated
	}
    public boolean isAbsolutelyIsolated(Site loc)
    {
    	if (loc == null) return true;
    	else if (loc.row() < 0 || loc.col() < 0 || loc.row() > N - 1 || loc.col() > N - 1) return true;
    	else return (isIsolated(loc) == 1);
    }
    public boolean isNotAtAllIsolated(Site loc)
    {
    	if (loc == null) return false;
    	else if (loc.row() < 0 || loc.col() < 0 || loc.row() > N - 1 || loc.col() > N - 1) return false;
    	else return (isIsolated(loc) == 0);
    }
    public boolean isSemiIsolated(Site loc)
    {
    	if (loc == null) return true;
    	else if (loc.row() < 0 || loc.col() < 0 || loc.row() > N - 1 || loc.col() > N - 1) return true;
    	else return (isIsolated(loc) == -1);
    }
    
    //gets all of the valid locations that are adjacent to this
    public Site[] getNeighbors(Site loc)
    {
    	if (loc == null) return null;
    	if (loc.row() < 0 || loc.row() > N - 1 || loc.col() < 0 || loc.col() > N - 1) return null;
    	
    	//max neighbors counting this one is 9
    	int numSquaresVisited = 0;
    	int countNumInaccessible = 0;
		//conditions to make sure the square for loop runs
		int r = loc.row() - 1;
		int c = loc.col() - 1;
		if (r < 0) r = 0;
		if (c < 0) c = 0;
		for (r = r; r > loc.i() - 2 && r < loc.i() + 2 && r > -1 && r < size(); r++)
		{
			//System.out.println("r = " + r);
			c = loc.j() - 1;
			if (c < 0) c = 0;
			for (c = c; c > loc.j() - 2 && c < loc.j() + 2 && c > -1 && c < size(); c++)
			{
				//System.out.println("c = " + c);
				Site s = new Site(r, c);
				if (isInaccessible(s) || s.equals(loc)) countNumInaccessible++;
				numSquaresVisited++;
			}//end of c for loop
		}//end of r for loop
		
		//generate the list here
		//System.out.println("numSquaresVisited = " + numSquaresVisited);
		//System.out.println("countNumInaccessible = " + countNumInaccessible);
		//size of the array = numSquaresVisited - countNumInaccessible;
		final int totalLocs = numSquaresVisited - countNumInaccessible;
		Site[] locs = new Site[totalLocs];
		
		int locsIndex = 0;
		r = loc.row() - 1;
		c = loc.col() - 1;
		if (r < 0) r = 0;
		if (c < 0) c = 0;
		for (r = r; r > loc.i() - 2 && r < loc.i() + 2 && r > -1 && r < size(); r++)
		{
			//System.out.println("r = " + r);
			c = loc.j() - 1;
			if (c < 0) c = 0;
			for (c = c; c > loc.j() - 2 && c < loc.j() + 2 && c > -1 && c < size(); c++)
			{
				if (locsIndex < totalLocs && locsIndex > - 1 && totalLocs < 9);//do nothing
				else break;
				
				//System.out.println("c = " + c);
				Site s = new Site(r, c);
				if (isInaccessible(s) || s.equals(loc));
				else
				{
					locs[locsIndex] = s;
					locsIndex++;
				}
			}//end of c for loop
		}//end of r for loop
		
		return locs;
    }
    
    
    //Is the move from a to b legal?
    public boolean isLegalMoveNoWallCheck(Site a, Site b)
    {
    	//checks to see if they are null or off the grid
    	if (!isSiteValidForAnNByNGridStartingAt0(a)) return false;
        if (!isSiteValidForAnNByNGridStartingAt0(b)) return false;
        
        //check if we aren't allowed to move there at all
        if (isInaccessible(a) || isInaccessible(b)) return false;
        //do a distance check here
        if (Math.abs(a.row() - b.row()) > 1)  return false;
        if (Math.abs(a.col() - b.col()) > 1)  return false;
        if (a.row() == b.row()) return true;
        if (a.col() == b.col()) return true;
        //are they both rooms and are they next to each other
        if (isRoom(a) && isRoom(b)) return true;
        //the do nothing move is valid
        if (a.equals(b)) return true;
        return false;
    }
    
    
    //gets a list of locations that the part can move to
    //this does not do a wall check because of the other information that is required
    public Site[] getLegalMoves(Site a)
    {
    	if (a == null) return null;
    	Site[] neighbors = getNeighbors(a);
    	
    	boolean[] keep = new boolean[neighbors.length];
    	for (int i = 0; i < keep.length; i++) keep[i] = true;//want to keep all of them
    	
    	int remCount = 0;
    	for (int i = 0; i < neighbors.length; i++)
    	{
    		if (neighbors[i].equals(a))
    		{
    			remCount++;
    			keep[i] = false;
    		}
    		else if (isLegalMoveNoWallCheck(a, neighbors[i])) keep[i] = true;
    		else
    		{
    			remCount++;
    			keep[i] = false;
    		}
    	}//end of i for loop
    	
    	Site[] retVals = new Site[neighbors.length - remCount];
    	int index = 0;
    	for (int i = 0; i < neighbors.length; i++)
    	{
    		if (keep[i])
    		{
    			retVals[index] = neighbors[i];
    			index++;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	
    	return retVals;
    }
    
    
    //NOT SURE IF THIS WORKS RIGHT 12-8-2017 (dungeonK.txt monster caught cheating)
    //MAY WANT TO SIMPLIFY THIS METHOD??? 12-8-2017
    //did we pass in valid data?
    //are we moving from wall to wall and is this legal?
    //are we moving from wall to room and did the PART do this legally?
    //are we moving from room to wall?
    public boolean wallCheck(Site a, Site b, Site lastPartSite, boolean monsterMoving)
    {
    	//we are going from a to b
    	//check preconditions
    	//check if the locations are valid for our purposes first
    	if (!isSiteValidForAnNByNGridStartingAt0(a) || !isSiteValidForAnNByNGridStartingAt0(b)) return false;
        //check if we aren't allowed to move there at all
        if (isInaccessible(a) || isInaccessible(b)) return false;
        //check for the do nothing
        if (a.equals(b)) return true;
        
        //check if we are trying to cross a wall from a previous location
        
        //if a is a wall and b is the monster or the rogue's location just outside of the wall
        //return TRUE; if a is a wall and game.getMonsterSite() is equal to a and b is a room
        //or wall as well (we know that it is accessible because it made it this far in the
        //method) b may also be equal to rogue's location, then return FALSE because the monster
        //tried to cross through the wall.
        
        //a is the site we are moving from; b is the site we are moving to.
        if (isWall(a) || isWall(b))
        {
        	//System.out.println("isWall(a) = " + isWall(a));
        	//System.out.println("isWall(b) = " + isWall(b));
        	//System.out.println("isRoom(a) = " + isRoom(a));
        	//we know w is a wall and v is not
        	//w is where we are moving to
        	if (isRoom(a)) return true;//room (a) to wall (b) is legal
			else if (isWall(a))
			{
				//could be wall to wall
				//wall to room 
				//1. wall to wall can only be on the same col if it is against the end of the board
				//or against rooms (counting blanks as the end of the board also), else:
				//we know that this can only be on the same row (column to column). We know that diagnal
				//from wall to wall is NOT allowed.
				//2. wall to room which is where the monster could try to walk through the wall
				//which we need to prevent.
				if (isWall(b))
				{
					//System.out.println("This is wall to wall");
					if (a.row() == b.row()) return true;
					else if (a.col() == b.col())
					{
						//wall to wall on the columns
						if (N > 2)
						{
							if (a.col() == N - 1 || a.col() == 0) return true;
							else
							{
								//if N > 2
								//.++++
								// +++  
								// +++.
								//if on one end v.col() - 1 is a column of blanks OR
								//is a combination of that and rooms this is true.
								//if there is a plus on one side of the one we are moving to return false
								//otherwise return true
								if (isWall(new Site(b.row(), b.col() - 1)) ||
									isWall(new Site(b.row(), b.col() + 1)))
								{
									return false;
								}
								else return true;
							}
						}
						else return true;
					}
					else return false;//diagnal from wall to wall is NOT allowed
				}
				else
				{
					//System.out.println("This is a wall to room");
					//we know this is a room
					//this is a wall (a) to room (b) check
					
					//What to do about this?
	        		//.+++    .+++
	        		//M+@+ -> .M@+ Can the monster get the rogue?
	        		//.+++    .+++ NO! The Rogue is isolated.
	        		
	        		//We have the last location of the monster and the last location of the
	        		//rogue as well as the current location of both the monster and the rogue.
	        		//We have the board.
	        		
	        		//Site lastMonsterLoc = game.getLastMonsterSite();//what ever is at v right
	        		//now will not be null, if this were on the first move of this part
	        		//Site lastRogueLoc = game.getLastRogueSite();
	        		Site lastMonsterLoc = null;
	        		Site lastRogueLoc = null;
	        		if (monsterMoving) lastMonsterLoc = lastPartSite;
	        		else lastRogueLoc = lastPartSite;
	        		//System.out.println("lastPartSite = " + lastPartSite);
	        		
	        		//check to see if last part site was legal
	        		if (lastPartSite == null) return true;
	        		if (!isLegalMoveNoWallCheck(lastPartSite, a)) return false;
	        		//System.out.println("the last move was legal");
	        		//System.out.println("monsterMoving = " + monsterMoving);
	        		//System.out.println("loc a = " + a);
	        		//System.out.println("loc b = " + b);
	        		
	        		if (monsterMoving)
	        		{
		        		if (lastMonsterLoc.col() < a.col())
		        		{
		        			//we know that it came from the left to the wall trying to get through
		        			if (b.col() > a.col())
		        			{
		        				//we need to check to see if there are walls on both sides of the
		        				//a position in this case we need to check up and down
		        				if (a.row() == 0) return true;
			        			if (a.row() == N - 1) return true;
			        			if (isWall(new Site(a.row() - 1, a.col())) &&
		        					isWall(new Site(a.row() + 1, a.col())))
		        				{
		        					return false;
		        				}
		        				else return true;
		        			}
		        			else return true;
		        		}
		        		else if (lastMonsterLoc.col() > a.col())
		        		{
		        			//we know that it came from the right
		        			if (b.col() < a.col())
		        			{
		        				//we need to check to see if there are walls on both sides of the
		        				//a position in this case we need to check up and down
		        				if (a.row() == 0) return true;
			        			if (a.row() == N - 1) return true;
			        			if (isWall(new Site(a.row() - 1, a.col())) &&
		        					isWall(new Site(a.row() + 1, a.col())))
		        				{
		        					return false;
		        				}
		        				else return true;
		        			}
		        			else return true;
		        		}
		        		else
		        		{
		        			//if the cols are equal check the rows
		        			if (lastMonsterLoc.row() < a.row())
			        		{
			        			//we know that it came from the top (row 0) going to the bottom (row N)
			        			if (b.row() > a.row())
			        			{
			        				//we need to check to see if there are plusses on either side of a
			        				//that is left and right since going up or down
			        				if (a.col() == 0) return true;
			        				if (a.col() == N - 1) return true;
			        				if (isWall(new Site(a.row(), a.col() - 1)) &&
			        					isWall(new Site(a.row(), a.col() + 1)))
			        				{
			        					return false;
			        				}
			        				else return true;
			        			}
			        			else return true;
			        		}
			        		else if (lastMonsterLoc.row() > a.row())
			        		{
			        			//we know that it came from the bottom going to the top
			        			if (b.row() < a.row())
			        			{
			        				if (a.col() == 0) return true;
			        				if (a.col() == N - 1) return true;
			        				if (isWall(new Site(a.row(), a.col() - 1)) &&
			        					isWall(new Site(a.row(), a.col() + 1)))
			        				{
			        					return false;
			        				}
			        				else return true;
			        			}
			        			else return true;
			        		}
			        		else return true;//should not happen
		        		}
	        		}
	        		else
	        		{
	        			//rogue is moving
	        			//v equals the rogue site; rogue is doing the moving
	        			if (lastRogueLoc.col() < a.col())
		        		{
		        			//we know that it came from the left to the wall trying to get through
		        			if (b.col() > a.col())
		        			{
		        				//we need to check to see if there are walls on both sides of the
		        				//a position in this case we need to check up and down
		        				if (a.row() == 0) return true;
			        			if (a.row() == N - 1) return true;
			        			if (isWall(new Site(a.row() - 1, a.col())) &&
		        					isWall(new Site(a.row() + 1, a.col())))
		        				{
		        					return false;
		        				}
		        				else return true;
		        			}
		        			else return true;
		        		}
		        		else if (lastRogueLoc.col() > a.col())
		        		{
		        			//we know that it came from the right
		        			if (b.col() < a.col())
		        			{
		        				//we need to check to see if there are walls on both sides of the
		        				//a position in this case we need to check up and down
		        				if (a.row() == 0) return true;
			        			if (a.row() == N - 1) return true;
			        			if (isWall(new Site(a.row() - 1, a.col())) &&
		        					isWall(new Site(a.row() + 1, a.col())))
		        				{
		        					return false;
		        				}
		        				else return true;
		        			}
		        			else return true;
		        		}
		        		else
		        		{
		        			//if the cols are equal check the rows
		        			if (lastRogueLoc.row() < a.row())
			        		{
			        			//we know that it came from the top (row 0) going to the bottom (row N)
			        			if (b.row() > a.row())
			        			{
			        				//we need to check to see if there are plusses on either side of a
			        				//that is left and right since going up or down
			        				if (a.col() == 0) return true;
			        				if (a.col() == N - 1) return true;
			        				if (isWall(new Site(a.row(), a.col() - 1)) &&
			        					isWall(new Site(a.row(), a.col() + 1)))
			        				{
			        					return false;
			        				}
			        				else return true;
			        			}
			        			else return true;
			        		}
			        		else if (lastRogueLoc.row() > a.row())
			        		{
			        			//we know that it came from the bottom going to the top
			        			if (b.row() < a.row())
			        			{
			        				//we need to check to see if there are plusses on either side of a
			        				//that is left and right since going up or down
			        				if (a.col() == 0) return true;
			        				if (a.col() == N - 1) return true;
			        				if (isWall(new Site(a.row(), a.col() - 1)) &&
			        					isWall(new Site(a.row(), a.col() + 1)))
			        				{
			        					return false;
			        				}
			        				else return true;
			        			}
			        			else return true;
			        		}
			        		else return true;//should not happen
		        		}
	        		}
				}
			}
			else return false;
        }
        else return true;//should not make it here...
    }
    public boolean wallCheck(Site a, Site b, Site lastPartSite)
    {
    	boolean monsterMoving = true;
    	if (a.equals(game.getMonsterSite())) monsterMoving = true;
    	else if (a.equals(game.getRogueSite())) monsterMoving = false;
    	else return false;//failed initial condition
    	return wallCheck(a, b, lastPartSite, monsterMoving);
    }
    public boolean wallCheck(Site a, Site b)
    {
    	boolean monsterMoving = true;
    	Site lastPartSite = null;
    	if (a.equals(game.getMonsterSite()))
    	{
    		monsterMoving = true;
    		lastPartSite = game.getLastMonsterSite();
    	}
    	else if (a.equals(game.getRogueSite()))
    	{
    		monsterMoving = false;
    		lastPartSite = game.getLastRogueSite();
    	}
    	else return false;//failed initial condition
    	//System.out.println("a = " + a);
    	//System.out.println("b = " + b);
    	//System.out.println("lastPartSite = " + lastPartSite);
    	//System.out.println("monsterMoving = " + monsterMoving);
    	return wallCheck(a, b, lastPartSite, monsterMoving);
    }
    
    public boolean areBarriersAlongImmediatePathToRogue(Site rogue, Site monster)
    {
    	//check the preconditions if any are violated return true.
    	if (rogue == null || monster == null) return true;
    	else if (rogue.row() > N - 1 || rogue.col() > N - 1 || monster.col() > N - 1 ||
    		monster.row() > N - 1 || rogue.col() < 0 || rogue.row() < 0 ||
    		monster.col() < 0)
    	{
    		return true;
    	}
    	//else;//we know we are safe to move on
    	
    	int sxory = -1;
    	boolean add = false;
    	boolean moveAlongRow = true;
    	if (rogue.row() == monster.row() && rogue.col() == monster.col()) return false;//kill it
    	else if (rogue.row() == monster.row())
    	{
    		moveAlongRow = true;
    		
    		//we are moving on the cols
    		sxory = monster.col();
    		if (monster.col() > rogue.col()) add = false;
    		else add = true;
    	}
    	else if (rogue.col() == monster.col())
    	{
    		moveAlongRow = false;
    		
    		//we are moving on the rows
    		sxory = monster.row();
    		if (monster.row() > rogue.row()) add = false;
    		else add = true;
    	}
    	else return true;//violation of last precondition
    	//System.out.println("moveAlongRow = " + moveAlongRow);
    	
    	//if only rooms "." we are good -> false (always)
    	//if only walls "+" we are good -> false (DEPENDS)
    	//or a combination of the two -> false
    	//else return true
    	Site lastPartSite = null;//site before a
    	Site a = null;//a site after the lastPartSite both will be null on the first time the loop runs
    	boolean wallFound = false;
    	for (int v = sxory; v > -1 && v < N; v += 0)
    	{
    		if (moveAlongRow)
    		{
    			if (isInaccessible[monster.row()][v]) return true;
    			else if (isWall[monster.row()][v])
    			{
    				wallFound = true;
    				//a wall was found
    			}
    			else if (wallFound)
    			{
    				//if it is a wall to wall this is legal provided that
    				Site b = new Site(monster.row(), v);
    				if (wallCheck(a, b, lastPartSite, true) == false) return true;
    				wallFound = false;
    			}
    			//else;//do nothing
    			lastPartSite = a;
    			a = new Site(monster.row(), v);
    		}
    		else
    		{
    			if (isInaccessible[v][monster.col()]) return true;
    			else if (isWall[v][monster.col()])
    			{
    				wallFound = true;
    			}
    			else if (wallFound)
    			{
    				//a wall was found
    				//if it is a wall to wall this is legal provided that
    				Site b = new Site(v, monster.col());
    				if (wallCheck(a, b, lastPartSite, true) == false) return true;
    				wallFound = false;
    			}
    			//else;//do nothing
    			lastPartSite = a;
    			a = new Site(v, monster.col());
    		}
    		
    		//end of the for loop condition
    		if (add) v++;
    		else v--;
    	}//end of v for loop
    	
    	return false;
    }
    
    //this is a recursive method that can be used to calculate a path from the monster to the rogue
    private Site lastA = null;
    public boolean canPointAGetToPointB(Site a, Site b, boolean[][] visited)
    {
    	//System.out.println("INSIDE OF RECURSIVE METHOD!");
    	//System.out.println("a = " + a);
    	//System.out.println("b = " + b);
    	
    	//check for invalid data
    	if (!isSiteValidForAnNByNGridStartingAt0(a) || !isSiteValidForAnNByNGridStartingAt0(b)) return false;
    	if (isInaccessible(a) || isInaccessible(b)) return false;
    	if (isIsolated(a) == 1 || isIsolated(b) == 1) return false;
    	
    	//check for obvious a == b
    	if (a.equals(b)) return true;
    	
    	//check to see if they are neighbors
    	Site[] vANeighbors = getLegalMoves(a);
    	for(int i = 0; i < vANeighbors.length; i++)
    	{
    		if (vANeighbors[i].equals(b)) return true;
    	}//end of i for loop
    	
    	//check to see if both points are on a skinny path that goes (up and down) or (left and right)
    	//and that each point has at most 2 neighbors.
    	if (!areBarriersAlongImmediatePathToRogue(a, b)) return true;
    	
    	//System.out.println("Begin a 2nd recursive call!");
    	
    	//start setting up for the 2nd recursive call!
    	boolean[] keep = new boolean[vANeighbors.length];
    	for (int i = 0; i < vANeighbors.length; i++) keep[i] = true;
    	
    	int remCount = 0;
    	for (int i = 0; i < vANeighbors.length; i++)
    	{
    		//System.out.println("a = " + a);
    		//System.out.println("lastA = " + lastA);
    		//System.out.println("vANeighbors[" + i + "] = " + vANeighbors[i]);
    		//System.out.println("isWall(a) = " + isWall(a));
			//System.out.println("isWall(vANeighbors[i]) = " + isWall(vANeighbors[i]));
			if (wallCheck(a, vANeighbors[i], lastA, false))
			{
				//System.out.println("WALL CHECK SAID THAT WAS A LEGAL MOVE!");
				keep[i] = true;
			}
			else
			{
				keep[i] = false;
				//System.out.println("WALL CHECK SAID THAT THIS IS NOT LEGAL YET!");
				remCount++;
			}
    	}
    	
    	Site[] vWCNeighbors = new Site[vANeighbors.length - remCount];
    	int index =0;
    	for (int i = 0; i < vANeighbors.length; i++)
    	{
    		if (keep[i])
    		{
    			vWCNeighbors[index] = vANeighbors[i];
    			//System.out.println("vWCNeighbors[" + index + "] = " + vWCNeighbors[index]);
    			index++;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	
    	//visit part a before moving it and then calling method recursively
    	visited[a.row()][a.col()] = true;
    	
    	//initialize return value array to false
    	boolean[] retVal = new boolean[vWCNeighbors.length];
		for (int i = 0; i < retVal.length; i++) retVal[i] = false;
		
		//do the next move if not on a visited location
		for (int i = 0; i < retVal.length; i++)
		{
			if (visited[vWCNeighbors[i].row()][vWCNeighbors[i].col()]) retVal[i] = false;
			else
			{
				//System.out.println("i = " + i);
				//System.out.println("lastA = " + lastA);
	    		//System.out.println("a = " + a);
	    		//System.out.println("vWCNeighbors[" + i + "] = " + vWCNeighbors[i]);
				//System.out.println("BEFORE RECURSIVE CALL!");
				//we already know that the wall check was taken into account
				lastA = a;
				retVal[i] = canPointAGetToPointB(vWCNeighbors[i], b, visited);//recursive call here
				//System.out.println("AFTER RECURSIVE CALL!");
				//System.out.println("retVal[" + i + "] = " + retVal[i]);
				//System.out.println();
				
				//check to see if we are done
				if (retVal[i] == true) return true;
				//else;//do nothing
			}
		}//end of i for loop
		//System.out.println();
		
		//If the code makes it here, all spots were visited. So we need to find one that is NOT.
		//If we cannot find one that is not visited and valid to move to, return false.
		//else use recursion to test further from that new spot. The new spot must be next to
		//one that was visited.
		
		//find a visited spot, then check all around it to see if there is one that is not visited
		//if you found one not visited, check to make sure that you could move to it.
		//if you can, do so; if not, you cannot do that try to check to see if there are any more
		//if there are not, return false.
		for (int r = 0; r < N; r++)
		{
			for (int c = 0; c < N; c++)
			{
				if (visited[r][c])
				{
					//search around this one for one that is false
					//use row and col instead of r and c and search
					//in a square pattern
					int row = r - 1;
					int col = c - 1;
					if (row < 0) row = 0;
					if (col < 0) col = 0;
					
					boolean[] retVal2 = new boolean[9];
					for (int i = 0; i < retVal2.length; i++) retVal2[i] = false;
					
					int retIndex = 0;
					for (row = row; row < N && row > -1 && row < r + 2; row++)
					{
						col = c - 1;
						if (col < 0) col = 0;
						for (col = col; col < N && col > -1 && col < c + 2; col++)
						{
							if (!visited[row][col] && !isInaccessible[row][col])
							{
								//found a good spot to use
								//System.out.println("(" + row + ", " + col + ")");
								retVal2[retIndex] = canPointAGetToPointB(new Site(row, col),
									b, visited);//recursive call here
								
								//System.out.println("retVal2[" + retIndex + "] = " + retVal2[retIndex]);
								
								if (retVal2[retIndex] == true) return true;
								//else;//do nothing
							}
							else retVal2[retIndex] = false;
							
							retIndex++;
						}//end of col for loop
					}//end of row for loop
				}
				//else;//do nothing
			}//end of c for loop
		}//end of r for loop
		
		/*
		//print the visited grid
		for (int r = 0; r < N; r++)
		{
			for (int c = 0; c < N; c++)
			{
				if (r == b.row() && c == b.col()) System.out.print("B");
				else if (r == a.row() && c == a.col()) System.out.print("A");
				else
				{
					if (visited[r][c]) System.out.print("1");
					else System.out.print("0");
				}
			}//end of c for loop
			System.out.println();
		}//end of r for loop//*/
		
		return false;
    }
    public boolean canPointAGetToPointB(Site a, Site b)
    {
    	//System.out.println("a = " + a);
    	//System.out.println("b = " + b);
    	//System.out.println();
    	
    	//check for invalid data
    	if (a == null || b == null) return false;
    	if (a.row() < 0 || a.col() < 0 || b.row() < 0 || b.col() < 0 || a.row() > N - 1 ||
    		a.col() > N - 1 || b.row() > N - 1 || b.col() > N - 1) return false;
    	if (isInaccessible(a) || isInaccessible(b)) return false;
    	if (isIsolated(a) == 1 || isIsolated(b) == 1) return false;
    	
    	//check for obvious a == b
    	if (a.equals(b)) return true;
    	
    	//check to see if they are neighbors
    	Site[] aneighbors = getNeighbors(a);
    	for(int i = 0; i < aneighbors.length; i++)
    	{
    		if (aneighbors[i].equals(b)) return true;
    	}//end of i for loop
    	
    	//check to see if both points are on a skinny path that goes (up and down) or (left and right)
    	//and that each point has at most 2 neighbors.
    	if (!areBarriersAlongImmediatePathToRogue(a, b)) return true;
    	
    	//System.out.println("began recursive call!");
    	
    	//set up the visited grid
    	boolean[][] visited = new boolean[N][N];
    	for (int r = 0; r < N; r++) for (int c = 0; c < N; c++) visited[r][c] = false;
    	
    	//begin recursive call
    	return canPointAGetToPointB(a, b, visited);
    }
    
    public int[][] getAllCombinationsForRoomCycles(int roomNum)
    {
    	//min width = 2
    	//width = roomNum + 1
    	//String length = roomNum + 1
    	//duplicates = 2
    	//of allowed visits to the same room is: (if roomNum < 2) 0 else it is: roomNum - # duplicates
    	//we know the length of each string is roomNum + 1
    	//we know that the first and last number is fixed at the current count...
    	//NOT N^N but N^3 combos. 3 = roomNum - 1
    	int dials = 2;
    	if (roomNum < 1) dials = 0;
    	else if (roomNum == 1) dials = 2;
    	else dials = 4;
    	//System.out.println("dials = " + dials);
    	//total combos = roomNum to the power of strLen
    	int totalCombos = roomNum;
    	for (int n = 0; n < dials - 1; n++) totalCombos *= roomNum;
    	
    	int[][] combos = new int[totalCombos][roomNum];
    	//System.out.println("combos.length = " + combos.length);
    	//int room counter for each position
    	int[] roomCounters = new int[roomNum];
    	for (int n = 0; n < roomCounters.length; n++) roomCounters[n] = 0;
    	int rc = 0;//room counter
    	int si = roomNum - 2;//spot index
    	for (int i = 0; i < totalCombos; i++)
    	{
    		//System.out.println("i = " + i);
    		//System.out.println("i % roomNum == 0: " + (i % roomNum == 0));
    		//N=1 1^3=1
    		//11 (1)
    		//N=2 
    		//111 (the width changed over here to keep 2 duplicates and the other number)
    		//121
    		//212
    		//222 (4)
    		//N=3
    		//1111 (the width could have stayed the same here because of only 2 duplicates,
    		//1121 but we wanted to increase the number of duplicates to get the max combinations)
    		//1131
    		//1211
    		//1221
    		//1231
    		//1311
    		//1321
    		//1331 (9) ... 3^3=27
    		//
    		//N=4
    		//1111 (4^3 = 64)
			//^  ^ are the rc value
			//we just increment the rc if roomCounters[1] == roomNum and we reset the ones in the middle
			//to 1s.
			//1111
			//  ^ roomNum - 2 is the index for this. When the value is equal to the room num,
			//we need to reset this counter value to 1, decrement the spot index (si) and increment
			//this value. We also know that the value for roomNum - 2 will always increment.
			//If the spot index == 1 and the value of roomCounters[spot index] == roomNum,
			//do the above for the 1111 case.
			//1111
			//1121
			//1131
			//1141
			//THIS IS WHERE WE ENCOUNTER THE PROBLEM
			//we need to reset this counter
			//and increment the next spot to the left if roomCounter[spot index]
			//if the spot index == 0 we increment the starting and ending numbers
			//and reset all counters
			if (i == 0)
			{
				rc++;
    			//set all middle room counters to 1
    			for (int n = 1; n + 1 < roomNum; n++) roomCounters[n] = 1;
    			if (rc < 1) rc = 1;
    			roomCounters[0] = rc;
    			roomCounters[roomNum - 1] = rc;
			}
			else
			{
				//always increment roomCounters[roomNum - 2] unless it is equal to roomNum
				if (roomCounters[roomNum - 2] < roomNum) roomCounters[roomNum - 2] = roomCounters[roomNum - 2] + 1;
				else if (roomCounters[roomNum - 2] == roomNum)
				{
					//this counter needs to be reset to 1
					//roomCounters[roomNum - 2] = 1;
					//need to reset all indexes from si to (roomNum - 1) to 1
					//System.out.println("si = " + si);
					
					if (si > 1 && si < roomNum - 1)
					{
						if (si == roomNum - 2)
						{
							//we know that we need to increment the one next to this
							//and reset everything to the left
							//then decrement si
							for (int n = si; n > 0 && n < roomNum - 1; n++) roomCounters[n] = 1;
							si--;
							roomCounters[si] = roomCounters[si] + 1;
						}
						else break;
					}
					else if (si == 1)
					{
						//check to see if we can increment the roomCounter[si] then reset everycounter left of it
						if (roomCounters[si] < roomNum && roomCounters[si] > 0)
						{
							roomCounters[si] = roomCounters[si] + 1;
							for (int n = si + 1; n > 0 && n < roomNum - 1; n++) roomCounters[n] = 1;
						}
						else if (roomCounters[si] == roomNum)
						{
							//we need to increment the rc value and reset all counters to 1 except the first and
							//last one.
							
							si = roomNum - 2;
							if (rc < roomNum);//do nothing
							else break;
							rc++;
							if (rc < 1) rc = 1;
							//else;//do nothing
			    			//set all middle room counters to 1
			    			for (int n = 1; n + 1 < roomNum; n++) roomCounters[n] = 1;
			    			roomCounters[0] = rc;
			    			roomCounters[roomNum - 1] = rc;
						}
						else break;
					}
					else break;
					//we also need to increment the counter immediately to the left of this
					//the spot index also decrements.
				}
				else break;//invalid
			}
				
    		for (int n = 0; n < roomNum; n++) combos[i][n] = roomCounters[n];
    		
    		String str = "";
    		for (int n = 0; n < roomNum; n++) str += "" + roomCounters[n];
    		//System.out.println("str = " + str);
    	}//end of i for loop
    	return combos;
    }
    
    public boolean canVisitAllOfThePointsInsideARoom(int roomNum)
    {
    	if (roomNum < 1 || roomNum > getMaxPlatformNumber()) return false;
    	
    	Site[] locs = getListOfLocsInRoom(roomNum);
    	for (int i = 0; i < locs.length; i++)
    	{
    		Site a = locs[i];//this is the a
    		for (int k = 0; k < locs.length; k++)
    		{
    			if (k == i) continue;
    			Site b = locs[k];
    			if (!canPointAGetToPointB(a, b)) return false;
    		}//end of k for loop
    	}//end of i for loop
    	return true;
    }
    
    public boolean canVisitAllOfThePointsInsideAllRooms()
    {
    	int maxRoomNum = getMaxPlatformNumber();
    	if (maxRoomNum < 1) return false;
    	else
    	{
    		for (int n = 1; n < maxRoomNum; n++)
    		{
    			if (canVisitAllOfThePointsInsideARoom(n) == false) return false;
    		}//end of n for loop
    		return true;
    	} 
    }
    
    //method to check to see if there are cycles present NOT DONE YET 12-9-2017
    /*
    //NONE OF THESE METHODS WORK 12-9-2017
    private static int numRoomsVisited = 0;
    //DOES NOT WORK RIGHT PROBABLY NEEDS TO BE REWRITTEN. 12-8-2017
    public boolean canVisitARoomOtherThan(boolean canUseAnyPoint, int rnv, Site a,
    												Site b, boolean[] visitedPlatform)
    {
    	int maxRooms = getMaxPlatformNumber();
    	if (rnv == 0 || rnv > maxRooms) return false;
    	else if (rnv < 0 || rnv > 0 && rnv < maxRooms + 1);//do nothing valid
    	if (visitedPlatform == null) return false;
    	if (!isSiteValidForAnNByNGridStartingAt0(a)) return false;
    	if (!isSiteValidForAnNByNGridStartingAt0(b)) return false;
    	
    	//if rnv < 0, we are searching for a room other than ones that we have visited
    	//found inside of the array. The room number is 1 + index.
    	
    	//if we are at a junction site a becomes all of the valid neighbors from the current location
    	//if we are at a zero, direction is determined from a to b. B is the new location.
    	//b is the zero a will give us the direction
    	//use the valid neighbors of b to do this... we know the previous location
    	System.out.println("loc a = " + a);
    	System.out.println("loc b = " + b);
    	Site[] vbtemp = getLegalMoves(b, a, true);
    	boolean[] keep = new boolean[vbtemp.length];
    	int remCount = 0;
    	for (int n = 0; n < keep.length; n++)
    	{
    		System.out.println("vbtemp[n] = " + vbtemp[n]);
    		if (vbtemp[n].equals(a))
    		{
    			remCount++;
    			keep[n] = false;
    		}
    		else keep[n] = true;
    	}
    	Site[] vbneighbors = new Site[vbtemp.length - remCount];
    	System.out.println("vbneighbors.length = " + vbneighbors.length);
    	int mindex = 0;
    	for (int n = 0; n < keep.length; n++)
    	{
    		if (keep[n])
    		{
    			System.out.println("vbtemp[n] = " + vbtemp[n]);
    			vbneighbors[mindex] = vbtemp[n];
    			mindex++;
    		}
    		//else;//do nothing
    	}//end of n for loop
    	
    	//check to see if the vbneighbors have a room number other than what we did not want to find
    	//or other than what we have already found.
    	for (int i = 0; i < vbneighbors.length; i++)
    	{
    		Site loc = vbneighbors[i];
    		if (areaNum[loc.row()][loc.col()] == 0);
    		else if (areaNum[loc.row()][loc.col()] == rnv && rnv > 0);//do nothing
    		else if (rnv < 1)
    		{
    			boolean foundNum = false;
    			for (int n = 0; n < visitedPlatform.length; n++)
    			{
    				if (visitedPlatform[n] == false)
    				{
    					if (areaNum[loc.row()][loc.col()] == n + 1)
    					{
    						visitedPlatform[n] = true;
    						return true;
    					}
    				}
    			}//end of n for loop
    		}
    	}//end of i for loop
    	
    	boolean[] retVals = new boolean[vbneighbors.length];
    	for (int n = 0; n < retVals.length; n++) retVals[n] = false;
    	for (int n = 0; n < retVals.length; n++)
    	{
    		retVals[n] = canVisitARoomOtherThan(canUseAnyPoint, rnv, b, vbneighbors[n], visitedPlatform);
    		if (retVals[n] == true) return true;
    	}//end of n for loop
    	
    	//if we can use any point this makes it really easy
    	return false;
    }
    public boolean canVisitAllOfTheRooms(boolean canUseAnyPoint, int srn, boolean[] visitedPlatform)
    {
    	int maxRooms = getMaxPlatformNumber();
    	if (srn < 1 || srn > maxRooms) return false;
    	if (visitedPlatform == null) return false;
    	
    	//if we can choose any point, we simply need to find one of each room number
    	//else we need to see mainly if we can get to all of them if we can't just try to get to
    	//the points that are connected to 0s
    	//mark all of the rooms visited, we start in room 1
    	//we search for 0s connecting to the room, then start with those points we are trying to
    	//find a room that is not this one.
    	
    	//find the first site inside the room and use it
    	//then search for zeros that are attached to the room
    	//example:
    	//000-1
    	//-1110
    	//0110
    	//we look all over for 0s leading into a 1
    	//we will just use the first point found in the room to avoid any confusion
    	Site ss = null;
    	boolean breakOuter = false;
    	for (int r = 0; r < N; r++)
    	{
    		if (breakOuter == true) break;
    		for (int c = 0; c < N; c++)
    		{
    			if (areaNum[r][c] == srn)
    			{
    				ss = new Site(r, c);
    				breakOuter = true;
    				break;
    			}
    		}
    	}
    	
    	//mark current room number as visited
    	visitedPlatform[srn - 1] = true;
    	
    	//we are now looking for 0s next to the current room number
    	for (int r = 0; r < N && r > -1; r++)
    	{
    		for (int c = 0; c < N && c > -1; c++)
    		{
    			if (areaNum[r][c] == 0)
    			{
    				System.out.println("found a zero!");
    				System.out.println("r = " + r);
    				System.out.println("c = " + c);
    				//directions are (1) up (r - 1); (0) down (r + 1); (1) right (c + 1); (0) left (c - 1)
    				if (c > 1 && areaNum[r][c - 1] == srn)
    				{
    					//we have found a zero that we need to check to see where it goes
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r, c - 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (c + 1 < N && areaNum[r][c + 1] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r, c + 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (r > 0 && c > 0 && areaNum[r - 1][c - 1] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r - 1, c - 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (r > 0 && areaNum[r - 1][c] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r - 1, c),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (r > 0 && c + 1 < N && areaNum[r - 1][c + 1] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r - 1, c + 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (c > 0 && r + 1 < N && areaNum[r + 1][c - 1] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r + 1, c - 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (r + 1 < N && areaNum[r + 1][c] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r + 1, c),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				else if (r + 1 < N && c + 1 < N && areaNum[r + 1][c + 1] == srn)
    				{
    					System.out.println("we need to see where this goes");
    					if (!canVisitARoomOtherThan(canUseAnyPoint, srn, new Site(r + 1, c + 1),
    						new Site(r, c), visitedPlatform));
    					else return true;
    				}
    				//else;//do nothing
    			}
    		}
    	}
    	return false;
    }
    
    public boolean visitAsManyRoomsAsPossible()
    {
    	int maxNumPlatforms = getMaxPlatformNumber();
		if (maxNumPlatforms < 2) return true;//no rooms to visit or only one
		boolean visitedPlatform[] = new boolean[maxNumPlatforms];
		
		boolean visitAllPointsInAllRooms = canVisitAllOfThePointsInsideAllRooms();
		//if the above is true, it doesn't matter on point choice else it does.
		
		//visiting pattern find a zero on the room and attempt to follow the path it
		//has if you can visit a room, mark the room as visited
		//if you come to a junction of many rooms split and try again
		return false;
    }
    
    public boolean canVisitAllOfTheRooms()
	{
		//first get the max number of rooms
		int maxNumPlatforms = getMaxPlatformNumber();
		if (maxNumPlatforms < 2) return true;//no rooms to visit or only one
		boolean[] visitedPlatform = new boolean[maxNumPlatforms];
		//pick a random location in all of the rooms
		//if a location is totally isolated or cannot be reached, return false
		//we know that this is false, but we need to skip this one and start with one we can visit
		//and see if we can visit another one we need to check for any order.
		
		//first go through each room and check to see if when inside that room,
		//we can visit all of the points in all of the rooms, we simply need to check to see if we can visit
		//the rooms mark the ones that we have visited then see which combos are valid for cycles.
		boolean visitAllPointsInAllRooms = canVisitAllOfThePointsInsideAllRooms();
		//if the above is true, it doesn't matter on point choice else it does.
		boolean vallrs = canVisitAllOfTheRooms(visitAllPointsInAllRooms, 1, visitedPlatform);
		
		//at the end before the return statements
		for (int i = 0; i < visitedPlatform.length; i++) if (visitedPlatform[i]) numRoomsVisited++;
		return (numRoomsVisited == visitedPlatform.length);
	}
	public boolean isAtLeastOneCyclePresent()
	{
		int maxPlatformNum = getMaxPlatformNumber();
		if (maxPlatformNum == 1) return true;
		else if (maxPlatformNum < 1) return false;
		else
		{
			//if there is a spot in one of the rooms and the numbers that are surrounding it
			//are all the same... not truely isolated but no other location can break in, then we have
			//a cycle in its own right inside of a room it's like we have two different platforms on the
			//same one.
			//
			//HERE IS AN example of the same platform, but divided into two sections to check to see if
			//this is isolated from the other one, use the canPointAGetToPointB(Site a, Site b) and pass
			//in one in the middle and one outside:
			//
			//... To write the check for the points inside of a room first, if it is in the room we choose
			//+++ a starting point and then we work accross the row looking to see if we can get to all of
			//+.+ the points down the cols. If we can't, then we know that there are two sections. We know
			//+.+ that if at any points where that is false, we have a cycle for that room only if the
			//+++ rogue or monster is inside the section that it can't get out of.
			//
			//if one room is totally isolated, then it itself is a cycle.
			//..  THIS example will yield to the obvious isolation test
			//..  if it isn't first found of as a room that you can't get
			//    to.
			// . 
			//   
			//if we can visit all of the rooms, then this is true.
			//if we can't: 4 rooms and 1,2,3,1 exists a cycle exists
			//we need to check for this...
			//
			//a cycle is defined as visiting 2 or more rooms and being able to move between them
			//1,2,1; 1,2,3,4,1; 1,2,4,3,1; unless there is only one room present
			//
			//for getting a cycle return list of rooms in the order that produces a cycle
			//we need to check for all possible combinations that only use one
			//for N rooms, we may only visit: length each word = N + 1;
			//for N = 2:
			//111,121,212,222 = 2^2 -> 4
			//for N = 3:
			//1111,1121,1131, (3^2) for each number -> N^N combos
			//1211,1221,1231,
			//1311,1321,1331, (9) -> 3*(3^2)=3^3=27
			//2112,2122,2132,
			//2212,2222,2232,
			//2312,2322,2332, (9)
			//3113,3123,3123,
			//3133,3213,3223,
			//3313,3323,3333. (9)
			//
			//if it starts with a 1 it must end with the 1 in the last slot; therefore, there are 3 spots that can
			//change
			
			//we need to check to see if we can get to any point in a room from any other point
			//then we need to see if we can get to that room
			boolean visitAllPointsInAllRooms = canVisitAllOfThePointsInsideAllRooms();
			if (visitAllPointsInAllRooms == false) return true;
			
			
		}
		return false;
	}
    //*/
    
    // does v-w correspond to a legal move?
    public boolean isLegalMove(Site v, Site w) {
        //pre-condition was not checked
        if (v == null || w == null) return false;
        
        int i1 = v.i();
        int j1 = v.j();
        int i2 = w.i();
        int j2 = w.j();
        //check if the locations are valid for our purposes first
        if (i1 < 0 || j1 < 0 || i1 >= N || j1 >= N) return false;
        if (i2 < 0 || j2 < 0 || i2 >= N || j2 >= N) return false;
        //check if we aren't allowed to move there at all
        if (isInaccessible(v) || isInaccessible(w)) return false;
        //do a distance check here
        if (Math.abs(i1 - i2) > 1)  return false;
        if (Math.abs(j1 - j2) > 1)  return false;
        //are they both rooms and are they next to each other
        if (isRoom(v) && isRoom(w)) return true;
        //the do nothing move is valid
        if (v.equals(w)) return true;
        
        //if (i1 == i2) return true;
        //if (j1 == j2) return true;
        
        //check if we are trying to cross a wall from a previous location
        
        //if v is a wall and w is the monster or the rogue's location just outside of the wall
        //return TRUE; if v is a wall and game.getMonsterSite() is equal to v and w is a room
        //or wall as well (we know that it is accessible because it made it this far in the
        //method) w may also be equal to rogue's location, then return FALSE because the monster
        //tried to cross through the wall.
        
        //v is the site we are moving from; w is the site we are moving to.
        if (wallCheck(v, w)) return true;
        else return false;
    }
    
    //the default for the monsterMoving is that the monster is moving
    //you are moving from a to b and lastASite was the location before a
    //the last two pieces of information are only needed for a wall check
    public Site[] getLegalMoves(Site a, Site b, Site lastASite, boolean monsterMoving)
    {
    	if (a == null || b == null) return null;
    	Site[] neighbors = getNeighbors(a);
    	boolean canMoveToB = false;
    	for (int i = 0; i < neighbors.length; i++)
    	{
    		if (neighbors[i].equals(b))
    		{
    			canMoveToB = true;
    			break;
    		}
    	}//end of i for loop
    	if (canMoveToB == false) return null;
    	
    	if (isLegalMoveNoWallCheck(a, b))
    	{
    		//need to do a wall check from a to all of the neighbors
    		//we want to move to part b as a next move
    		Site[] temp = getNeighbors(a);
    		boolean[] keep = new boolean[temp.length];
    		for (int i = 0; i < keep.length; i++) keep[i] = true;//want to keep all of them
    		
    		if (isSiteValidForAnNByNGridStartingAt0(lastASite) == false) return temp;
    		
    		//we know that lastASite was one of the neighbors
    		boolean lastSiteAIsValid = false;
	    	for (int i = 0; i < neighbors.length; i++)
	    	{
	    		if (neighbors[i].equals(lastASite))
	    		{
	    			lastSiteAIsValid = true;
	    			break;
	    		}
	    	}//end of i for loop
	    	if (lastSiteAIsValid == false) return temp;
    		
    		int remCount = 0;
    		for (int i = 0; i < temp.length; i++)
    		{
    			//need to use a separate wall check
    			//for the neighbors and a so a is moving to a neighbor instead of b
    			Site loc = temp[i];
    			if (loc.equals(lastASite))
    			{
    				keep[i] = false;
    				remCount++;
    			}
    			else if (wallCheck(a, loc, lastASite, monsterMoving)) keep[i] = true;
    			else
    			{
    				keep[i] = false;
    				remCount++;
    			}
    		}//end of i for loop
    		
    		Site[] retVals = new Site[temp.length - remCount];
    		int index = 0;
    		for (int i = 0; i < temp.length; i++)
    		{
    			if (keep[i])
    			{
    				retVals[index] = temp[i];
    				index++;
    			}
    			//else;//do nothing
    		}//end of i for loop
    		return retVals;
    	}
    	else return null;//not legal
    }
    public Site[] getLegalMoves(Site a, Site b, Site lastASite)
    {
    	return getLegalMoves(a, b, lastASite, true);
    }
    //this method does a wall check only on the neighbors
    public Site[] getLegalMoves(Site a, Site lastASite, boolean monsterMoving)
    {
    	if (a == null || lastASite == null) return null;
    	Site[] validMoveLocs = getLegalMoves(a);
    	boolean[] keep = new boolean[validMoveLocs.length];
    	int remCount = 0;
    	for (int i = 0; i < validMoveLocs.length; i++)
    	{
    		Site b = validMoveLocs[i];
    		if (wallCheck(a, b, lastASite, monsterMoving)) keep[i] = true;
    		else
    		{
    			keep[i] = false;
    			remCount++;
    		}
    	}//end of i for loop
    	Site[] retVals = new Site[validMoveLocs.length - remCount];
    	int index = 0;
    	for (int i = 0; i < validMoveLocs.length; i++)
    	{
    		if (index < retVals.length);
    		else break;
    		
    		if (keep[i])
    		{
    			retVals[index] = validMoveLocs[i];
    			index++;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return retVals;
    }
}
