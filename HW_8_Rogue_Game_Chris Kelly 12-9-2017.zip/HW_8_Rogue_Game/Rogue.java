/*************************************************************************
 *  Compilation:  javac Rogue.java
 * 
 *************************************************************************/

//package HW_8_Rogue_Game;
public class Rogue {
    private Game game = null;
    private Dungeon dungeon = null;
    private int N = 0;
    private static java.util.Random random = new java.util.Random();

    // constructor - save away some useful information
    public Rogue(Game game) {
        this.game    = game;
        this.dungeon = game.getDungeon();
        this.N       = dungeon.size();
    }

	// TAKE A RANDOM LEGAL MOVE
    public Site makeRandomMove()
    {
    	Site monster = game.getMonsterSite();
        Site rogue   = game.getRogueSite();
        Site move    = null;

        // take random legal move
        /*
        int n = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Site site = new Site(i, j);
                if (dungeon.isLegalMove(rogue, site))
                {
                    n++;
                    if (Math.random() <= 1.0 / n) move = site;
                }
            }
        }//*/
        Site[] lrms = dungeon.getLegalMoves(rogue, game.getLastRogueSite(), true);
        if (lrms == null) lrms = dungeon.getLegalMoves(rogue);
        if (lrms.length > 0)
        {
        	int n = 0;
        	//pick a random number from 0 to length - 1
        	n = random.nextInt(lrms.length - 0) + 0;
        	move = lrms[n];
        	//System.out.println("move = " + move);
        	return move;
        }
        else return rogue;
        //return move;
    }
    
    // NOT DONE YET 12-9-2017
    // TAKE A RANDOM LEGAL MOVE
    // YOUR MAIN TASK IS TO RE-IMPLEMENT THIS METHOD TO DO SOMETHING INTELLIGENT
    public Site move() {
        Site monster = game.getMonsterSite();
        Site rogue   = game.getRogueSite();
        Site move    = null;
		
		//if the rogue is isolated, do nothing
		//if the monster is isolated, make a random move because the rogue won
		//if the monster is close to the rogue, move away from the monster
		//close => manhattan distance of 2 or less
		//if the rogue can move diagnal and keep mandistance of 2 or increase it,
		//do it.
		//rogue should move diagnal away from monster if monster is in a manhattan
		//distance of N / 4 if N < 8, then not applicable.
		//
		//need to do something here...
		if (dungeon.isIsolated(monster) == 1) return makeRandomMove();
		else if (dungeon.isAbsolutelyIsolated(rogue)) return rogue;
		else
		{
			if (monster.manhattanTo(rogue) < 5 && N > 3)
			{
				Site[] lms = dungeon.getLegalMoves(rogue, game.getLastRogueSite(), false);
				if (monster.row() > rogue.row())
				{
					//monster is below the rogue
					if (monster.col() < rogue.col())
					{
						//monster is to the left of the rogue
						//monster will move up and right
						//rogue needs to move up and right
						//.@.
						//...
						//M..
						//get a neighbor of the rogue that is a valid move spot up
						//and to the right or to the left or straight up and for
						//the wall check plug in the rogue's last location
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() < rogue.row() && s.col() > rogue.col()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
					else if (monster.col() > rogue.col())
					{
						//monster is to the right of the rogue
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() < rogue.row() && s.col() < rogue.col()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
					else
					{
						//monster is directly below the rogue
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() < rogue.row()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
				}
				else if (monster.row() < rogue.row())
				{
					//monster is above the rogue
					if (monster.col() < rogue.col())
					{
						//monster is to the left of the rogue
						//monster will move up and right
						//rogue needs to move up and right
						//.@.
						//...
						//M..
						//get a neighbor of the rogue that is a valid move spot up
						//and to the right or to the left or straight up and for
						//the wall check plug in the rogue's last location
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() > rogue.row() && s.col() > rogue.col()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
					else if (monster.col() > rogue.col())
					{
						//monster is to the right of the rogue
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() > rogue.row() && s.col() < rogue.col()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
					else
					{
						//monster is directly below the rogue
						for (int i = 0; i < lms.length; i++)
						{
							Site s = lms[i];
							if (s.row() > rogue.row()) return s;
						}//end of i for loop
						return makeRandomMove();
					}
				}
				else
				{
					//monster is on the same row as the rogue
					//run a barrier check first...
					if (dungeon.areBarriersAlongImmediatePathToRogue(rogue, monster))
					{
						//make a random move
						return makeRandomMove();
					}
					else
					{
						//try to move down and away from the monster
						if (rogue.row() > N / 2)
						{
							//move up and to the right
							if (monster.col() < rogue.col())
							{
								//monster moves to the right
								//rogue moves to the right
								for (int i = 0; i < lms.length; i++)
								{
									Site s = lms[i];
									if (s.row() < rogue.row() && s.col() > rogue.col()) return s;
								}//end of i for loop
								return makeRandomMove();
							}
							else
							{
								//monster moves to the left
								//rogue moves to the left
								for (int i = 0; i < lms.length; i++)
								{
									Site s = lms[i];
									if (s.row() < rogue.row() && s.col() < rogue.col()) return s;
								}//end of i for loop
								return makeRandomMove();
							}
						}
						else
						{
							//move down and to the right
							if (monster.col() > rogue.col())
							{
								//monster moves to the left
								//rogue needs to move to the left
								for (int i = 0; i < lms.length; i++)
								{
									Site s = lms[i];
									if (s.row() > rogue.row() && s.col() < rogue.col()) return s;
								}//end of i for loop
								return makeRandomMove();
							}
							else
							{
								//monster moves to the right
								//rogue moves to the right
								for (int i = 0; i < lms.length; i++)
								{
									Site s = lms[i];
									if (s.row() > rogue.row() && s.col() > rogue.col()) return s;
								}//end of i for loop
								return makeRandomMove();
							}
						}
					}
				}
			}
			
			//find cycles in the area
			//a cycle allows the rogue to move from section to section
			//if there are no cycles, then try to stay away from monster:
			//if the monster takes one step towards you try to move in the
			//same direction as the monster.
			return makeRandomMove();
		}
		
        // take random legal move
        /*int n = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Site site = new Site(i, j);
                if (dungeon.isLegalMove(rogue, site))
                {
                    n++;
                    if (Math.random() <= 1.0 / n) move = site;
                }
            }
        }
        move = makeRandomMove();
        return move;//*/
    }

}
