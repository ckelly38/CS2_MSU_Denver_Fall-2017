/******************************************************************************
 *  readme.txt template                                                   
 *  Rogue
**********************************************************************/

Name: Chris Kelly
NetID:
Precept:
OS: Windows 10
Compiler: Java 1.7.0_21
Text editor: JCreator (IDE) and Notepad (Text Editor), Command Prompt and
 jar.exe and java.exe for creation and execution of the new jar file. 
Hours to complete assignment (optional):



/******************************************************************************
 *  Describe your monster's strategy for intercepting the rogue.
 *****************************************************************************/

-If the Manhattan distance to the rogue is 1, kill the rogue.
else check to see if the rogue is isolated (unreachable). If the dungeon starts
with the rogue being unreachable, then the game immediately ends with the rogue
winning.
-The monster should try to move diagnal to the rogue when possible unless there
is a direct path to the rogue on a straight line.
-Generate a path to the rogue using recursion and methods similar to the
canPointAGetToPointB(Site a, Site b) method. Only the new method would return
a list of locations.

/******************************************************************************
 *  Are there any dungeons (supplied by us, or created by you)
 *  where the monster does not intercept the rogue even though
 *  with an optimal strategy it would? If so, try to describe
 *  why it doesn't work?
 *****************************************************************************/

-If they were completely separated by walls (blank spaces). IE always in two
different rooms. If the above were the case, no matter what strategy the
monster used, the monster NEVER could get to the rogue.
-???

/******************************************************************************
 *  Describe your rogue's strategy for evading the monster.
 *****************************************************************************/

-Start in a location that is completely isolated from the monster OR have the
monster start in a location that is completely isolated from the rogue. If
that is the case, automatically end the game with the rogue winning.
-If this is not the case, try to move away from the rogue unless pinned. (NOT WRITTEN YET)
-If the rogue can identify a cycle in the board, IE a path from room to room
and back again. Like: A CAT is an ANIMAL an animal can be a FELINE, and a
feline is a CAT. (NOT WRITTEN YET)

/******************************************************************************
 *  Are there any dungeons (supplied by us, or created by you)
 *  where the rogue does not evade the monster for as long as
 *  possible? If so, try to describe why it doesn't.
 *****************************************************************************/

-If I said that the rogue was already caught (for a 1*1 this is the only valid
board).
-If the dungeon was really small (at least a 2*2).
-If there were more than one monster after the rogue (NOT A VALID BOARD).
-If there were more than one rogue after the monster (monster could catch either
and win-NOT A VALID BOARD)
-If the rogue started out cornered.

/******************************************************************************
 *  Give the worst case asymptotic running time *per move* of your two
 *  algorithms as a function of the dungeon dimension N, e.g., N^2.
 *****************************************************************************/

N^4 is the worst case running time for both, because if the monster does NOT
get the rogue in this time, I just end the game to stop the infinite loop.

Monster: N^4
Rogue: N^4


/******************************************************************************
 *  Known bugs / limitations.
 *****************************************************************************/

INITIAL "BUGS" FIXED:
-No validator present and some pre-conditions on certain methods were NEVER
checked for example a site is null that you were trying to move to.
-The dungeon class did not check NOR note if a certain spot was not valid for
both pieces to be on.
-The dungeon class did not note that a certain spot was unreachable for the
other piece.
-Reading a file method OR having the user enter a dungeon did NOT check if the
dungeon was valid. This did not check to see if there were more than one rogue
and more than one monster. If either did not exist, the board was invalid...
-Infinite loop for a dungeon where the rogue was unreachable to the monster.
-Randomly moving to a location did not check if it was doing nothing.
-In the Site class, there was no note as to what was the row and what was the
col. I added my own methods row() and col() for my own sanity.
-In the Site class, I added a toString() method as this is needed for printing
objects.
-Some text files as boards that were given had other hidden returns that could
NOT be seen in Notepad for Windows. I did my best to remove those files.
-Rogue and monster make random legal move could return null which is not a
legal move. I fixed this by picking a move randomly from a list of legal
moves that were generated based on its position and/or last position.

OTHER "KNOWN" BUGS NOT FIXED OR ADDRESSED BECAUSE THE ABOVE HAD TO BE FIRST:
-Possible bug in the wallCheck(Site a, Site b, Site lastPartSite,
boolean monsterMoving); method causing the getLegalMoves methods to fail.
It may or may not work all of the time. THUS ANY METHOD DEPENDING ON IT MAY FAIL.
-Not enough time to determine where the nearest corridor was that was
farthest from the monster and closest to the rogue.
-Not enough time to determine if there were cycles in the grid and to get the
path. NOTE: THESE METHODS ARE COMMENTED BECAUSE THEY WERE NOT FINISHED AND
DID NOT WORK WELL AT ALL.
-Not enough time to generate a direct path from the rogue to the monster or
vise-versus. NOT STARTED AT ALL.

/******************************************************************************
 *  List whatever help (if any) that you received.
 *****************************************************************************/

Jar File Notes: Chris Kelly 11-30-2017

TO CREATE A JAR FILE:
A JAR FILE Must have a manifest file:

Manifest-Version: 1.0
Created-By: 1.7.0_21 (Chris Kelly and Dr. Blanche Cohen)
Class-Path: HW_8_Rogue_Game.jar
Main-Class: Game

Manifest-Version: 1.0  (number) is required.
Created-By: jdk version (Author name in a comment)
The version of jdk is required. Author is optional.
By default, the first two options are required.
Class-Path is optional when there is only one jar file, but
it becomes required when there are more than 1.
Main-Class: class name.
This is required when you have more than one class.

SENDING THE MAKE A JAR FILE COMMAND TO THE APPLICATION:
Command to create a simple jar file with:
-Commands are all on one line
-a custom manifest
-allows the user to name the jar file
-and the -C changes the directory to the one with the files
and then that adds the files in it
-all program names in the basic format of the command written out
needs the path to that program in the command as well. This is
why I gave you the form, and then an example that worked for me.
-File paths and program paths will differ for every user.

jar.exe cvfm program.jar manifest.txt -C directory files

"C:\Program Files\Java\jdk1.7.0_21\bin\jar.exe" cvfm
"E:\CS2 Fall 2017 MSU_Denver\HW_8_Rogue_Game\HW_8_Rogue_Game.jar"
"E:\CS2 Fall 2017 MSU_Denver\HW_8_Rogue_Game\manifest.txt"
-C "E:\CS2 Fall 2017 MSU_Denver\HW_8_Rogue_Game"
Game.class In.class Monster.class Rogue.class Dungeon.class Site.class

EXECUTION COMMAND FOR THE JAR FILE AND LAUNCHING OF THE JAR FILES:
Command to execute the jar file:

java.exe -jar jarfilename.jar

"C:\Program Files\Java\jdk1.7.0_21\bin\java.exe" -jar
"E:\CS2 Fall 2017 MSU_Denver\HW_8_Rogue_Game\HW_8_Rogue_Game.jar"

If you try to execute the jar file without the -jar option on it,
it will give you an "Error: Could not find or load main class your_jar_file.jar".

/******************************************************************************
 *  Describe any serious problems you encountered.                    
 *****************************************************************************/

SEE LIST OF INITIAL BUG FIXES;
-Some text files as boards that were given had other hidden returns that could
NOT be seen in Notepad for Windows. I removed them from those in the files.

/******************************************************************************
 *  List any other comments here. Feel free to provide any feedback   
 *  on how much you learned from doing the assignment, and whether    
 *  you enjoyed doing it.                                             
 *****************************************************************************/
