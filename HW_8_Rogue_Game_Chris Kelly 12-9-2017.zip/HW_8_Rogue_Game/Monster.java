/*************************************************************************
 *  Compilation:  javac Monster.java
 * 
 *************************************************************************/

//package HW_8_Rogue_Game;
public class Monster {
    private Game game;
    private Dungeon dungeon;
    private int N;
    private static java.util.Random random = new java.util.Random();

    // constructor - save away some useful information
    public Monster(Game game) {
        this.game    = game;
        this.dungeon = game.getDungeon();
        this.N       = dungeon.size();
    }
	
	// TAKE A RANDOM LEGAL MOVE
	public Site makeRandomMove()
	{
		Site monster = game.getMonsterSite();
        Site rogue   = game.getRogueSite();
        Site move    = null;

        // take random legal move
        /*int n = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Site site = new Site(i, j);
                if (site.equals(monster));
                else
                {
                	if (dungeon.isLegalMove(monster, site)) {
	                    n++;
	                    if (Math.random() <= 1.0 / n) move = site;
	                }
                }
            }
        }//*/
        
        Site[] lrms = dungeon.getLegalMoves(monster, game.getLastMonsterSite(), true);
        if (lrms == null) lrms = dungeon.getLegalMoves(monster);
        if (lrms.length > 0)
        {
        	int n = 0;
        	//pick a random number from 0 to length - 1
        	n = random.nextInt(lrms.length - 0) + 0;
        	move = lrms[n];
        	//System.out.println("move = " + move);
        	return move;
        }
        else return monster;
        //return move;
	}

    // NOT DONE YET 12-9-2017
    // YOUR MAIN TASK IS TO RE-IMPLEMENT THIS METHOD TO DO SOMETHING INTELLIGENT
    public Site move() {
        Site monster = game.getMonsterSite();
        Site rogue   = game.getRogueSite();
        Site move    = null;
		
		//get the manhatton distance to the the rogue
		//nothing can move onto the blanks.
		int manDistance = monster.manhattanTo(rogue);
		//System.out.println("manDistance = " + manDistance);
		//System.out.println("monster = " + monster);
		//System.out.println("rogue = " + rogue);
		
		//check to see if the rogue is isolated (1) or semi-isolated (-1)
		//if rogue is isolated, make a random move wait for it to not be isolated.
		//if the rogue is semi-isolated, try to pin it down.
		//if the rogue is not isolated (0), then calculate the manhatton distance
		//and move on that path. 
		if (dungeon.isIsolated(rogue) == 1) return makeRandomMove();
		else if (manDistance == 1)
		{
			if (dungeon.wallCheck(monster, rogue, game.getLastMonsterSite(), true)) return rogue;
			else return makeRandomMove();
		}
		else if (rogue.row() == monster.row() && monster.col() == rogue.col()) return monster;//do nothing
		else if (rogue.row() == monster.row() || monster.col() == rogue.col())
		{
			//check to see if there are any barriers along the immediate path,
			//if all rooms "." or walls "+", no
			//else yes.
			//if there are not, then move along the same path,
			//else make a random move.
			if (dungeon.areBarriersAlongImmediatePathToRogue(rogue, monster))
			{
				//we know that we could be almost-isolated here if the rogue is, then we need to
				//find a path to the rogue
				///*
				Site[] rogueNeighbors = dungeon.getNeighbors(rogue);
				if (dungeon.isSkinnyPath(rogue))
				{
					//we need to know if the path only moves in one column or only in one row
					//then if this is the case (for most of the path) move in the direction of
					//the path away from the rogue (unless on the path, then move toward rogue).
					//
					//we know this is a skinny path
					//
					Site s = null;
					if (rogue.row() == monster.row())
					{
						if (rogue.col() < monster.col()) s = new Site(monster.row(), monster.col() - 1);
						else s = new Site(monster.row(), monster.col() + 1);
					}
					else
					{
						//if (monster.col() == rogue.col())
						if (rogue.row() < monster.row()) s = new Site(monster.row() - 1, monster.col());
						else s = new Site(monster.row() + 1, monster.col());
					}
					//check to see if this is the dead end and kind of if this move is legal
					if (dungeon.isInaccessible(s))
					{
						//calculate a path to the rogue and take one step on that path...
						//do nothing for the moment.
						s = makeRandomMove();
					}
					else return makeRandomMove();
					return s;
				}
				else return makeRandomMove();//*/
			}
			else
			{
				//move along that path
				Site s = null;
				if (monster.row() == rogue.row())
				{
					//new location has monster.row() in it
					if (monster.col() > rogue.col())
					{
						s = new Site(monster.row(), monster.col() - 1);
					}
					else
					{
						s = new Site(monster.row(), monster.col() + 1);
					}
				}
				else
				{
					//monster.col() == rogue.col()
					//new location has monster.row() in it
					if (monster.row() > rogue.row())
					{
						s = new Site(monster.row() - 1, monster.col());
					}
					else
					{
						s = new Site(monster.row() + 1, monster.col());
					}
				}
				return s;
			}
		}
		else if (dungeon.isIsolated(rogue) == -1)
		{
			//the rogue is semi-isolated. We need to find the closest semi-isolated
			//spot to the monster and the rogue. This must be along the manhattan
			//distance.
			//If a barrier is immediately between the rogue and the monster, then
			//the monster moves away from that (in a diagnal direction if possible).
			//
			//try to calculate a path to the rogue.
			
			Site[] rogueNeighbors = dungeon.getNeighbors(rogue);
			if (rogueNeighbors.length > 0 && rogueNeighbors.length < 4)
			{
				//3 for 3 other spots
				//we know that this one is really almost isolated
				//we really need to know if this connects to an area with almost all of the neighbors
				//or all of them
				
			}
			
			//don't know what to do here yet...
			return makeRandomMove();
		}
		else
		{
			//not isolated, not semi-isolated
			//need to do something here
		}
		
        // take random legal move
        int n = 0;
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Site site = new Site(i, j);
                if (site.equals(monster));
                else
                {
                	if (dungeon.isLegalMove(monster, site)) {
	                    n++;
	                    if (Math.random() <= 1.0 / n) move = site;
	                }
                }
            }
        }
        move = makeRandomMove();
        //System.out.println("move = " + move);
        return move;
    }

}
