/*************************************************************************
 *  Compilation:  javac Site.java
 *
 *  simple data type for an (i, j) site = (r, c) site = (row, column)
 *
 *************************************************************************/

//package HW_8_Rogue_Game;
public class Site {
    private int i;//row
    private int j;//col

    //intitialize the Site object
    public Site(int i, int j) {
        this.i = i;//row
        this.j = j;//col
    }

    public int i() { return i; }
    public int j() { return j; }
    public int row() { return i; }
    public int col() { return j; }

    // Manhattan distance between invoking Site and w
    public int manhattanTo(Site w) {
        if (w == null) return -1;//error
        Site v = this;
        int i1 = v.i();
        int j1 = v.j();
        int i2 = w.i();
        int j2 = w.j();
        return Math.abs(i1 - i2) + Math.abs(j1 - j2);
    }
	
    // does invoking site equal site w?
    public boolean equals(Site w) {
        if (w == null) return false;
        else return (manhattanTo(w) == 0);
    }
	
	//for printing out objects
	public String toString()
	{
		return "(" + row() + ", " + col() + ")";
	}
}
