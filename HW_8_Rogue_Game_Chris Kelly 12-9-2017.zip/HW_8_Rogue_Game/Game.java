/*************************************************************************
 *  Compilation:  javac Game.java
 *  Execution:    java Game < input.txt
 *  Dependencies: Dungeon.java Site.java In.java Monster.java Rogue.java
 *  Chris Kelly 11-30-2017 10:30 PM
 *  NOTE: I could convert C++ to Java pretty easily. I would, if I did,
 *  get rid of anything that is not directly compatable with C++. I would
 *  also use the corresponding C++ or C library files.
 *************************************************************************/

//package HW_8_Rogue_Game;
import java.util.Scanner;
import java.io.File;
public class Game {

    // portable newline
    private final static String NEWLINE = System.getProperty("line.separator");
  
    private Dungeon dungeon = null;     // the dungeon
    private char MONSTER = '\0';        // name of the monster (A - Z)
    private char ROGUE = '@';           // name of the rogue
    private int N = 0;                  // board dimension
    private Site monsterSite = null;    // location of monster
    private Site rogueSite = null;      // location of rogue
    private Site lastMonsterSite = null;// the previous location of the monster
    private Site lastRogueSite = null;  // the previous location of the rogue  
    private Monster monster = null;     // the monster
    private Rogue rogue = null;         // the rogue
    private char[][] board = null;      // the "graph"

    //allows the user to enter a size for the board, if the user does not enter a valid size the program exits
    private void getDimensionFromUser(In in)
    {
    	boolean checkQuit = false;
        while (checkQuit == false)
        {
        	try
	        {
	        	System.out.print("Enter the dimension of the dungeon: ");
	        	N = Integer.parseInt(in.readLine());
	        	checkQuit = true;
	        	break;
	        }
	        catch(NumberFormatException e)
	        {
	        	System.out.println("ERROR: INVALID INPUT!");
	        	N = 0;
	        	checkQuit = false;
	        }
	        catch(Exception e)
	        {
	        	e.printStackTrace();
	        	N = 0;
	        	checkQuit = false;
	        }
        }//end of while loop
        
    	//checks to make sure the dimension was valid; if valid it proceeds, if not the program exits
        if (N < 1)
        {
        	System.out.println("Fatal Error: Invalid Dimension! Quitting the Program!");
        	System.exit(0);
        }
        //else;//valid do nothing
    }
    
    //allows the user to enter the dimension of the board by calling the above and to generate the actual board
    private void getBoardFromUser(In in)
    {
    	getDimensionFromUser(in);
    	board = new char[N][N];
        boolean monsterFound = false;
    	boolean rogueFound = false;
        boolean breakOuter = false;
        for (int r = 0; r < N; r++)
        {
        	if (breakOuter) break;
        	
        	System.out.print("Enter a line of the board: ");
        	String s = in.readLine();
        	for (int c = 0; c < N; c++)
        	{
        		board[r][c] = s.charAt(c);
        		
        		// check for monster's location
                if (board[r][c] >= 'A' && board[r][c] <= 'Z') {
                    if (monsterFound == false)
                    {
	                    MONSTER = board[r][c];
	                    board[r][c] = '.';
	                    monsterSite = new Site(r, c);
                    }
                    else
                    {
                    	for (int row = r; row < N; row++)
                    	{
                    		for (int col = c; col < N; col++)
                    		{
                    			board[row][col] = '\0';
                    		}
                    	}
                    	
                    	breakOuter = true;
                    	break;
                    }
                }

                // check for rogue's location
                if (board[r][c] == ROGUE) {
                    if (rogueFound == false)
                    {
	                    board[r][c] = '.';
	                    rogueSite  = new Site(r, c);
                    }
                    else
                    {
                    	for (int row = r; row < N; row++)
                    	{
                    		for (int col = c; col < N; col++)
                    		{
                    			board[row][col] = '\0';
                    		}
                    	}
                    	
                    	breakOuter = true;
                    	break;
                    }
                }
                
                //check for both
                if (board[r][c] == '*')
                {
                	if (rogueFound == false && monsterFound == false)
                	{
                		rogueSite  = new Site(r, c);
                		monsterSite = new Site(r, c);
                	}
                	else
                    {
                    	for (int row = r; row < N; row++)
                    	{
                    		for (int col = c; col < N; col++)
                    		{
                    			board[row][col] = '\0';
                    		}
                    	}
                    	
                    	breakOuter = true;
                    	break;
                    }
                }
        	}//end of c for loop
        }//end of r for loop
    }
    
    public String getFileNameFromUser(In in)
    {
    	String fileName = "";
    	Scanner file = null;
    	while (file == null)
    	{
    		System.out.print("Enter the filename for the board: ");
	    	fileName = in.readLine();
	    	
	    	if (fileName.equals("exit"))
	    	{
	    		System.out.println("Quitting the Program!");
	    		System.exit(0);
	    	}
	    	
	    	try
	    	{
	    		file = new Scanner(new File(fileName));
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.println("ERROR: FILE DOES NOT EXIST!");
	    		//e.printStackTrace();
	    	}
    	}//end of while loop
    	return fileName;
    }
    //this gets the file name from the user and reads that file, since the dimension is in there we also check
    //if it is valid (minimum size is 1). If for the file name the user enters exit all lowercase, the program
    //will quit.
    private void readFile(In in, String fileName)
    {
    	if (in == null)
    	{
    		System.out.println("Fatal Error: Could not get input from the user!");
    		System.exit(0);
    	}
    	
    	boolean promptFileName = false;
    	Scanner file = null;
    	while (file == null)
    	{
    		if (fileName == null || fileName.length() < 5) promptFileName = true;
    		if (promptFileName) fileName = getFileNameFromUser(in);
	    	
	    	try
	    	{
	    		file = new Scanner(new File(fileName));
	    	}
	    	catch(Exception e)
	    	{
	    		fileName = "";
	    		System.out.println("ERROR: FILE DOES NOT EXIST!");
	    		//e.printStackTrace();
	    	}
    	}//end of while loop
    	
    	//do the actual reading of the file here
    	//file will be in the format of number then the characters
    	//if the number is negative, exit the program or minus character found as the first character
    	//once we are done building the board quit. Quit reading the file, unless error found on or before
    	//the nth line. Once the Nth line read, quit reading the file.
    	int lineNum = 0;
    	boolean monsterFound = false;
    	boolean rogueFound = false;
    	boolean breakOuter = false;
    	while (file.hasNext())
    	{
    		if (lineNum < N + 1 && !breakOuter);//do nothing
    		else break;
    		
    		String line = file.nextLine();
    		System.out.println("line = " + line);
    		if (line.length() < 1)
    		{
    			System.out.println("Fatal Error: Unexpected Enter/Return Character Found in the File!");
    			System.out.println("Please remove these characters in a separate text editor, save the");
    			System.out.println(" file, and try again. Program will now exit!");
		        System.exit(0);
    		}
    		//else;//do nothing
    		
    		if (lineNum == 0)
    		{
    			N = Integer.parseInt(line);
    			//checks to make sure the dimension was valid; if valid it proceeds, if not the program exits
		        if (N < 1)
		        {
		        	System.out.println("Fatal Error: Invalid Dimension! Quitting the Program!");
		        	System.exit(0);
		        }
		        //else;//valid do nothing
		        
		        //finish declairing it
		        board = new char[N][N];
	    	}
    		else
    		{
    			int r = lineNum - 1;
    			for (int c = 0; c < N; c++)
	        	{
	        		board[r][c] = line.charAt(2 * c);
	        		
	        		// check for monster's location
	                if (board[r][c] >= 'A' && board[r][c] <= 'Z') {
	                    //System.out.println("monsterFound = " + monsterFound);
	                    if (monsterFound == false)
	                    {
	                    	MONSTER = board[r][c];
	                    	board[r][c] = '.';
	                    	monsterSite = new Site(r, c);
	                    	monsterFound = true;
	                    }
	                    else
	                    {
	                    	//fill rest with the null character
	                    	for (int k = r; k < N; k++)
	                    	{
	                    		for (int i = c; i < N; i++)
	                    		{
	                    			board[k][i] = '\0';//null character
	                    		}
	                    	}
	                    	breakOuter = true;
	                    	break;
	                    }
	                }
					else if (board[r][c] == ROGUE) {
	                    //System.out.println("rogueFound = " + rogueFound);
	                    if (rogueFound == false)
	                    {
	                    	// check for rogue's location
	                		board[r][c] = '.';
	                    	rogueSite  = new Site(r, c);
	                    	rogueFound = true;
	                    }
	                    else
	                    {
	                    	//fill rest with the null character
	                    	for (int k = r; k < N; k++)
	                    	{
	                    		for (int i = c; i < N; i++)
	                    		{
	                    			board[k][i] = '\0';//null character
	                    		}
	                    	}
	                    	breakOuter = true;
	                    	break;
	                    }
	                }
	                else if (board[r][c] == '*')
	                {
	                	//System.out.println("rogueFound = " + rogueFound);
	                	//System.out.println("monsterFound = " + monsterFound);
	                	if (rogueFound == false && monsterFound == false)
	                	{
	                		//check for both
	                		rogueSite  = new Site(r, c);
	                		monsterSite = new Site(r, c);
	                		rogueFound = true;
	                		monsterFound = true;
	                	}
	                	else
	                    {
	                    	//fill rest with the null character
	                    	for (int k = r; k < N; k++)
	                    	{
	                    		for (int i = c; i < N; i++)
	                    		{
	                    			board[k][i] = '\0';//null character
	                    		}
	                    	}
	                    	breakOuter = true;
	                    	break;
	                    }
	                }
	                //else;//do nothing
	        	}//end of c for loop
    		}
    		
    		//increment the line counter
    		lineNum++;
    	}//end of while loop
    	
    	printBoard();
    }
    private void readFile(In in)
    {
    	String fileName = "";
    	Scanner file = null;
    	while (file == null)
    	{
    		fileName = getFileNameFromUser(in);
	    	
	    	try
	    	{
	    		file = new Scanner(new File(fileName));
	    	}
	    	catch(Exception e)
	    	{
	    		System.out.println("ERROR: FILE DOES NOT EXIST!");
	    		//e.printStackTrace();
	    	}
    	}//end of while loop
    	readFile(in, fileName);
    }
    
    //check to make sure that the board is valid
    public boolean isValidBoard()
    {
    	if (board == null) return false;
    	//else;//do nothing safe to proceed
    	
    	//we do know that N is at least one.
    	//check to see if it is obvious
    	//System.out.println("N = " + N);
    	if (N == 1)
    	{
    		if (board[0][0] == ' ') return false;
    		//else;//go through it just to make sure that it is correct
    	}
    	//else;//we need to go through the entire thing
    	
    	//board of all spaces is not valid (even if there is a monster and one rogue)
    	//board of all walls is valid (provided there is one monster and one rogue)
    	
    	boolean oneLetterFound = false;
    	boolean oneAtSymbolFound = false;
    	boolean bothOnSameSpot = false;
    	int numSpaces = 0;
    	for (int r = 0; r < N; r++)
    	{
    		for (int c = 0; c < N; c++)
    		{
    			if (board[r][c] == '@')
    			{
    				if (oneAtSymbolFound) return false;
    				else oneAtSymbolFound = true;
    			}
    			else if (board[r][c] == 'A' || board[r][c] == 'B' || board[r][c] == 'C' ||
    				board[r][c] == 'D' || board[r][c] == 'E' || board[r][c] == 'F' ||
    				board[r][c] == 'G' || board[r][c] == 'H' || board[r][c] == 'I' ||
    				board[r][c] == 'J' || board[r][c] == 'K' || board[r][c] == 'L' ||
    				board[r][c] == 'M' || board[r][c] == 'N' || board[r][c] == 'O' ||
    				board[r][c] == 'P' || board[r][c] == 'Q' || board[r][c] == 'R' ||
    				board[r][c] == 'S' || board[r][c] == 'T' || board[r][c] == 'U' ||
    				board[r][c] == 'V' || board[r][c] == 'W' || board[r][c] == 'X' ||
    				board[r][c] == 'Y' || board[r][c] == 'Z')
    			{
    				if (oneLetterFound) return false;
    				else oneLetterFound = true;
    			}
    			else if (board[r][c] == '*')
    			{
    				//both the at symbol and monster were found
    				if (bothOnSameSpot == false && oneLetterFound == false &&
    					oneAtSymbolFound == false)
    				{
    					bothOnSameSpot = true;
    				}
    				else return false;
    			}
    			else if (board[r][c] == '+' || board[r][c] == '.');
    			else if (board[r][c] == ' ') numSpaces++;
    			else return false;
    		}//end of c for loop
    	}//end of r for loop
    	
    	//System.out.println("oneAtSymbolFound = " + oneAtSymbolFound);
    	//System.out.println("rogueSite = " + rogueSite);
    	//System.out.println("oneLetterFound = " + oneLetterFound);
    	//System.out.println("monsterSite = " + monsterSite);
    	//System.out.println("bothOnSameSpot = " + bothOnSameSpot);
    	if (rogueSite != null && monsterSite != null)
    	{
    		if (oneAtSymbolFound == false && oneLetterFound == false)
			{
				//set these or return true;
				oneAtSymbolFound = true;
				oneLetterFound = true;
			}
			else return false;
    	}
    	else
    	{
	    	if (rogueSite == null && oneAtSymbolFound == true);//do nothing valid
	    	else if (rogueSite != null && oneAtSymbolFound == false)
	    	{
	    		oneAtSymbolFound = true;
	    	}
	    	else return false;
	    	
	    	if (monsterSite == null && oneLetterFound == true);//do nothing valid
	    	else if (monsterSite != null && oneLetterFound == false)
	    	{
	    		oneLetterFound = true;
	    	}
	    	else return false;
    	}
    	
    	//System.out.println("NEW oneAtSymbolFound = " + oneAtSymbolFound);
    	//System.out.println("NEW oneLetterFound = " + oneLetterFound);
    	//System.out.println("numSpaces = " + numSpaces);
    	//System.out.println("N * N - 2 = " + (N * N - 2));
    	if (numSpaces > N * N - 2 && numSpaces > 0) return false;
    	
    	if (oneLetterFound && oneAtSymbolFound) return true;
    	else return false;
    }
    
    // initialize game
    public Game(In in)
    {
        // read in data
        boolean readInFromFile = true;
        
        while (!isValidBoard())
        {
        	if (readInFromFile == false) getBoardFromUser(in);
        	else
        	{
        		readFile(in);
        		//readFile(in, "D5-1.txt");
        	}
        	//System.out.print("Testing to see if the board is valid: ");
        	boolean valid = isValidBoard();
        	//System.out.println("valid = " + valid);
        	if (valid) break;
        	else System.out.println("ERROR: The board you entered is invalid!");
        }//end of while loop
        
        dungeon = new Dungeon(board, this);
        monster = new Monster(this);
        rogue   = new Rogue(this);
    }

    // return position of monster and rogue
    public Site getMonsterSite() { return monsterSite; }
    public Site getRogueSite()   { return rogueSite;   }
    public Dungeon getDungeon()  { return dungeon;     }
	public Site getLastMonsterSite() { return lastMonsterSite; }
	public Site getLastRogueSite() { return lastRogueSite; }
	
    // play until monster catches the rogue
    public void play() {
        boolean play = true;
        
        //check to see if you are initially caught by the monster
        for (int r = 0; r < N; r++)
        {
        	for (int c = 0; c < N; c++)
        	{
        		if (board[r][c] == '*')
        		{
        			System.out.println("Caught by monster");
        			play = false;
        			break;
        		}
        		//else;//do nothing
        	}//end of c for loop
        }//end of r for loop
        
        //System.out.println("dungeon.isIsolated(rogueSite) = " + dungeon.isIsolated(rogueSite));
        //System.out.println("dungeon.isIsolated(monsterSite) = " + dungeon.isIsolated(monsterSite));
        //System.out.println("dungeon.canPointAGetToPointB(rogueSite, monsterSite) = " +
        //	dungeon.canPointAGetToPointB(rogueSite, monsterSite));
        
        for (int t = 1; play; t++) {
            //if either player is inaccessible to the other, no path will lead to them;
            //just end the game saying that the rogue won.
            if ((t == 1) && (dungeon.isIsolated(rogueSite) == 1 ||
            	dungeon.isIsolated(monsterSite) == 1 ||
            	!dungeon.canPointAGetToPointB(rogueSite, monsterSite)))
            {
            	System.out.println("Rogue Wins!");
            	play = false;
            	break;
            }
            //else;//do nothing
            
            //in case the program does not end, kill it after N^4 times.
            if (t < N * N * N * N);//do nothing
            else
            {
            	System.out.println("Rogue Wins!");
            	play = false;
            	break;
            }
            
            System.out.println("Move " + t);
            System.out.println();
            
            // monster moves
            System.out.println("Monster moves");
            if (monsterSite.equals(rogueSite)) break;
            Site next = monster.move();
            if (dungeon.isLegalMove(monsterSite, next))
            {
            	lastMonsterSite = monsterSite;
            	monsterSite = next;
            }
	        else
	        {
	        	//System.out.println("isSkinnyPath(next) = " + dungeon.isSkinnyPath(next));
	        	//System.out.println("isInaccessible(next) = " + dungeon.isInaccessible(next));
	        	//System.out.println("monsterSite = " + monsterSite);
	        	//System.out.println("next = " + next);
	        	throw new RuntimeException("Monster caught cheating");
	        }
            //System.out.println(this);
            printBoard();

            // rogue moves
            System.out.println("Rogue moves");
            if (monsterSite.equals(rogueSite)) break;
            next = rogue.move();
            if (dungeon.isLegalMove(rogueSite, next))
            {
            	lastRogueSite = rogueSite;
            	rogueSite = next;
            }
            else throw new RuntimeException("Rogue caught cheating");
            //System.out.println(this);
            printBoard();
        }

        if (play) System.out.println("Caught by monster");
        //else;//do nothing
    }


    // string representation of game state (inefficient because of Site and string concat)
    public String toString() {
        String s = "";
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                Site site = new Site(i, j);
                if (rogueSite.equals(monsterSite) && (rogueSite.equals(site))) s += "* ";
                else if (rogueSite.equals(site))                               s += ROGUE   + " ";
                else if (monsterSite.equals(site))                             s += MONSTER + " ";
                else if (dungeon.isRoom(site))                                 s += ". ";
                else if (dungeon.isWall(site))                                 s += "+ ";
                else if (dungeon.isInaccessible(site))                         s += "  ";
            }
            s += NEWLINE;
        }
        return s;
    }

	public void printBoard()
	{
		if (board == null) return;
		
		//PRE-CONDTION: rogueSite and monsterSite are not null
		for (int r = 0; r < N; r++)
		{
			for (int c = 0; c < N; c++)
			{
				if (board[r][c] == '\0') break;
				
				if (rogueSite == null)
				{
					if (monsterSite == null) System.out.print(board[r][c]);
					else
					{
						if (r == monsterSite.i() && c == monsterSite.j())
						{
							System.out.print(MONSTER);
						}
						else System.out.print(board[r][c]);
					}
				}
				else
				{
					if (r == rogueSite.i() && c == rogueSite.j())
					{
						if (monsterSite == null) System.out.print(ROGUE);
						else
						{
							if (r == monsterSite.i() && c == monsterSite.j())
							{
								System.out.print("*");
							}
							else System.out.print(ROGUE);
						}
					}
					else
					{
						if (monsterSite == null) System.out.print(board[r][c]);
						else
						{
							if (r == monsterSite.i() && c == monsterSite.j())
							{
								System.out.print(MONSTER);
							}
							else System.out.print(board[r][c]);
						}
					}
				}
			}
			System.out.println();
		}//end of r for loop
		System.out.println();
	}
	
    public static void main(String[] args) {
        In stdin = new In();
        Game game = new Game(stdin);
        //System.out.println(game);
        //int[][] arr = game.getDungeon().getAllCombinationsForRoomCycles(4);
        //game.lastMonsterSite = new Site(1, 5);
        //game.monsterSite = new Site(2, 5);
        //game.rogueSite = new Site(3, 5);
        game.printBoard();
        //System.out.println(game.getDungeon().canVisitAllOfTheRooms());
        game.play();
        stdin.close();
    }

}
