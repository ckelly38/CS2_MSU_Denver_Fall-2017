/**
 * @(#)HW7.java
 * 10-30-2017
 * 3:45 PM - 5:40 PM + 8:44 PM - 10:53 PM
 * Today, I built the basic file reading and writing structure (copied from HW 5).
 * I then started to set up the HashTable. I am not sure that I do not understand how big the
 * table should be and how it should grow. Tomorrow, I need to get the out put file method done then create
 * the HW7.out (cannot be executed as this is a plain text) and then the HW7.hash files.
 * 
 * 10-31-2017
 * 4:04 PM - 4:21 + 4:55 PM - 7:25 PM
 * Today, I had a good class and we talked about HW7. I will start implementing the extra credit option.
 * I also edited my Node class so that it can be compatable with the tree.
 * 
 * 11-1-2017
 * 6:31 PM - 7:21 PM
 * Today, I finished part 2 of the project and turned it in. I am not sure if I did it correctly.
 * 
 * @author Chris Kelly
 * @version 1.00 2017/10/30
 */

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Set;
import java.util.Hashtable;
public class HW7 {

    private static myLinkedList[] table = null;
    private static ArrayList<String> words = new ArrayList<String>();//the original
    private static ArrayList<Integer> wcounts = new ArrayList<Integer>();//the number of times this word was found
    private static final char specialDelimiter = '+';
    private static boolean useDashAsSpace = false;
    private static double alpha = -1;
    private static int ArraySize = -1;
    private static Hashtable<Integer, String> ht = null;
    //if this is false, this will treat it like a special character that needs to be
    //removed; if this is true, this will still remove the dashes but identify two words
    //on either side of it as such.
    
    public HW7() {
    }
    
    //this gets the name of the file from the user
    //if there is a problem, this method prints an
    //error message and uses recursion until the user
    //enters a valid file name which gets returned
    public static String getFileNameFromUser()
    {
    	System.out.print("Filename: ");
    	Scanner scanner = new Scanner(System.in);
    	String fileName = scanner.nextLine();
    	
    	//check if it is valid if it is not, use recursion
    	try
    	{
    		Scanner fileScan = new Scanner(new File(fileName));
    		fileScan.close();
    	}
    	catch(Exception e)
    	{
    		//e.printStackTrace();
    		System.out.println("ERROR: Cannot find or open the file: " + fileName);
    		return getFileNameFromUser();
    	}
    	return fileName;
    }
    
    //this checks to see if a number is prime
    public static boolean isPrime(int num)
    {
    	if (num % 2 == 0) return false;
    	if (num < 2) return false;
    	
    	for (int i = 3; i < num; i+=2) if (num % i == 0) return false;
    	
    	return true;
    }
    
    //this returns -1 if there was an error
    //up indicates the direction to search in for the next prime number
    public static int getClosestPrimeTo(int num, boolean up)
    {
    	if (num < 3) return 2;
    	
    	if (!up)
    	{
    		for (int i = num; i > 2; i-= 2) if (isPrime(i)) return i;
    		return 2;
    	}
    	else
    	{
    		for (int i = num; i > 2; i+= 2) if (isPrime(i)) return i;
    		return -1;//the loop ended in error
    	}
    }
    public static int getClosestPrimeTo(int num)
    {
    	return getClosestPrimeTo(num, false);
    }
    
    public static void getArraySizeFromUser()
    {
    	Scanner scanner = new Scanner(System.in);
    	while(true)
    	{
    		System.out.print("Enter a prime array size: ");
    		try
    		{
    			ArraySize = scanner.nextInt();
    		}
    		catch(Exception e)
    		{
    			System.out.println("ERROR: INVALID INPUT!");
    			scanner.reset();
    			scanner.next();
    			ArraySize = -1;
    		}
    		
    		if (isPrime(ArraySize)) return;
    		else
    		{
    			if (ArraySize < 1);//do nothing
    			else System.out.println("The closest prime number is: " + getClosestPrimeTo(ArraySize));
    			ArraySize = -1;
    		}
    	}//end of while loop
    }
    
    //this helps the read file method it finds invalid characters and removes them then returns the new word
    private static String removeSpecialCharacterFromAWord(String word)
    {
    	String myChars = "`~^+, -:;.*!?_[]()/%$";//we are to ignore ,:;* -_!?". (etc.)
    	myChars += '"';
    	myChars += "'";
    	for (int i = 0; i < word.length(); i++)
    	{
    		for (int k = 0; k < myChars.length(); k++)
    		{
    			//System.out.println("k = " + k);
    			//System.out.println("len = " + word.length());
    			//System.out.print("word.charAt("+i+") = ");
    			//System.out.println(word.charAt(i));
    			if (myChars.charAt(k) == word.charAt(i))
    			{
    				if (word.charAt(i) == '-' && useDashAsSpace == true)
    				{
    					//go on either side of that to see if the word should be split into more
    					//if it should, I will insert a + and then return it as one, in the readFile
    					//I will remove all of + and add more words...
    					
						int startWordIndex = -1;
    					for (int in = i - 1; in > -1; in--)
    					{
    						if (Character.isLetter(word.charAt(in)))
    						{
    							startWordIndex = in;
    							break;
    						}
    					}
    					int nextWordStartIndex = -1;
    					for (int in = i + 1; in < word.length(); in++)
    					{
    						if (Character.isLetter(word.charAt(in)))
    						{
    							nextWordStartIndex = in;
    							break;
    						}
    					}
    					
    					if (startWordIndex > -1 && nextWordStartIndex > -1)
    					{
    						word = word.substring(0, startWordIndex + 1) + specialDelimiter + word.substring(nextWordStartIndex);
    					}
    					else if (startWordIndex > -1 && nextWordStartIndex < 0)
    					{
    						word = word.substring(0, startWordIndex + 1);
    					}
    					else if (startWordIndex < 0 && nextWordStartIndex > -1)
    					{
    						word = word.substring(nextWordStartIndex);
    					}
    					else word = "";
    				}
    				else
    				{
	    				if (i + 1 < word.length())
	    				{
	    					word = word.substring(0, i) + word.substring(i + 1);
	    				}
	    				else
	    				{
	    					word = word.substring(0, i);
	    				}
    				}
    				i = -1;
    				//System.out.println("REMOVED A CHAR");
    				break;
    			}
    			//else;//do nothing
    		}//end of k for loop
    	}//end of i for loop
    	return word;
    }
    
    //this reads the file and the data into the program
    public static void readFile(String fileName)
    {
    	Scanner fileScan = null;
    	try
    	{
    		fileScan = new Scanner(new File(fileName));
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return;
    	}
    	
    	//read the file here and store the words inside an ArrayList
    	//the scanner.next() will be helpful
    	//also, we are to ignore ,:;* -_!?". (etc.)
    	//do not ignore duplicates
    	int i = 0;
    	while(fileScan.hasNext())
    	{
    		String word = fileScan.next();
    		word = removeSpecialCharacterFromAWord(word);
    		word = word.toLowerCase();
    		
    		if (useDashAsSpace)
    		{
	    		while (word.indexOf(specialDelimiter) > -1)
	    		{
	    			if (word.indexOf(specialDelimiter) > -1)
		    		{
		    			String worda = word.substring(0, word.indexOf(specialDelimiter));
		    			//System.out.println("worda = " + worda);
		    			
		    			//adds the split words into the list
		    			if (worda.length() > 0)
		    			{
		    				//go through the entire list of words and see if there is a copy of this found
		    				boolean found = false;
		    				int foundIndex = -1;
		    				for (int k = 0; k < i; k++)
		    				{
		    					if (words.get(k).equals(worda))
		    					{
		    						found = true;
		    						foundIndex = k;
		    						break;
		    					}
		    				}
		    				
		    				if (!found)
		    				{
		    					words.add(i, worda);
		    					wcounts.add(i, 1);
		    					i++;
		    				}
		    				else
		    				{
		    					wcounts.set(foundIndex, wcounts.get(foundIndex) + 1);
		    				}	
		    			}
		    			//else;//do nothing
		    			
		    			word = word.substring(word.indexOf(specialDelimiter) + 1);
		    			//System.out.println("wordb = " + word);
		    			//System.out.println();
		    		}
		    		else break;
	    		}//end of inner while loop
    		}
    		//else;//do nothing
    		
    		//add to the arraylist here
    		//either this adds the word directly to the list OR
    		//it adds the last one to the list after the inner loop ran
    		if (word.length() > 0)//to get rid of blank words
    		{
	    		//go through the entire list of words and see if there is a copy of this found
				boolean found = false;
				int foundIndex = -1;
				for (int k = 0; k < i; k++)
				{
					if (words.get(k).equals(word))
					{
						found = true;
						foundIndex = k;
						break;
					}
				}
				
				if (!found)
				{
					words.add(i, word);
	    			wcounts.add(i, 1);
	    			i++;
				}
				else
				{
					wcounts.set(foundIndex, wcounts.get(foundIndex) + 1);
				}
    		}
    	}//end of while loop
    	
    	//done reading the file so close it
    	fileScan.close();
    }
    
    //this needs to be modified for each of the different files and the formats will be different
    //HW7.out FORMAT: Index: contents of the linked lists;
    //HW7.hash FORMAT: keys and values for the first 5 keys
    //this will allign the word counts with each other...
    public static void createOutPutFile(String outFileName)
    {
    	BufferedWriter bw = null;
    	try
    	{
    		File file = new File(outFileName);
    		
    		//if it doesn't exist, create it
    		if (!file.exists())
    		{
    			file.createNewFile();
    		}
    		
    		bw = new BufferedWriter(new FileWriter(file));
    		
    		//do the actual writing here
    		//HW7.out FORMAT: Index: contents of the linked lists (only first 5);
    		//HW7.hash FORMAT: keys and values for the first 5 keys
    		
    		if (outFileName.equals("HW7.out"))
    		{
	    		for (int i = 0; i < 5 && i < ArraySize; i++)
	    		{
	    			String str = "INDEX " + i + ":";
	    			bw.write(str);
	    			bw.newLine();
	    			str = "LINKED LIST SIZE: " + table[i].size();
	    			bw.write(str);
	    			bw.newLine();
	    			Node current = null;
	    			for(int k = 0; k < table[i].size(); k++)
	    			{
	    				if (k == 0) current = table[i].getHead();
	    				else current = current.getNext();
	    				bw.write("" + (current.getData()));
	    				bw.newLine();
	    			}//end of k for loop
	    		}//end of i for loop
    		}
    		else if (outFileName.equals("HW7.hash"))
    		{
    			//we need to get a list of keys from the map
    			//then we need to print the values associated with those keys
    			Set<?> mks = ht.keySet();
    			Object[] mkeys = mks.toArray();
    			/*
    			System.out.println(mks.size());
    			for (int i = 0; i < mks.size(); i++)//i < 5 && 
    			{
    				System.out.println(ht.get(mkeys[i]));
    			}//end of i for loop*/
    			
    			//bw.write("keys, value");
    			//bw.newLine();
    			for (int i = 0; i < 5; i++)
    			{
    				bw.write(mkeys[i] + ", " + ht.get(mkeys[i]));
    				bw.newLine();
    			}//end of i for loop
    		}
    		//else;//do nothing
    		
    		/*int maxLen = 0;
	    	for (int i = 0; i < wordsarrayforbubble.length; i++)
	    	{
	    		int len = wordsarrayforbubble[i].length();
	    		if (len > maxLen)
	    		{
	    			maxLen = len;
	    		}
	    	}
	    	for (int i = 0; i < wordsarrayforbubble.length; i++)
    		{
    			String str = wordsarrayforbubble[i];
    			int len = str.length();
    			if (len < maxLen)
	    		{
	    			for (int k = 0; k < maxLen - len; k++) str += " ";
	    		}
	    		str += wcounts.get(i);
    			
    			//do the actual writing here
    			bw.write(str);
    			bw.newLine();
    		}//*/
    		//bw.write() does the writing of the contents like a System.out.print("stuff");
    		//bw.newLine() makes a new line there
    		
    		//always close the file when done writing to it
    		//bw.close();//will be closed below
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    	finally
    	{
    		try
    		{
    			//always close the file when done writing to it
	    		bw.close();
	    	}
	    	catch(Exception e)
	    	{
	    		e.printStackTrace();
	    	}
    	}
    }
    
    
    //gets the hashcode based on commonality of words or numbers
    //if a number greater than 9 is entered this divides it by 31 and calls itself again
    public static int hashCode(int num)
    {
    	if (num < 0) num *= -1;
    	
    	if (num < 10) return 0;
    	else return hashCode(num / 31);
    }
    
    //this method returns -1 if an invalid character is found
    //else this method returns a positive number from 1 to 12 with commonly used words as case 5
    //rigged to be semi-normal model for tale of two cities.
    public static int hashCode(String str)
    {
    	if (str.length() < 1) return -1;
    	boolean allNumbers = true;//if true convert the string to an integer and then call the
    	boolean invalidCharacterFound = false;
    	int firstLetterIndex = -1;
    	//hashCode function for a number
    	for (int i = 0; i < str.length(); i++)
    	{
    		if (str.charAt(i) == '[' || str.charAt(i) == ']' ||
    			str.charAt(i) == '(' || str.charAt(i) == ')' ||
    			str.charAt(i) == '#' || str.charAt(i) == '/' ||
    			str.charAt(i) == '\'' || str.charAt(i) == '%')
    		{
    			//not a letter do nothing
    			invalidCharacterFound = true;
    			allNumbers = true;//overrride
    			break;
    		}
    		else if (Character.isLetter(str.charAt(i)))
    		{
    			firstLetterIndex = i;
    			allNumbers = false;
    			break;
    		}
			else if (Character.isDigit(str.charAt(i)));
			else
			{
				allNumbers = false;
    			//break;//want to check the entire string first
			}
			//else return -1;
    	}
    	//System.out.println("firstLetterIndex = " + firstLetterIndex);
    	//System.out.println("allNumbers = " + allNumbers);
    	
    	if (firstLetterIndex < 0)
    	{
    		if (allNumbers)
    		{
    			if (invalidCharacterFound)
    			{
    				//[980]
    				//needs to be 90876547
    				//convert the first to ascii by int cast, then multiply value by 10 ^ length of the string
    				int num = -1;
    				for (int i = 0; i < str.length(); i++)
    				{
    					num = (int)(str.charAt(i));
    					for (int k = i; k < str.length(); k++) num *= 10;
    				}
    				return hashCode(num);
    			}
    			else return hashCode(Integer.parseInt(str));
    		}
    		else return -1;
    	}
    	else
    	{
    		if (str.length() < 4)
	    	{
	    		invalidCharacterFound = false;
	    		for (int i = 0; i < str.length(); i++)
	    		{
	    			if (Character.isLetter(str.charAt(i)));
	    			else if (Character.isDigit(str.charAt(i)))
	    			{
	    				//System.out.println(Character.getNumericValue(str.charAt(i)));
	    				return hashCode(Character.getNumericValue(str.charAt(i)));
	    			}
	    			else
	    			{
	    				invalidCharacterFound = true;
	    				break;
	    			}
	    		}
	    		
	    		if (invalidCharacterFound)
	    		{
	    			int num = -1;
    				for (int i = 0; i < str.length(); i++)
    				{
    					num = (int)(str.charAt(i));
    					for (int k = i; k < str.length(); k++) num *= 10;
    				}
    				return hashCode(num);
	    		}
	    		else return 5;
	    	}
    		else if (str.charAt(firstLetterIndex) == 'a' || str.charAt(firstLetterIndex) == 'b') return 3;
	    	else if (str.charAt(firstLetterIndex) == 'c' || str.charAt(firstLetterIndex) == 'd') return 4;
	    	else if (str.charAt(firstLetterIndex) == 'e' || str.charAt(firstLetterIndex) == 'f') return 7;
	    	else if (str.charAt(firstLetterIndex) == 'g' || str.charAt(firstLetterIndex) == 'h') return 2;
	    	else if (str.charAt(firstLetterIndex) == 'i' || str.charAt(firstLetterIndex) == 'j') return 1;
	    	else if (str.charAt(firstLetterIndex) == 'k' || str.charAt(firstLetterIndex) == 'l') return 11;
	    	else if (str.charAt(firstLetterIndex) == 'm' || str.charAt(firstLetterIndex) == 'n' ||
	    		str.charAt(firstLetterIndex) == 'q') return 9;
	    	else if (str.charAt(firstLetterIndex) == 'o' || str.charAt(firstLetterIndex) == 'p') return 6;
	    	else if (str.charAt(firstLetterIndex) == 'r' || str.charAt(firstLetterIndex) == 's') return 5;
	    	else if (str.charAt(firstLetterIndex) == 't' || str.charAt(firstLetterIndex) == 'y') return 10;
	    	else if (str.charAt(firstLetterIndex) == 'u' || str.charAt(firstLetterIndex) == 'v' ||
	    		str.charAt(firstLetterIndex) == 'w') return 8;
	    	else if (str.charAt(firstLetterIndex) == 'x' || str.charAt(firstLetterIndex) == 'z') return 12;
	    	else return -1;//not valid data for this method
    	}
    }
    
    //if a double hash code is needed to even out the distribution
    //then we will call this to do something with the old code...
    //returns -1 on error
    public static int doubleHashCode(int num)
    {
    	//highest number returned from previous function was 12 (the error was -1)
    	if (num < 0) return -1;//for error
    	else return ((num * 5) % 31) + (num % 15);
    }
    
    public static void makeTable()
    {
    	//based on the distribution of the alphabet for Tale of Two Cities and commonly used words
    	//as well as other preferences, we can see that
    	//my alpha needs to be greater than 1 (a > 1) and a = N / M
    	//ArraySize = 13;//elements 0 to 14 (M) not table size...
    	alpha = 1.2;
    	double N = alpha * ArraySize;
    	//int N = alpha * ArraySize;
    	//In a table of size M with n = a M keys, the average number of probes is about
        //1/2 * (1 + 1/(1- a)) for search hits and
        //1/2 * (1 + 1/(1- a)2) for misses/inserts
    	
    	table = new myLinkedList[ArraySize];
    	for (int i = 0; i < ArraySize; i++)
    	{
    		table[i] = new myLinkedList<String>(false, false);
    		//table[i].setPrintOnlyData(true);
    	}
    	
    	for (int i = 0; i < words.size(); i++)
    	{
    		String str = words.get(i);
    		//System.out.println("str = " + str);
    		int index = hashCode(str);
    		while (index > ArraySize - 1) index = doubleHashCode(index);
    		//else;//do nothing
    		//System.out.println("index = " + index);
    		Node<String> n = new Node<String>(str);
    		table[index].add(n);
    	}
    }
    
    public static void main(String[] args)
    {
    	String inputFileName = getFileNameFromUser();
    	readFile(inputFileName);
    	
    	//EXTRA CREDIT: if I call this, I want to be able to modify my hashing algorithmn.
    	//getArraySizeFromUser();
    	//System.out.println("ArraySize = " + ArraySize);
    	ArraySize = 13;//the user can change the array size if this line is commented and
    	//the getArraySizeFromUser() is uncommented.
    	
    	//make the hash table based on the ArraySize
    	makeTable();
    	
    	//print the table here
    	/*System.out.println();
    	for (int i = 0; i < table.length; i++)
    	{
    		System.out.println("i = " + i);
    		System.out.println("size: " + table[i].size());
    		System.out.println();
    		//table[i].setPrintOnlyData(false);//true is default for the user
    		table[i].printList();
    	}//end of i for loop*/
    	
    	createOutPutFile("HW7.out");
    	//end of part 1
    	
    	//this is for part 2
    	//I am not sure if this is right (11-1-2017)
    	//Hashtable(int initialCapacity, float loadFactor)
    	ht = new Hashtable<Integer, String>(words.size(), (float)(1.4));
    	for (int i = 0; i < words.size(); i++) ht.put(i, words.get(i));
    	createOutPutFile("HW7.hash");
    }
}