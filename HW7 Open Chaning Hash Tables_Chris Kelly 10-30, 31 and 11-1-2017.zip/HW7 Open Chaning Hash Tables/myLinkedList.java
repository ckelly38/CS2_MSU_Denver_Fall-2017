/**
 * @(#)myCircleLinkedList.java
 * Chris Kelly
 * 
 * Dates:
 * 10-10-2017
 * 6:15 PM - 9:17 PM + 9:36 PM - 12:39 AM
 * Today, I set up all of the add methods, the print forward methods (NEED TO DO BACKWARDS),
 * the skeleton methods for all of them. I still have to WRITE and test the remove methods.
 * I also added a method to access a specific node from the index as well as methods to access the
 * head of the list as well as a method to access the tail. Other essential methods are there as well.
 * 
 * 10-11-2017
 * 2:55 PM - 5:18 PM (-30 minutes for distractions) + 5:57 PM - 12:14 AM
 * Today, I finished the removal and print methods. I also made the current methods more efficient.
 * I also fixed the logic errors in the methods.
 * 
 * 10-12-2017
 * 8:40 PM - 1:03 AM
 * Today, I made this class type independent. I also made a driver or test program to test it.
 * I created two copy constructors to make my test program more efficient. I also moved the main method to
 * a different file and as a result, I had to make the Node class a class that can be accessed by the driver
 * program. This class had to be declared outside of my list class, so I had to use getters and setters and
 * write them inside the Node class.
 * 
 * 10-13-2017
 * 12:57 PM - 9:54 PM + 10:42 PM - 12:53 AM (-1.5 hours time today did not factor in breaks or distractions)
 *
 * GOALS: 1. Need to add a contains Node with specific data method today. This method will also tell me how
 * many times it found it in there 2. I need to have the driver tell me if the program worked as expected
 * for each and every test. 3. Get all of the methods to work as expected.
 * 
 * WHAT I ACTUALLY DID: Today, I imporved my driver class by writing test methods and a
 * containsCount[For](Node<T> n) and a contains(Node<T> n) method. I wrote some methods in the driver to check
 * to see if the list was actually circular like it was supposed to be or not. I also wrote a method in the
 * driver to test my copy constructors. I also had it tell me if there were any more removals than should have
 * been. I also had the driver tell me how many tests the test cases past, how many they failed, and the total.
 * I also modified the print list to warn me if there was any data that was unset and left as null. I also made
 * my driver so that it would give me a summary of all of the tests, so I can see where if any one failed and which
 * before I go scrolling through to find it. I still need to finish this, but I am almost done with it...
 *
 * 10-14-2017
 * 11:08 AM - 11:31 AM + 12:35 PM - 1:40 PM
 * Today, I finished building the results summary for the driver program and then uploaded this. I added a
 * type independent test to the bottom but did not add it to the summary. This worked of course.
 *
 * 10-30-2017
 * 10:44 PM
 * I fixed a bug in the add for a single element list and realized that at some points in time, my head and or tail
 * Node pointers can be null when the add methods get called. As a result this can cause a null pointer exception.
 * I fixed this from happening.
 * 
 * 10-31-2017
 * 4:08 PM - 4:21 PM + 4:55 PM - 5:14 PM
 * Today, I modified the Node class to be able to have as many pointers as the programmer wants, so a tree can be
 * implemented in the future.
 * 
 * GOAL: Design a linked list class that can later be implemented as a circular linked list.
 * 
 * NOTE: JUDY GURKA ASSIGNED THIS AS HOMEWORK. 
 *
 * @author 
 * @version 1.00 2017/10/10
 */
 
class Node<T>
{
	private Node<T> next = null;
	private Node<T> previous = null;
	private Node<T>[] relatives = null;
	//NOTE: for trees relatives[0] = only parent and
	//relatives[1] = left child and
	//relatives[numPointers - 1] = right child
	//also next and previous may always be null
	private int numPointers = 0;
	private T data;
	
	//getters and setters for the "data"
	public void setData(T value)
	{
		data = value;
	}
	public T getData()
	{
		return data;
	}
	
	//returns null if not found
	public Node<T> getParent()
	{
		if (relatives == null) return null;
		else return relatives[0];
	}
	public Node<T>[] getRelatives()
	{
		return relatives;
	}
	public Node<T> getRightSibling()
	{
		Node<T>[] myAuntsAndUncles = getParent().getRelatives();
		//for children: start at 1
		if (myAuntsAndUncles == null) return null;
		if (myAuntsAndUncles.length < 2) return null;
		boolean foundSelf = false;
		for (int i = 1; i < myAuntsAndUncles.length; i++)
		{
			if (foundSelf == true) return myAuntsAndUncles[i];
			
			if (myAuntsAndUncles[i] == this) foundSelf = true;
		}//end of i for loop
		return null;
	}
	
	public Node<T> getNext()
	{
		return next;
	}
	public void setNext(Node<T> value)
	{
		next = value;
		if (value != null) next.setData(value.getData());
		//else;//do nothing
	}
	public Node<T> getPrevious()
	{
		return previous;
	}
	public void setPrevious(Node<T> value)
	{
		previous = value;
		if (value != null) previous.setData(value.getData());
		//else;//do nothing
	}
	
	//constructors for the node class one as default,
	//the other initializes the data
	public Node()
	{
		next = null;
		previous = null;
		data = null;
		numPointers = 0;
	}
	public Node(T value)
	{
		super();
		setData(value);
	}
	public Node(T value, int num)
	{
		super();
		setData(value);
		if (num < 1)
		{
			throw new ArrayIndexOutOfBoundsException("Number of related nodes to this " +
				"node must be greater than 0!");
		}
		numPointers = num;
		relatives = new Node[numPointers];
		for (int i = 0; i < relatives.length; i++) relatives[i] = new Node<T>();
	}
}
public class myLinkedList<T>
{
    private int size = 0;//this tells us the size of the list
    private boolean multilinked = true;//true means more than one link else only one link
    private boolean addCalled = false;//this will control when the user can change multilinked value
    private Node<T> head = null;//needed so that we know where the start of the list is
    private Node<T> tail = null;//this is used as a temporary Node
    private boolean circular = false;//means that the end of the list
    //will point to the beginning of the list and not to null
    private boolean printOnlyData = true;//true is default to the user false is for debugging purposes
    
    public void setPrintOnlyData(boolean value)
    {
    	printOnlyData = value;
    }
    public boolean getPrintOnlyData()
    {
    	return printOnlyData;
    }
    
    //Constructors for the list
    public myLinkedList()
    {
    	size = 0;
    	setCircular(false);
    	setMultilinked(true);//multi (double or single)
    	head = new Node();
    	tail = new Node();
    	head.setData(null);
    	tail.setData(null);
    	setPrintOnlyData(true);
    }
    public myLinkedList(boolean circle, boolean multilinks)
    {
    	super();
    	setPrintOnlyData(true);
    	setCircular(circle);
    	setMultilinked(multilinks);
    }
    //copy constructors PRECondition: oldList is not null
    public myLinkedList(myLinkedList<T> oldList, boolean circle, boolean multilinks)
    {
    	setPrintOnlyData(true);
    	size = 0;
    	setCircular(circle);
    	setMultilinked(multilinks);
    	head = new Node();
    	tail = new Node();
    	head.setData(null);
    	tail.setData(null);
    	
    	//do the copying here
    	for (int i = 0; i < oldList.size(); i++)
    	{
    		//we want two different lists with the same data, so we only copy
    		//over the data NOT make two pointers to the same list
    		Node<T> n = new Node(oldList.getNode(i).getData());
    		add(n);
    	}//end of i for loop
    	
    	//check to see if the properties are different from those in the oldList
    	boolean changeCircle = (oldList.isCircular() != circle);
    	boolean changeMultilinks = (oldList.isCircular() != circle);
    	//if change multilinks = true we go through every element in the list
    	//if change Circle is true we only need to change the ending elements
    	//if both are true change circular first in a separate if statement
    	if (changeCircle)
    	{
    		//change the head's next's previous pointer to point to the tail
    		//change it to null. This depends on the value of the parameter circle.
    		//since we are talking about a previous pointer it also depends on the multilinks parameter.
    		if (multilinks) head.getNext().setPrevious(tail.getNext());
    		else head.getNext().setPrevious(null);
    		if (circle) tail.getNext().setNext(head.getNext());
    		else tail.getNext().setNext(null);
    	}
    	if (changeMultilinks)
    	{
    		//go through the entire list starting at the head
    		//if multilinks is true, make sure that the previous pointer (of the next element)
    		//points to the one before it
    		//else just make sure that the next pointer is set
    		//do not change the ones for circular as they are already done above
    		Node<T> current = null;
    		Node<T> previous = null;
    		for (int i = 0; i < size(); i++)
    		{
    			if (i == 0) current = head.getNext();
    			else current = current.getNext();
    			
    			if (multilinks)
    			{
    				current.setPrevious(previous);
    				previous = current;
    			}
    			else current.setPrevious(null);
    		}//end of i for loop
    	}
    }
    public myLinkedList(myLinkedList<T> oldList)
    {
    	setPrintOnlyData(true);
    	size = 0;
    	setCircular(oldList.isCircular());
    	setMultilinked(oldList.isMultilinked());
    	head = new Node();
    	tail = new Node();
    	head.setData(null);
    	tail.setData(null);
    	
    	//do the copying here
    	for (int i = 0; i < oldList.size(); i++)
    	{
    		//we want two different lists with the same data, so we only copy
    		//over the data NOT make two pointers to the same list
    		Node<T> n = new Node(oldList.getNode(i).getData());
    		add(n);
    	}//end of i for loop
    	//System.out.println("Old List:");
    	//oldList.printList();
    	//System.out.println("New List:");
    	//printList();
    }
    
    //this returns the first node in the list
    //this can return null so be careful
    public Node<T> getHead()
    {
    	return head;
    }
    
    //this may match the head
    //this can also return null so be careful
    public Node<T> getTail()
    {
    	return tail;
    }
    
    //despite this not being an array the index will indicate what element we are on
    //if the index is out of range, null is returned.
    public Node<T> getNode(int index)
    {
    	if (index < 0 || index > size()) return null;
    	else
    	{
    		//since we can always go forward... we just count up to the index and return
    		Node<T> current = null;
    		for (int i = 0; i < this.size(); i++)
    		{
    			if (i == 0) current = head.getNext();
    			else current = current.getNext();
    			
    			if (i == index) return current;
    			//else;//do nothing
    		}//end of i for loop
    		return current;
    	}
    }
    
    //this tells the program if the list is circular
    public void setCircular(boolean value)
    {
    	circular = value;
    }
    
    //this checks to see if the linked list is circular
    public boolean isCircular()
    {
    	return circular;
    }
    
    //this checks to see if the data in this Node is inside the list
    public int containsCount(Node<T> n)
    {
    	if (n == null) return -1;//negative not valid parameter
    	//else;//do nothing
    	int count = 0;//not in the list if less than 1
    	Node current = null;
    	for (int i = 0; i < size(); i++)
    	{
    		if (i == 0) current = head.getNext();
    		else current = current.getNext();
    		
    		if (T == Integer.class || T == int.class || T == Double.class || T == double.class ||
    			T == Float.class || T == float.class || T == Long.class || T == long.class)
    		{
    			if (current.getData() == n.getData()) count++;
    		}
    		else if (T == String.class)
    		{
    			if (current.getData().equals(n.getData())) count++;
    		}
    		else
    		{
    			if ((current.getData()).equals(n.getData())) count++;
    		}
    	}//end of i for loop
    	return count;
    }
    public int frequency(Node<T> n)
    {
    	return containsCount(n);
    }
    public boolean contains(Node<T> n)
    {
    	if (n == null) return false;
    	else return (!(containsCount(n) < 1));
    }
    
    //this checks to see if there is more than one link between the nodes
    public boolean isMultilinked()
    {
    	return multilinked;
    }
    
    //changes the value of a multilinked list (true) to just a singularly linked list (false)
    public void setMultilinked(boolean value)
    {
    	if (addCalled == false) multilinked = value;
    	else;//prevent this value from being set after the first one is added
    	//to the list to save on performance
    }
    
    //gets the size of the linked list
    public int size()
    {
    	return this.size;
    }
    
    //this adds elements to the list
    public void add()
    {
    	if (addCalled == false) addCalled = true;
    	//else;//do nothing
    	
    	Node<T> n = new Node();
    	
    	//System.out.println("n = " + n);
    	
    	//do the actual adding here
    	if (size() == 0)
    	{
    		//head is a dummy pointer
    		if (head == null) head = new Node();
    		if (tail == null) tail = new Node();
    		head.setNext(n);
    		tail.setNext(n);
    		
    		//System.out.println("head.getNext() = " + head.getNext());
    		if (isCircular())
    		{
    			if (isMultilinked())
    			{
    				n.setPrevious(tail.getNext());
    			}
    			n.setNext(n);
    		}
    		//else;//do nothing
    	}
    	else if (size() > 0)
    	{
    		//System.out.println("tail.getNext() = " + tail.getNext());
    		//System.out.println("tail.getNext().getNext() = " + tail.getNext().getNext());
    		tail.getNext().setNext(n);
    		if (isMultilinked()) n.setPrevious(tail.getNext());
    		//else;//do nothing
    		//System.out.println("NEW tail.getNext().getNext() = " + tail.getNext().getNext());
    		tail.setNext(n);
    		//System.out.println("NEW tail.getNext() = " + tail.getNext());
    		if (isCircular())
    		{
    			n.setNext(head.getNext());//sets the end for circular reference
    			//allows the beginning to point to the end
    			if (isMultilinked()) head.getNext().setPrevious(tail.getNext());
    			//else;//do nothing
    		}
    		//else;//do nothing
    	}
    	size++;
    }
    public void add(Node<T> n)
    {
    	if (n == null) throw new NullPointerException("The Node we are adding cannot be null!");
    	//else;//do nothing
    	
    	if (addCalled == false) addCalled = true;
    	//else;//do nothing
    	
    	//n is the current node to be added to the list
    	//n has a next always null and a previous
    	//the previous should be the tail.next before it moves on
    	
    	//System.out.println("n = " + n);
    	
    	//do the actual adding here
    	if (size() == 0)
    	{
    		//head is a dummy pointer
    		if (head == null) head = new Node();
    		if (tail == null) tail = new Node();
    		head.setNext(n);
    		tail.setNext(n);
    		
    		if (isCircular())
    		{
    			if (isMultilinked())
    			{
    				n.setPrevious(tail.getNext());
    			}
    			n.setNext(head.getNext());
    		}
    		//else;//do nothing
    	}
    	else if (size() > 0)
    	{
    		//System.out.println("tail.next = " + tail.getNext());
    		//System.out.println("tail.next.next = " + tail.getNext().getNext());
    		tail.getNext().setNext(n);
    		//System.out.println("NEW tail.next.next = " + tail.getNext().getNext());
    		if (isMultilinked()) n.setPrevious(tail.getNext());
    		tail.setNext(n);
    		//System.out.println("NEW tail.next = " + tail.getNext());
    		
    		if (isCircular())
    		{
    			n.setNext(head.getNext());//sets the end for circular reference
    			//allows the beginning to point to the end
    			if (isMultilinked()) head.getNext().setPrevious(tail.getNext());
    			//else;//do nothing
    		}
    		//else;//do nothing
    	}
    	size++;
    }
    public void add(int index, Node<T> element)
    {
    	if (index < 0) throw new ArrayIndexOutOfBoundsException(index + " is less than 0!");
    	//else;//do nothing
    	if (element == null) throw new NullPointerException("The Node we are adding cannot be null!");
    	//else;//do nothing
    	
    	if (index > size);//do nothing
    	else
    	{
    		if (addCalled == false) addCalled = true;
    	}
    	
    	//System.out.println("index = " + index);
    	//System.out.println("size = " + size);
    	if (index < size)
    	{
    		//we do the inserting here
    		//we need to go through the list and access every element before this one...
    		//then insert it carefully
    		
    		//we go forwards through the list to index - 1;
    		Node current = null;
    		for (int i = 0; i < index; i++)
    		{
    			if (i == 0) current = head.getNext();
    			else current = current.getNext();
    			
    			if (i == index - 1) break;
    			//else;//do nothing
    		}//end of i for loop
    		if (index == 0) current = head.getNext();
    		
    		//System.out.println("element      = " + element);
    		//System.out.println("element.next = " + element.getNext());
    		//System.out.println("current      = " + current);
    		//System.out.println("current.next = " + current.getNext());
    		//System.out.println("head.next    = " + head.getNext());
    		if (index == 0)
			{
				if (head == null) head = new Node();
    			if (tail == null) tail = new Node();
    		
				//head.next needs to point at element
				//it currently points to current
				
				//element.next needs to point to current
				//it currently does NOT point anywhere
				
				//if this is multilinked:
				//element.previous currently points to NULL
				//this should point to current.previous
				
				//current.next should NOT change
				
				element.setNext(current);
				if (isMultilinked())
				{
					element.setPrevious(current.getPrevious());
					//if current.previous points to the tail, then we need to
					//get the current.previous to point at element AND change
					//the tail's next to point to element
					current.setPrevious(element);
				}
				//else;//do nothing element.previous should be null
				head.setNext(element);
				
				if (isCircular()) tail.getNext().setNext(element);
				//else;//do nothing 
			}
    		else
    		{
	    		if (tail == null) tail = new Node();
	    		
	    		if (isMultilinked())
	    		{
	    			//current node = node index - 1
	    			//its next is the next of the inserted node
	    			//System.out.println("element.previous = " + element.getPrevious());
	    			//System.out.println("current.next.previous = " + current.getNext().getPrevious());
	    			
	    			element.setNext(current.getNext());
		    		element.setPrevious(current);
		    		current.getNext().setPrevious(element);
		    		current.setNext(element);
	    			
	    			//System.out.println("NEW element.previous = " + element.getPrevious());
	    			//System.out.println("NEW current.next.previous = " + current.getNext().getPrevious());
	    		}
	    		else
	    		{
	    			//singularly linked list
	    			
	    			//current is Node[index - 1]
	    			//element is what we want to insert
	    			
	    			//element.next needs to be current.next
	    			//current.next needs to be element
	    			
	    			element.setNext(current.getNext());
					current.setNext(element);
	    		}
    		}
    		//System.out.println("NEW element = " + element);
    		//System.out.println("NEW element.next = " + element.getNext());
    		//System.out.println("NEW current = " + current);
    		//System.out.println("NEW current.next = " + current.getNext());
    		
    		size++;
    	}
    	else if (index == size) add(element);//regular adds the element to the end of the list
    	else throw new ArrayIndexOutOfBoundsException(index + " is greater than the size(" + size() + ")!");
    }
    
    //These methods remove specific elements at an index, or by data.
    //They can remove one or all of them (for data matches).
    public void remove(int index)
    {
    	//removes the element at that specific index
    	//if the index is not valid, through an exception
    	if (index < 0) throw new ArrayIndexOutOfBoundsException(index + " is less than 0!");
    	//else;//do nothing
    	if (index < size)
    	{
    		Node current = null;
			for (int i = 0; i < index; i++)
			{
				if (i == 0) current = head.getNext();
				else current = current.getNext();
				
				if (i + 1 == index) break;
				//else;//do nothing
			}//end of i for loop
			if (index == 0) current = head.getNext();
			//else;//do nothing
    		
    		//we do the removing here
    		if (index == 0)
			{
				if (size() == 1)
				{
					head.setNext(null);
					tail.setNext(null);
				}
				else if (size() > 1)
				{
					if (isCircular())
					{
						if (isMultilinked())
						{
							head.getNext().setPrevious(tail.getNext());
							current.getNext().setPrevious(tail.getNext());
						}
						tail.getNext().setNext(current.getNext());
					}
					else
					{
						if (isMultilinked())
						{
							head.getNext().setPrevious(null);
							current.getNext().setPrevious(null);
						}
					}
    				head.setNext(head.getNext().getNext());
				}
				else
				{
					String error_message = "Your size is supposed to be zero or greater: " + size + "!";
					throw new ArrayIndexOutOfBoundsException(error_message);
				}
			}
			else if (index + 1 == size())
			{
				if (isCircular())
				{
					current.setNext(head.getNext());
					if (isMultilinked()) head.getNext().setPrevious(current);
					//else;//do nothing
				}
				else
				{
					if (isMultilinked()) head.getNext().setPrevious(null);
					current.setNext(null);
				}
				tail.setNext(current);
			}
			else
			{
				//index is greater than zero
				current.setNext(current.getNext().getNext());
				if (isMultilinked())
	    		{
	    			//we need to modify node[index - 1].next to point to node[index].next
	    			//and modify node[index + 1].previous to point to node[index - 1]
	    			//node[index].next = null; node[index].previous = null; node[index] = null;
	    			//suggest to garbage collection to run
	    			
	    			current.getNext().setPrevious(current);
	    		}
	    		//else;//do nothing done
			}
    		size--;
    	}
    	else throw new ArrayIndexOutOfBoundsException(index + " is greater than the size(" + size() + ")!");
    }
    public void remove(Node n, boolean all)
    {
    	//we want to remove same data; same next, previous, and data
    	Node current = null;
    	for (int i = 0; i < size(); i++)
    	{
    		if (i == 0) current = head.getNext();
    		else current = current.getNext();
    		
    		//System.out.println("i = " + i);
    		//System.out.println("n data = " + n.getData());
    		//System.out.println("current data = " + current.getData());
    		//System.out.println("n next = " + n.getNext());
    		//System.out.println("current next = " + current.getNext());
    		//System.out.println("n previous = " + n.getPrevious());
    		//System.out.println("current previous = " + current.getPrevious());
    		//System.out.println();
    		if (n.getData() == current.getData() || (n.getNext() == current.getNext() &&
    			n.getNext() != null) || (n.getPrevious() == current.getPrevious() && n.getPrevious() != null))
    		{
    			//we want to remove it
    			//first we want to set current to being for the one at i - 1
    			for (int k = 0; k < i; k++)
    			{
    				if (k == 0) current = head.getNext();
    				else current = current.getNext();
    				
    				if (k + 1 == i) break;
    				//else;//do nothing
    			}//end of k for loop
    			
    			//now that current is reset, do the removing
    			if (i == 0)
    			{
    				if (size() == 1)
    				{
    					current = null;
    					head.setNext(null);
    					tail.setNext(null);
    					break;
    				}
    				else if (size() > 1)
    				{
    					//current.next is Node1 because current = Node0;
    					//head.next needs to be Node1;
    					//tail.next.next needs to be Node1;
    					//tail.next.previous needs to be Node1 (assuming multilinkage).
    					
    					head.setNext(current.getNext());
    					if (isCircular())
    					{
    						if (isMultilinked())
    						{
    							current.getNext().setPrevious(tail.getNext());
    						}
    						tail.getNext().setNext(current.getNext());
    					}
    					else
    					{
    						if (isMultilinked()) current.getNext().setPrevious(null);
    					}
    				}
    				else
					{
						String error_message = "Your size is supposed to be zero or greater: " + size + "!";
						throw new ArrayIndexOutOfBoundsException(error_message);
					}
	    		}
	    		else if (i + 1 == size())
				{
					//we are removing the end element
					//current = Node[size - 2];
					
					//current's next needs to be the first element (head.next if circular; null otherwise)
					//head.next.previous needs to be equal to current (if circular and multilinked)
					//tail.next needs to be equal to current
					
					if (isCircular())
					{
						current.setNext(head.getNext());
						if (isMultilinked())
						{
							head.getNext().setPrevious(current);
						}
						//else;//do nothing
					}
					else current.setNext(null);
					tail.setNext(current);
				}
    			else
    			{
	    			//index is greater than 0
	    			//current = node[index - 1] we want to remove node[index]
	    			
	    			//System.out.println("OLD current.next.next = " + current.getNext().getNext());
	    			//System.out.println("OLD current.next.previous = " + current.getNext().getPrevious());
	    			current.setNext(current.getNext().getNext());
	    			if (isMultilinked())
	    			{
	    				current.getNext().setPrevious(current);
	    			}
	    			//else;//do nothing
	    			
	    			//System.out.println("NEW current.next.next = " + current.getNext().getNext());
	    			//System.out.println("NEW current.next.previous = " + current.getNext().getPrevious());
    			}
    			
    			size--;
    			if (all)
    			{
    				i = -1;
    				continue;
    			}
    			else break;
    		}
    		//else;//do not remove it
    	}//end of i for loop
    }
    //the methods below are convenience methods and just call the two above
    public void remove(Node n)
    {
    	//this removes the first instance of the specified element (going forward)
    	if (n == null) throw new NullPointerException("The Node to be removed must not be null!");
    	//else;//do nothing
    	
    	remove(n, false);
    }
    public void removeAllOf(Node n)
    {
    	if (n == null) throw new NullPointerException("The Node to be removed must not be null!");
    	//else;//do nothing
    	
    	remove(n, true);
    }
    public void removeAll()
    {
    	for(int i = 0; i < size(); i++)
    	{
    		remove(i);
    		i--;
    	}
    }
    public void clear()
    {
    	removeAll();
    }
    
    //for testing program only
    Class T;//needed for generics since this method has type specific code
    public void printList(boolean forwards, int what)
    {
    	//we check the size first
    	if (what == 0)
    	{
    		//prints all of the list in the direction specified...
    		//if doubly linked, this will be very easy
    		//if singularly linked, we only know what is "next" (forwards),
    		//if we were to print this list backwards we need a tail pointer
    		//and a pointer pointing at the one before
    		if (forwards == true)
    		{
    			Node current = null;
    			for (int i = 0; i < size(); i++)
    			{
    				if (i == 0) current = head.getNext();
    				else current = current.getNext();
    				
    				if (printOnlyData == false)
    				{
	    				System.out.println("current  = " + current);
	    				System.out.println("previous = " + current.getPrevious());
	    				System.out.println("next     = " + current.getNext());
    				}
    				
    				//do the actual printing here
    				if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE PROBLEMS!\n");
    				else System.out.println(current.getData() + "\n");
    				
    				if (i + 1 == size()) System.out.println();
    			}//end of i for loop
    		}
    		else
    		{
    			//backwards
    			//this is harder for singularly linked then it is for multilinked
    			if (isMultilinked())
    			{
    				//just start at the tail and go backwards
    				//following the previous until the first element is reached
    				Node current = null;
    				for (int i = size() - 1; i > -1; i--)
    				{
    					if (i == size() - 1) current = tail.getNext();
    					else current = current.getPrevious();
    					
    					if (printOnlyData == false)
	    				{
		    				System.out.println("current  = " + current);
		    				System.out.println("previous = " + current.getPrevious());
		    				System.out.println("next     = " + current.getNext());
	    				}
    					
    					if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE " +
    						"PROBLEMS!\n");
    					else System.out.println(current.getData() + "\n");
    					
    					if (i == 0) System.out.println();
    				}//end of i for loop
    			}
    			else
    			{
    				//this will be harder for a singularly linked list
    				//because it only has a next attribute
    				for (int i = size() - 1; i > -1; i--)
    				{
    					Node current = null;
    					if (i == size() - 1)
    					{
    						current = tail.getNext();
    						//System.out.println("current = " + current);
    						//System.out.println("next = " + current.getNext());
    					}
    					else
    					{
    						//we need to find it and set the value of
    						//current based on the size of the list
    						for (int k = 0; k < i + 1 && k < size(); k++)
	    					{
	    						if (k == 0) current = head.getNext();
	    						else current = current.getNext();
	    						//System.out.println("current = " + current);
	    						//System.out.println("next = " + current.getNext());
	    						//System.out.println(current.getData());
	    						
	    						if (k == i) break;//we found it
	    					}//end of k for loop
    					}
    					
    					if (printOnlyData == false)
	    				{
		    				System.out.println("current  = " + current);
		    				System.out.println("previous = " + current.getPrevious());
		    				System.out.println("next     = " + current.getNext());
	    				}
    					
    					if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE " +
    						"PROBLEMS!\n");
    					else System.out.println(current.getData() + "\n");
    					
    					if (i == 0) System.out.println();
    					//else;//do nothing
    					
    				}//end of i for loop
    			}
    		}
    	}
    	else if (what == 1 || what == 2)
    	{
    		//what == 1 odd data is printed
    		//what == 2 even data is printed
    		if (forwards)
    		{
    			Node current = null;
    			for (int i = 0; i < size(); i++)
    			{
    				if (i == 0) current = head.getNext();
    				else current = current.getNext();
    				//if (current == null) break;
    				
    				if (printOnlyData == false)
    				{
	    				System.out.println("current  = " + current);
	    				System.out.println("previous = " + current.getPrevious());
	    				System.out.println("next     = " + current.getNext());
    				}
    				
    				if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE PROBLEMS!\n");
    				//else;//do nothing
    				
    				if (T == Integer.class)
    				{
	    				if ((((int)(current.getData())) %2 == 0 && what == 2) ||
	    					(((int)(current.getData())) %2 == 1 && what == 1))
	    				{
	    					System.out.println(current.getData() + "\n");
	    				}
	    				//else;//do nothing
    				}
    				else if (T == Double.class)
    				{
	    				if ((((double)(current.getData())) %2 == 0 && what == 2) ||
	    					(((double)(current.getData())) %2 == 1 && what == 1))
	    				{
	    					System.out.println(current.getData() + "\n");
	    				}
	    				//else;//do nothing
    				}
    				else if (T == Float.class)
    				{
	    				if ((((float)(current.getData())) %2 == 0 && what == 2) ||
	    					(((float)(current.getData())) %2 == 1 && what == 1))
	    				{
	    					System.out.println(current.getData() + "\n");
	    				}
	    				//else;//do nothing
    				}
    				else if (T == Long.class)
    				{
	    				if ((((long)(current.getData())) %2 == 0 && what == 2) ||
	    					(((long)(current.getData())) %2 == 1 && what == 1))
	    				{
	    					System.out.println(current.getData() + "\n");
	    				}
	    				//else;//do nothing
    				}
    				else System.out.println(current.getData() + "\n");
    				//print the data like normal if it isn't a number
    				
    				if (i + 1 == size()) System.out.println();
    			}//end of the i for loop
    		}
    		else
    		{
    			//backwards
    			//this is harder for singularly linked then it is for multilinked
    			if (isMultilinked())
    			{
    				//just start at the tail and go backwards
    				//following the previous until the first element is reached
    				Node current = null;
    				for (int i = size() - 1; i > -1; i--)
    				{
    					if (i == size() - 1) current = tail.getNext();
    					else current = current.getPrevious();
    					
    					if (printOnlyData == false)
	    				{
		    				System.out.println("current  = " + current);
		    				System.out.println("previous = " + current.getPrevious());
		    				System.out.println("next     = " + current.getNext());
	    				}
	    				
    					if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE " +
    						"PROBLEMS!\n");
    					//else;//do nothing
    					
    					if (T == Integer.class)
	    				{
		    				if ((((int)(current.getData())) %2 == 0 && what == 2) ||
		    					(((int)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Double.class)
	    				{
		    				if ((((double)(current.getData())) %2 == 0 && what == 2) ||
		    					(((double)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Float.class)
	    				{
		    				if ((((float)(current.getData())) %2 == 0 && what == 2) ||
		    					(((float)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Long.class)
	    				{
		    				if ((((long)(current.getData())) %2 == 0 && what == 2) ||
		    					(((long)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else System.out.println(current.getData() + "\n");
	    				//print the data like normal if it isn't a number
    					
    					if (i == 0) System.out.println();
    				}//end of i for loop
    			}
    			else
    			{
    				//this will be harder for a singularly linked list
    				//because it only has a next attribute
    				for (int i = size() - 1; i > -1; i--)
    				{
    					Node current = null;
    					if (i == size() - 1)
    					{
    						current = tail.getNext();
    						//System.out.println("current = " + current);
    						//System.out.println("next = " + current.getNext());
    					}
    					else
    					{
    						//we need to find it and set the value of
    						//current based on the size of the list
    						for (int k = 0; k < i + 1 && k < size(); k++)
	    					{
	    						if (k == 0) current = head.getNext();
	    						else current = current.getNext();
	    						//System.out.println("current = " + current);
	    						//System.out.println("next = " + current.getNext());
	    						//System.out.println(current.getData());
	    						
	    						if (k == i) break;//we found it
	    					}//end of k for loop
    					}
    					
    					if (printOnlyData == false)
	    				{
		    				System.out.println("current  = " + current);
		    				System.out.println("previous = " + current.getPrevious());
		    				System.out.println("next     = " + current.getNext());
	    				}
    					
    					if (current.getData() == null) System.out.println("\nWARNING: NO DATA CAN CAUSE " +
    						"PROBLEMS!\n");
    					//else;//do nothing
    					
    					if (T == Integer.class)
	    				{
		    				if ((((int)(current.getData())) %2 == 0 && what == 2) ||
		    					(((int)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Double.class)
	    				{
		    				if ((((double)(current.getData())) %2 == 0 && what == 2) ||
		    					(((double)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Float.class)
	    				{
		    				if ((((float)(current.getData())) %2 == 0 && what == 2) ||
		    					(((float)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else if (T == Long.class)
	    				{
		    				if ((((long)(current.getData())) %2 == 0 && what == 2) ||
		    					(((long)(current.getData())) %2 == 1 && what == 1))
		    				{
		    					System.out.println(current.getData() + "\n");
		    				}
		    				//else;//do nothing
	    				}
	    				else System.out.println(current.getData() + "\n");
	    				//print the data like normal if it isn't a number
    					
    					if (i == 0) System.out.println();
    					//else;//do nothing
    					
    				}//end of i for loop
    			}
    		}
    	}
    	//else;//do nothing
    }
    public void printList(boolean forwards)
    {
    	printList(forwards, 0);
    }
    public void printList()
    {
    	printList(true, 0);
    }
}