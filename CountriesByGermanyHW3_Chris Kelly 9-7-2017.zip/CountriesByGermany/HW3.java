/**
 * @(#)HW3.java
 *
 * Dates:
 * 8-31-2017
 * 3:39 PM - 4:06 PM + 4:24 PM - 5:39 PM + 7:30 - 9:33 PM
 * Today, I set up the data file, set up the user interface, and made skeliton classes
 * for all of the files. I also set up the Boarders class. I also started the
 * readFile() method, but I haven't finished it yet.
 *
 * 9-1-2017
 * 10:00 AM - 10:56 AM + 3:22 - 3:34 PM + 6:42 PM - 7:50 PM + 8:34 PM - 8:50 PM
 * Today, I completed the readFile() method, built a to string and get boarder country
 * name list as a string methods. I wrote methods necessary for printing everything, but
 * it seems that my data file that I read in does NOT have any countries with a population
 * greater than 100 million people. I will verify the integrity of the data file by checking
 * it against the source tomorrow; otherwise, I am all done.
 *
 * 9-4-2017
 * 9:59 AM - 10:19 AM
 * It is not 100 Million, but 35 Million.
 *
 * This is a class that creates two different types of lists.
 * An array and a linked list.
 *
 * @author Chris Kelly
 * @version 1.00 8-31-2017
 */

import java.util.Scanner;
import java.util.InputMismatchException;
import java.util.LinkedList;
import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
public class HW3
{

    public HW3()
    {
    	
    }
    
    private static LinkedList<Countries> countryLL;
    private static Countries[] countryArray;
    private static Countries myGermany = new Countries();
    private static Countries[] germanBCList;
    private static ArrayList<Countries> countriesWithMoreThanNMPeople = new ArrayList<Countries>();
    private static ArrayList<Countries> germanBCListWithMoreThanNMPeople = new ArrayList<Countries>();
    
    //this method gets the file to be read in by the user as well as its path
    //if the user does not enter a valid file name, the default "countries.txt"
    //(where my data is will be used)
    public static String getFileName()
    {
    	String fileName = "";
    	System.out.print("Enter a vaild file name: ");
    	Scanner scanner = new Scanner(System.in);
    	fileName = scanner.nextLine();
    	//System.out.println("fileName = " + fileName);
    	try
    	{
    		Scanner file = new Scanner(new File(fileName));
    		file.close();
    	}
    	catch(Exception e)
    	{
    		//do nothing
    		fileName = "countries.txt";//by default
    	}
    	//System.out.println("fileName = " + fileName);
    	return fileName;
    }
    
    //this method imports the data and stores it inside the array and the LinkedList
    public static void readFile()
    {
    	//first create the linked list, then store the size of it, then generate and copy everything into the array
    	String fileName = getFileName();//"countries.txt" default
    	Scanner mfileScanner = null;
    	try
    	{
    		mfileScanner = new Scanner(new File(fileName));
    		int listIndex = 0;
    		while(mfileScanner.hasNext())
	    	{
	    		String line = mfileScanner.nextLine();
	    		//System.out.println("line: " + line);
	    		//format: countryName: lattitude N-S, longitude E-W, countryArea, countryPopulation, countryGDB, countryYear, {country_name, country_name, etc.};
	    		
	    		Countries myCountry = new Countries();
	    		//find the : then the first comma, then the second comma, etc, until the {} then the;
	    		int startIndex = line.indexOf(":");
	    		myCountry.setCountryName(line.substring(0, startIndex));
	    		//System.out.println(myCountry.getCountryName());
	    		
	    		int item = 1;//1str,2str,3int,4int,5double,6year
	    		boolean foundStartOfBoarderCountriesList = false;
	    		for (int i = startIndex; i < line.length() && i > -1; i++)
	    		{
	    			//System.out.println("i = " + i);
	    			//System.out.println(line.substring(i, i + 1));
	    			if (line.substring(i, i + 1).equals(" ") || line.substring(i, i + 1).equals(":") ||
	    				line.substring(i, i + 1).equals(",") || line.substring(i, i + 1).equals(";") ||
	    				line.substring(i, i + 1).equals("}"))
	    			{
	    				//System.out.println("skipped something");
	    				continue;
	    			}
	    			else if (line.substring(i, i + 1).equals("{"))
	    			{
	    				//System.out.println("skipped something");
	    				foundStartOfBoarderCountriesList = true;
	    				continue;
	    			}
	    			//else;//do nothing
	    			
	    			boolean foundNextComma = false;//assuming there is one; will be false if it can't find one
	    			int nextCommaIndex = -1;
	    			boolean findForRan = false;
	    			boolean foundEndOfBCList = false;
	    			for (int k = i + 1; k < line.length() && k > -1; k++)
	    			{
	    				//System.out.println(line.substring(k, k + 1));
	    				if (k == i + 1) findForRan = true;
	    				//else;//do nothing
	    				
	    				if (k + 1 < line.length() && line.substring(k, k + 1).equals(","))
	    				{
	    					foundNextComma = true;
	    					nextCommaIndex = k;
	    					break;
	    				}
	    				else if (k + 1 < line.length() && line.substring(k, k + 1).equals("}"))
	    				{
	    					foundEndOfBCList = true;
	    					nextCommaIndex = k;
	    					break;
	    				}
	    				//else;//do nothing
	    			}//end of k for loop
	    			
	    			//System.out.println("foundNextComma = " + foundNextComma);
	    			//System.out.println("nextCommaIndex = " + nextCommaIndex);
	    			//System.out.println("foundEndOfBCList = " + foundEndOfBCList);
	    			//System.out.println("foundStartOfBoarderCountriesList = " + foundStartOfBoarderCountriesList);
	    			if (foundNextComma == true || foundEndOfBCList == true)
	    			{
	    				String myStr = line.substring(i, nextCommaIndex);
	    				//System.out.println(myStr);
	    				//System.out.println("item = " + item);
	    				if (item == 1) myCountry.setLattitude(myStr);
	    				else if (item == 2) myCountry.setLongitude(myStr);
	    				else if (item == 3 || item == 4 || item == 6)
	    				{
	    					int myValue = Integer.parseInt(myStr);
	    					if (item == 3) myCountry.setCountryArea(myValue);
	    					else if (item == 4) myCountry.setCountryPopulation(myValue);
	    					else myCountry.setCountryYear(myValue);
	    				}
	    				else if (item == 5)
	    				{
	    					myCountry.setCountryGDP(Double.parseDouble(myStr));
	    				}
	    				else if (item < 16 && item > 6)
	    				{
	    					Countries mbc = new Countries();
	    					mbc.setCountryName(myStr);
	    					myCountry.addCountryToBoarderList(mbc);
	    				}
	    				//else;//do nothing
	    				
	    				if (item > 0 && item < 16) i = nextCommaIndex;
	    				//else;//do nothing
	    				//we need to start setting boarder country code here
	    				
	    				item++;
	    			}
	    			//else;//do nothing
	    		}//end of i for loop
	    		
	    		//add the elements to a list
	    		countryLL.add(listIndex, myCountry);
	    		listIndex++;
	    		
	    	}//end of while loop
    	}
    	catch(FileNotFoundException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    private static void printListOfCountriesBoarder(Countries myC)
    {
    	System.out.println(myC.getBoarderCountryListStr());
    }
    
    final static int minPopulationInLists = 35000000;
    private static ArrayList<Countries> generateArrayListBothGermanAndNMillionPeople()
    {
    	//System.out.println("germanBCList.length = " + germanBCList.length);
    	for (int i = 0; i < germanBCList.length; i++)
    	{
    		Countries myC = (Countries)(germanBCList[i]);
    		//System.out.println(myC);
    		//System.out.println(myC.getCountryPopulation());
    		if (myC.getCountryPopulation() > minPopulationInLists)
    		{
    			germanBCListWithMoreThanNMPeople.add(myC);
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return germanBCListWithMoreThanNMPeople;
    }
    
    public static ArrayList<Countries> generateArrayListNMillionPeople()
    {
    	for (int i = 0; i < countryArray.length; i++)
    	{
    		Countries mc = (Countries)(countryArray[i]);
    		//System.out.println(mc);
    		if (mc.getCountryPopulation() > minPopulationInLists)
    		{
    			countriesWithMoreThanNMPeople.add(mc);
    		}
    		//else;//do nothing
    	}
    	return countriesWithMoreThanNMPeople;
    }
    
    public static void main(String[] args)
    {
    	countryLL = new LinkedList<Countries>();
    	Scanner scanner = new Scanner(System.in);
    	int userPreference = -1;
    	boolean readInDataYet = false;
    	while (userPreference == -1)
    	{
	    	while (userPreference == -1)
	    	{
	    		if (!readInDataYet) System.out.print("1. Import Data,");
	    		if (readInDataYet) System.out.println("\n2. Display a list of all of the " +
	    			"countries that boarder Germany,");
	    		if (readInDataYet) System.out.println("3. Display a list of all of the " +
	    			"countries that have population that is greater than " + (minPopulationInLists / 1000000.0) + " million,");
	    		if (readInDataYet) System.out.print("4. Display a list of all of the " +
	    			"countries that boarder Germany AND have a population greater than " + (minPopulationInLists / 1000000.0) + " million,");
	    		System.out.println(" and\n5. Quit the program.");
	    		
	    		try
	    		{
	    			userPreference = scanner.nextInt();
	    		}
	    		catch(InputMismatchException e)
	    		{
	    			System.out.println("ERROR: Invalid input!");
	    			userPreference = -1;//this provides that the loop will run again
	    			scanner.reset();//resets the scanner buffer
	    			scanner.next();//this allows it to move on from the error
	    			//if we did not reset and do the next here, we have an infinite loop
	    		}
	    		
	    		if (userPreference > 5 || userPreference < 1) userPreference = -1;
	    		else if (userPreference == 1 && readInDataYet) userPreference = -1;
	    		else if (readInDataYet == false && userPreference != 1 &&
	    			userPreference != 5) userPreference = -1;
	    		else break;
	    		System.out.println();
	    	}//end of while loop
    	
    		//use the option and reset unless you quit the program
    		if (userPreference == 1)
    		{
    			readFile();
    			readInDataYet = true;
    			
    			//initialize the array and copy over the data
    			countryArray = new Countries[countryLL.size()];
    			for (int i = 0; i < countryLL.size(); i++)
    			{
    				countryArray[i] = countryLL.get(i);
    			}
    			
    			//then check to see if we can find the boarder countries in a list
    			for (int i = 0; i < countryArray.length; i++)// + 1
    			{
    				//System.out.println("i = " + i);
    				Countries myCountry = null;
    				if (i < countryArray.length) myCountry = (Countries)(countryArray[i]);
    				//else;//do nothing
    				
    				Countries[] myBCs = myCountry.getBoarderCountries();
    				for (int k = 0; k < myBCs.length; k++)
    				{
    					//System.out.println("k = " + k);
    					Countries myBC = (Countries)(myBCs[k]);
    					//System.out.println(myBC);
    					//we need to try to find this country's name on the ArrayList
    					//and copy over additional data
    					for (int n = 0; n < countryArray.length; n++)
    					{
    						//System.out.println("n = " + n);
    						Countries mc = (Countries)(countryArray[n]);
    						//System.out.println(mc);
    						if (mc.getCountryName().equals(myBC.getCountryName()))
    						{
    							//System.out.println("old " + myBC.toString());
    							myBC = mc;
    							//System.out.println("new " + myBC.toString());
    							myBCs[k] = myBC;
    							//System.out.println();
    							break;
    						}
    						//else;//do nothing
    					}//end of n for loop
    				}//end of k for loop
    				
    				//update the array in the Countries object
    				myCountry.setBoarderCountriesList(myBCs);
    				
    			}//end of i for loop
    			
    			//set the value of Germany here
    			for (int i = 0; i < countryArray.length; i++)
    			{
    				Countries mc = (Countries)(countryArray[i]);
    				if (mc.getCountryName().equals("Germany"))
    				{
    					myGermany = mc;
    					break;
    				}
    				//else;//do nothing
    			}
    			//System.out.println(myGermany);
    			
    			germanBCList = myGermany.getBoarderCountries();
    		}
    		else if (userPreference == 2)
    		{
    			printListOfCountriesBoarder(myGermany);
    		}
    		else if (userPreference == 3)
    		{
    			countriesWithMoreThanNMPeople = generateArrayListNMillionPeople();
    			//System.out.println("countriesWithMoreThanNMPeople_SIZE = " +
    			//	countriesWithMoreThanNMPeople.size());
    			for (int i = 0; i < countriesWithMoreThanNMPeople.size(); i++)
    			{
    				Countries mc = (Countries)(countriesWithMoreThanNMPeople.get(i));
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    		}
    		else if (userPreference == 4)
    		{
    			germanBCListWithMoreThanNMPeople = generateArrayListBothGermanAndNMillionPeople();
    			//System.out.println("germanBCListWithMoreThanNMPeople_SIZE = " +
    			//	germanBCListWithMoreThanNMPeople.size());
    			for (int i = 0; i < germanBCListWithMoreThanNMPeople.size(); i++)
    			{
    				Countries mc = (Countries)(germanBCListWithMoreThanNMPeople.get(i));
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    		}
    		//else;//do nothing quit the program
    		
    		//end of loop code
    		if (userPreference == 5);//do nothing
    		else userPreference = -1;
    	}//end of outer while loop
    }
}