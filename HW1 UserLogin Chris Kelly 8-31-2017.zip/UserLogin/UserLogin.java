/**
 * @(#)UserLogin.java
 *
 *
 * @Chris Kelly
 * for Computer Science 2 Dr. Blanche Cohen
 * MSU Denver AES 220 from 12 - 2 PM
 *  
 * @version 1.00
 * Date:
 * 8-29-2017
 * 3:24 PM - 5:32 PM + 6:51 PM - 7:08 PM + 7:10 PM - 7:16 PM + 8:46 PM - 9:16 PM + 9:40 PM - 10:03 PM
 * (Set-up and designed the original program, and asked questions about the program's structure)
 * 
 * 8-30-2017 
 * 3:14 PM - 3:59 PM
 * (Made necessary changes to the program, from the answers to my questions) 
 *
 * This is a program that demonstrates writing to files,
 * by taking a username string from the keyboard as input,
 * then checking it to see if it has a certain special character,
 * a certain overall length, an uppercase character, and a number.
 */

import java.util.Scanner;
import java.io.IOException;
import java.io.PrintWriter;

public class UserLogin
{
    //constant that holds the minimum String length
    final int minLen = 5;
    
    //this holds the report to be generated
    private static StringBuffer report = null;
    private static Scanner in = new Scanner(System.in);
    //must be static to work correctly
    
    private boolean numFound = false;
    private boolean validCase = false;
    private boolean validLength = false;
    private boolean validSpecial = false;
    
    public UserLogin()
    {
    	greetUser();
    }
    
    //this prints an explanation of the program to the screen
    private void greetUser()
    {
    	System.out.println("Welcome user! Please enter a username ");
    	System.out.println("with at least one of all of the following:");
    	System.out.println("1. an uppercase letter,\n2. one digit,\n3. AND one of the following: !@#$");
    	System.out.println("The username must be at least " + minLen + " characters long");
    }
    
    //this gets the username from the user
    //the system.in indicates that the input
    //is coming from the keyboard
    private String readUserLoginFromUser()
    {
    	String userName = in.nextLine();
    	return userName;
    }
    
    //this method returns true if there is one
    //letter found to be upperCase
    //if the loop did not run this will return
    //false; all errors will be handled in a method below
    private boolean checkCase(String userName)
    {
    	validCase = false;
    	for (int i = 0; i < userName.length(); i++)
    	{
    		char myChar = userName.charAt(i);
    		if (Character.isLetter(myChar) &&
    			Character.isUpperCase(myChar))
    		{
    			validCase = true;
    			break;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return validCase;
    }
    
    //checks to see if the userName meets the length requirement
    //returns false if it does not
    private boolean checkLength(String userName)
    {
    	validLength = (userName.length() > (minLen - 1));
    	return validLength;
    }
    
    //this checks to see if there is at least one digit
    //if there is one it returns true; false otherwise
    private boolean checkDigit(String userName)
    {
    	numFound = false;
    	for (int i = 0; i < userName.length(); i++)
    	{
    		if (Character.isDigit(userName.charAt(i)))
    		{
    			numFound = true;
    			break;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return numFound;
    }
    
    //this code checks to see if there is one special character
    //a special character is not a number and not a letter
    //the !@#$ are valid anything else is not
    private boolean checkSpecial(String userName)
    {
    	validSpecial = false;
    	for (int i = 0; i < userName.length(); i++)
    	{
    		char myChar = userName.charAt(i);
    		if (!Character.isDigit(myChar) && !Character.isLetter(myChar))
    		{
    			if (myChar == ' ') validSpecial = false;//space check since they are invalid
    			else validSpecial = (myChar == '!' || myChar == '@' || myChar == '#' || myChar == '$');
    			//returns true if any above are found and false because an invalid one was found
    			return validSpecial;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return validSpecial;
    }
    
    //this method calls all of the above checks and
    //checks to see if any of the conditions are violated
    //if they are it will return false; true otherwise
    private boolean checkValidity(String userName)
    {
    	checkLength(userName);
    	checkSpecial(userName);
    	checkDigit(userName);
    	checkCase(userName);
    	return (validLength && validSpecial &&
    		numFound && validCase);
    }
    
    //this is pretty self explanitory it adds it to the report of the login file
    //this is done inside of the background unknown to the user
    private void addToReport(String userName)
    {
    	report.append("Login: " + userName + " (");
    	if (checkValidity(userName)) report.append("valid)\n");
    	else
    	{
    		report.append("invalid)\n");
    		if (!validCase) report.append("   -- no uppercase letter\n");
    		if (!numFound) report.append("   -- no digit\n");
    		if (!validSpecial) report.append("   -- invalid special character\n");
    		if (!validLength) report.append("   -- too short (minimum of " + minLen + " characters)\n");
    	}
    }
    
    //this method creates a file for the report and saves it on the system
    private void printReport()
    {
    	String fileName = "report.txt";
    	PrintWriter writer = null;
    	//try
    	//{
    		//creates the file stream here
    		//writer = new PrintWriter(fileName, "UTF-8");
    		
    		//does the file writing here
    		//writer.println(report.toString());
    		
    		//NOTE: printWriter.println() ignores the \n character in the string
    	//}
    	//catch(IOException e)
    	//{
    		//e.printStackTrace();//or do nothing
    	//}
    	
    	//need to close the file
    	//writer.close();
    	
    	
    	//PrintWriter writer = null;
    	try
    	{
    		writer = new PrintWriter(fileName, "UTF-8");
    		//printWriter.println() ignores the \n character
    		String parseReport = report.toString();
    		int strLen = 0;
    		while (parseReport.indexOf("\n") > -1)
    		{
    			String line = parseReport.substring(0, parseReport.indexOf("\n"));
    			
    			//we write to the file here
    			writer.println(line);
    			
    			//System.out.println("line = " + line);
    			//System.out.println("lineLen = " + line.length());
    			
    			line += "\n";
    			
    			strLen += line.length();
    			
    			//System.out.println("strLen = " + strLen);
    			//System.out.println("reportLen = " + report.length());
    			
    			//we see if the loop is ready to exit by incrementing the string length to what is al
    			if (strLen < report.length())
    			{
    				parseReport = parseReport.substring(parseReport.indexOf("\n") + 1);
    			}
    			else parseReport = "";
    		}//end of while loop
    		
    		//don't forget to close the file
    		writer.close();
    	}
    	catch(IOException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    //this prints the user information to the screen and
    //any accompanying error message if necessary
    private void printUser(String userName)
    {
    	System.out.print("Login: " + userName + "\t(");
    	if (checkValidity(userName)) System.out.println("valid)");
    	else
    	{
    		System.out.println("invalid)");
    		if (!validCase) System.out.println("   -- no uppercase letter");
    		if (!numFound) System.out.println("   -- no digit");
    		if (!validSpecial) System.out.println("   -- invalid special character");
    		if (!validLength) System.out.println("   -- too short (minimum of " + minLen + " characters)");
    	}
    	addToReport(userName);
    	//printReport();
    }
    
    public static void main(String[] args)
    {
    	report = new StringBuffer();
    	
    	/*
    	UserLogin user = new UserLogin();
    	String userName = "";
    	//userName = user.readUserLoginFromUser();
    	//test cases:
    	userName = "go_t";// (invalid)
    	//userName = "Happy#@!888";// (valid)
    	//userName = "happy#@!$88";// (invalid)
    	//userName = "#@!$88h";// (invalid)
    	//userName = "#@!$";// (invalid)
    	//userName = "h";// (invalid)
    	//userName = "_";// (invalid)
    	user.printUser(userName);
    	userName = "Happy#@!888";// (valid)
    	user.printUser(userName);
    	userName = "happy#@!$88";// (invalid)
    	user.printUser(userName);
    	userName = "#@!$88h";// (invalid)
    	user.printUser(userName);
    	userName = "#@!$";// (invalid)
    	user.printUser(userName);
    	userName = "h";// (invalid)
    	user.printUser(userName);
    	userName = "_";// (invalid)
    	user.printUser(userName);
    	user.printReport();
    	//*/
    	
    	///*
    	boolean run = true;
    	while (run == true)
    	{
	    	UserLogin user = new UserLogin();
	    	String userName = "";
	    	userName = user.readUserLoginFromUser();
	    	//test cases:
	    	//userName = "go_t";// (invalid)
	    	//userName = "Happy#@!888";// (valid)
	    	//userName = "happy#@!$88";// (invalid)
	    	//userName = "#@!$88h";// (invalid)
	    	//userName = "#@!$";// (invalid)
	    	//userName = "h";// (invalid)
	    	//userName = "_";// (invalid)
	    	user.printUser(userName);
	    	
	    	boolean invalidResponse = true;
	    	while (invalidResponse)
	    	{
	    		System.out.print("\nDo you wish to add another UserLogin? (Y,y,1; N,n,0): ");
	    		String myStr = in.nextLine();
	    		if (myStr.length() > 1);//do nothing
	    		else if (myStr.length() == 1)
	    		{
	    			if (myStr.equals("Y") || myStr.equals("y") || myStr.equals("1"))
	    			{
	    				run = true;
	    				invalidResponse = false;
	    			}
	    			else if (myStr.equals("N") || myStr.equals("n") || myStr.equals("0"))
	    			{
	    				run = false;
	    				invalidResponse = false;
	    			}
	    			else;//do nothing
	    		}
	    	}//end of inner while loop
	    	
	    	if (!run) user.printReport();
	    	else System.out.println();//do nothing
	    	
    	}//end of while loop//*/
    }
}