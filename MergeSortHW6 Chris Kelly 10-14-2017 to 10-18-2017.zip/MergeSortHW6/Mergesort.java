/**
 * @(#)Mergesort.java
 *
 *
 * @author 
 * @version 1.00 2017/10/16
 */


public class Mergesort {

    public Mergesort() {
    }
    
    public boolean isSorted(int[] arr)
    {
    	//System.out.println(arr[0].getClass().getName());
    	for (int i = 0; i < arr.length - 1; i++)
    	{
    		if (arr[i] > arr[i + 1]) return false;
    	}
    	return true;
    }
    public boolean isSorted(double[] arr)
    {
    	for (int i = 0; i < arr.length - 1; i++)
    	{
    		if (arr[i] > arr[i + 1]) return false;
    	}
    	return true;
    }
    public boolean isSorted(float[] arr)
    {
    	for (int i = 0; i < arr.length - 1; i++)
    	{
    		if (arr[i] > arr[i + 1]) return false;
    	}
    	return true;
    }
    public boolean isSorted(long[] arr)
    {
    	for (int i = 0; i < arr.length - 1; i++)
    	{
    		if (arr[i] > arr[i + 1]) return false;
    	}
    	return true;
    }
    //on this check for is sorted, if your type is not a number or a string, you must write your own method
    //because this method will return false by default because it cannot check if it is sorted or not....
    public boolean isSorted(Object[] arr)
    {
    	//expect Strings Integers Doubles Floats Longs anything else
    	//throw an exception or return false
    	String simpleTypeName = arr[0].getClass().getSimpleName();
    	//System.out.println(simpleTypeName);
    	if (simpleTypeName.equals("Integer"))
    	{
	    	for (int i = 0; i < arr.length - 1; i++)
	    	{
	    		if ((Integer)(arr[i]) > (Integer)(arr[i + 1])) return false;
	    	}
    	}
    	else if (simpleTypeName.equals("Double"))
    	{
	    	for (int i = 0; i < arr.length - 1; i++)
	    	{
	    		if ((Double)(arr[i]) > (Double)(arr[i + 1])) return false;
	    	}
    	}
    	else if (simpleTypeName.equals("Long"))
    	{
	    	for (int i = 0; i < arr.length - 1; i++)
	    	{
	    		if ((Long)(arr[i]) > (Long)(arr[i + 1])) return false;
	    	}
    	}
    	else if (simpleTypeName.equals("Float"))
    	{
	    	for (int i = 0; i < arr.length - 1; i++)
	    	{
	    		if ((Float)(arr[i]) > (Float)(arr[i + 1])) return false;
	    	}
    	}
    	else if (simpleTypeName.equals("String"))
    	{
    		//check if it is sorted numerically 0 before 9 then A before Z and Z before a and a before z
    		//need to do something here 10-17-2017
    		//each index in the array contains a string, a string has a variable length of characters
    		for (int n = 0; n < arr.length; n++)
    		{
    			String str = (String)(arr[n]);
    			//need to get the next string
    			String next = "";
    			if (n + 1 < arr.length) next = (String)(arr[n + 1]);
    			if (next.length() == 0) return true;
    			//else;//do nothing
    			//go through the current characters check casing... and check if it is a number first
    			for (int i = 0; i < str.length(); i++)
    			{
    				if (i < next.length())
    				{
    					//System.out.println("A str.charAt("+i+") = " + str.charAt(i));
    					//System.out.println("In ASCII that is = " + (int)(str.charAt(i)));
    					//System.out.println("B next.charAt("+i+") = " + next.charAt(i));
    					//System.out.println("In ASCII that is = " + (int)(next.charAt(i)));
    					if ((int)(str.charAt(i)) > (int)(next.charAt(i))) return false;
    					else if ((int)(str.charAt(i)) < (int)(next.charAt(i))) break;
    					//these words are in order move on to the next pair
    					//else;//they are the same, we need to check the next character
    				}
    			}
    		}//end of n for loop
    	}
    	else return false;
    	return true;
    }
    public boolean isSorted(String str1, String str2)
    {
    	String[] msarrs = new String[2];
    	msarrs[0] = str1;
    	msarrs[1] = str2;
    	return isSorted(msarrs);
    }
    
    //these are the MergeSort for the primitive data types
    //NOTE: Inside the int[] array MergeSort, I have included an example of what the stack looks
    //like to help one understand what this is doing. This example also shows how a simple list
    //will get sorted using this process.
    public int[] MergeSort(int[] arr)
    {
    	if (isSorted(arr)) return arr;
    	else if (arr.length < 2) return arr;
    	//else;//do nothing proceed
    	
    	//code to determine how big the two arrays are going to be
    	int ASize = 0;
    	int BSize = 0;
    	if (arr.length %2 == 0)
    	{
    		ASize = arr.length / 2;
    		BSize = arr.length / 2;
    	}
    	else
    	{
    		ASize = 1 + (arr.length / 2);
    		BSize = arr.length / 2;
    	}
    	
    	int[] PartA = new int[ASize];
    	for (int i = 0; i < ASize; i++) PartA[i] = arr[i];
    	int[] PartB = new int[BSize];
    	for (int i = 0; i < BSize; i++) PartB[i] = arr[ASize + i];
    	//now we have two arrays part A and part B
    	
    	//once we have sorted all of the parts into lengths of 1 each
    	//sort them and start sorting...
    	
    	//mergesort both halves then merge them by sorting them
    	//System.out.println("Calling MergeSort(PartA), PartALen = " + ASize + " With PartA Below:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	PartA = MergeSort(PartA);
    	//System.out.println("Calling MergeSort(PartB), PartBLen = " + BSize + " With PartB Below:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	PartB = MergeSort(PartB);
    	
    	//sort only the individual terms...
    	//then when we go to the merging, we sort the bigger pieces...
    	//when merging we do as follows:
    	
    	//(I will provide steps for: 10,3,42,9,6,5,4)
    	//merge sort breaks this in to 2 parts: Part A: 10,3,42,9; Part B: 6,5,4
    	//since their lengths are greater than one: Part A (A1): 10,3 (A2): 42,9 Part B (B1): 6,5 (B2): 4
    	//again: Part A (A1-1): 10 (A1-2): 3 (A2-1): 42 (A2-2): 9 Part B (B1-1): 6 (B1-2): 5 (B2): 4
    	//on the stack we have:
    	//
    	//MergeSort(OriginalArray);
    	//MergeSort(PartA); Part A: 10,3,42,9;
    	//MergeSort(A1); (A1): 10,3
    	//MergeSort(A1-1); (A1-1): 10
    	//MergeSort(A1-2); (A1-2): 3
    	//sort A1 here part A and B and merge
    	//MergeSort(A2); (A2): 42,9
    	//MergeSort(A2-1); (A2-1): 42
    	//MergeSort(A2-2); (A2-2): 9
    	//sort A2 here part A and B and merge
    	//sort all of PartA before merging then return this to PartA
    	//
    	//move on to the original PartB call now:
    	//MergeSort(PartB); Part B: 6,5,4
    	//MergeSort(B1); (B1): 6,5
    	//MergeSort(B1-1); (B1-1): 6
    	//MergeSort(B1-2); (B1-2): 5
    	//sort B1 here
    	//MergeSort(B2); (B2): 4
    	//sort B2 here
    	//sort all of PartB before merging then return this to PartB
    	
    	//PART A: 3,10,14 PART B: 9,20,42
    	//1. first start at index 0 for both
    	//2. check to see if we need to do a swap (A):
    	//A. if PartA[AIndex] > PartB[BIndex] swap:
    	//A-1. Since Element A is greater than B, add element B to the list and move the B pointer up
    	//B. else do nothing increment b index to check but always start it on the last added value
    	//3. Move PartB pointer to the next spot
    	//4. run check in step 2 again
    	//5. when we run out of spots in the B list, move the A pointer to the next spot
    	//6. run check in step 2 again only with the new AIndex
    	
    	//3,10,14 and 9,20,42 (precondition: this is sorted...)
    	//3 is less than 9 and 42 and 20 so 3 is the first element
    	//moving on to 10 since done with partB list for the first time.
    	//is ten less than 9 NO. We need to do a swap.
    	//(APointer stays on 10 while 9 drops down to take the next spot
    	//in the list, and the BPointer moves to 20)
    	//done with a list the rest of b list drops down and merges
    	//3,9,10,14,20,42
    	
    	//if item in part A is less than all of the items in part B, add it to the list
    	//else add item B to the list
    	
    	//if we are done with all of the items in A's list and NOT done with B's list,
    	//we want the remaining items to just straight be added to the list
    	
    	//code to print the arrays
    	//System.out.println("NEW PartA:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	//System.out.println("NEW PartB:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	
    	int li = 0, ai = 0, bi = 0, bspot = 0;
    	boolean breakOuter = false;
    	
    	if (ASize == 0 && BSize > 0) return PartB;
    	else if (BSize == 0 && ASize > 0) return PartA;
    	else if (ASize == BSize && ASize == 1)
    	{
    		if (PartA[0] > PartB[0])
			{
				//is ten less than 9 NO. We need to do a swap.
				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
				//in the list, and the BPointer moves to 20)
				
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
				//then A
				arr[li] = PartA[0];
				li++;
			}
			else
			{
				//then A
				arr[li] = PartA[0];
				li++;
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
			}
    	}
    	else
    	{
	    	//we know that ASize > 1 and BSize > 1
	    	for (ai = 0; ai < ASize; ai += 0)
	    	{
	    		boolean add = false;
	    		if (breakOuter) break;
	    		
	    		boolean addElementAToList = true;
	    		for (bi = bspot; bi < BSize; bi++)
	    		{
	    			if (li == arr.length || li > arr.length)
	    			{
	    				breakOuter = true;
	    				break;
	    			}
	    			
	    			//System.out.println("PartA["+ai+"] = " + PartA[ai]);
	    			//System.out.println("PartB["+bi+"] = " + PartB[bi]);
	    			if (PartA[ai] > PartB[bi])
	    			{
	    				//System.out.println("Add ElementB Immidiately To The List!");
	    				//is ten less than 9 NO. We need to do a swap.
	    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
	    				//in the list, and the BPointer moves to 20)
	    				
	    				//add contents of B to the list
	    				addElementAToList = false;
	    				arr[li] = PartB[bi];
	    				//System.out.println("arr["+li+"] = " + arr[li]);
	    				li++;
	    				bspot++;
	    			}
	    			//else;//do nothing
	    		}//end of bi for loop
	    		
	    		//System.out.println("addElementAToList = " + addElementAToList);
	    		if (addElementAToList)
	    		{
	    			arr[li] = PartA[ai];
	    			//System.out.println("arr["+li+"] = " + arr[li]);
	    			li++;
	    			add = true;
	    		}
	    		
	    		//we only increment, and we only increment this when we found an a element
	    		if (add) ai++;
	    	}//end of ai for loop
    	}
    	
    	//System.out.println("li = " + li);
    	//System.out.println("orig array length = " + arr.length);
    	//System.out.println("ai = " + ai);
    	//System.out.println("ASize = " + ASize);
    	//System.out.println("bi = " + bi);
    	//System.out.println("bspot = " + bspot);
    	//System.out.println("BSize = " + BSize);
    	
    	if (bspot < BSize && BSize > 1)
    	{
    		for (int i = bspot; i < BSize; i++)
    		{
    			arr[li] = PartB[i];
    			//System.out.println("arr["+li+"] = " + arr[li]);
    			li++;
    		}
    	}
    	
    	//System.out.println("NEW ARRAY:");
    	//for (int i = 0; i < arr.length; i++) System.out.println(arr[i]);
    	return arr;
    }
    public double[] MergeSort(double[] arr)
    {
    	if (isSorted(arr)) return arr;
    	else if (arr.length < 2) return arr;
    	//else;//do nothing proceed
    	
    	//code to determine how big the two arrays are going to be
    	int ASize = 0;
    	int BSize = 0;
    	if (arr.length %2 == 0)
    	{
    		ASize = arr.length / 2;
    		BSize = arr.length / 2;
    	}
    	else
    	{
    		ASize = 1 + (arr.length / 2);
    		BSize = arr.length / 2;
    	}
    	
    	double[] PartA = new double[ASize];
    	for (int i = 0; i < ASize; i++) PartA[i] = arr[i];
    	double[] PartB = new double[BSize];
    	for (int i = 0; i < BSize; i++) PartB[i] = arr[ASize + i];
    	//now we have two arrays part A and part B
    	
    	//once we have sorted all of the parts into lengths of 1 each
    	//sort them and start sorting...
    	
    	//mergesort both halves then merge them by sorting them
    	//System.out.println("Calling MergeSort(PartA), PartALen = " + ASize + " With PartA Below:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	PartA = MergeSort(PartA);
    	//System.out.println("Calling MergeSort(PartB), PartBLen = " + BSize + " With PartB Below:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	PartB = MergeSort(PartB);
    	
    	//code for the sorting and merging begins here:
    	
    	//code to print the arrays
    	//System.out.println("NEW PartA:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	//System.out.println("NEW PartB:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	
    	int li = 0, ai = 0, bi = 0, bspot = 0;
    	boolean breakOuter = false;
    	
    	if (ASize == 0 && BSize > 0) return PartB;
    	else if (BSize == 0 && ASize > 0) return PartA;
    	else if (ASize == BSize && ASize == 1)
    	{
    		if (PartA[0] > PartB[0])
			{
				//is ten less than 9 NO. We need to do a swap.
				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
				//in the list, and the BPointer moves to 20)
				
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
				//then A
				arr[li] = PartA[0];
				li++;
			}
			else
			{
				//then A
				arr[li] = PartA[0];
				li++;
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
			}
    	}
    	else
    	{
	    	//we know that ASize > 1 and BSize > 1
	    	for (ai = 0; ai < ASize; ai += 0)
	    	{
	    		boolean add = false;
	    		if (breakOuter) break;
	    		
	    		boolean addElementAToList = true;
	    		for (bi = bspot; bi < BSize; bi++)
	    		{
	    			if (li == arr.length || li > arr.length)
	    			{
	    				breakOuter = true;
	    				break;
	    			}
	    			
	    			//System.out.println("PartA["+ai+"] = " + PartA[ai]);
	    			//System.out.println("PartB["+bi+"] = " + PartB[bi]);
	    			if (PartA[ai] > PartB[bi])
	    			{
	    				//System.out.println("Add ElementB Immidiately To The List!");
	    				//is ten less than 9 NO. We need to do a swap.
	    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
	    				//in the list, and the BPointer moves to 20)
	    				
	    				//add contents of B to the list
	    				addElementAToList = false;
	    				arr[li] = PartB[bi];
	    				//System.out.println("arr["+li+"] = " + arr[li]);
	    				li++;
	    				bspot++;
	    			}
	    			//else;//do nothing
	    		}//end of bi for loop
	    		
	    		//System.out.println("addElementAToList = " + addElementAToList);
	    		if (addElementAToList)
	    		{
	    			arr[li] = PartA[ai];
	    			//System.out.println("arr["+li+"] = " + arr[li]);
	    			li++;
	    			add = true;
	    		}
	    		
	    		//we only increment, and we only increment this when we found an a element
	    		if (add) ai++;
	    	}//end of ai for loop
    	}
    	
    	//System.out.println("li = " + li);
    	//System.out.println("orig array length = " + arr.length);
    	//System.out.println("ai = " + ai);
    	//System.out.println("ASize = " + ASize);
    	//System.out.println("bi = " + bi);
    	//System.out.println("bspot = " + bspot);
    	//System.out.println("BSize = " + BSize);
    	
    	if (bspot < BSize && BSize > 1)
    	{
    		for (int i = bspot; i < BSize; i++)
    		{
    			arr[li] = PartB[i];
    			//System.out.println("arr["+li+"] = " + arr[li]);
    			li++;
    		}
    	}
    	
    	//System.out.println("NEW ARRAY:");
    	//for (int i = 0; i < arr.length; i++) System.out.println(arr[i]);
    	return arr;
    }
    public float[] MergeSort(float[] arr)
    {
    	if (isSorted(arr)) return arr;
    	else if (arr.length < 2) return arr;
    	//else;//do nothing proceed
    	
    	//code to determine how big the two arrays are going to be
    	int ASize = 0;
    	int BSize = 0;
    	if (arr.length %2 == 0)
    	{
    		ASize = arr.length / 2;
    		BSize = arr.length / 2;
    	}
    	else
    	{
    		ASize = 1 + (arr.length / 2);
    		BSize = arr.length / 2;
    	}
    	
    	float[] PartA = new float[ASize];
    	for (int i = 0; i < ASize; i++) PartA[i] = arr[i];
    	float[] PartB = new float[BSize];
    	for (int i = 0; i < BSize; i++) PartB[i] = arr[ASize + i];
    	//now we have two arrays part A and part B
    	
    	//once we have sorted all of the parts into lengths of 1 each
    	//sort them and start sorting...
    	
    	//mergesort both halves then merge them by sorting them
    	//System.out.println("Calling MergeSort(PartA), PartALen = " + ASize + " With PartA Below:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	PartA = MergeSort(PartA);
    	//System.out.println("Calling MergeSort(PartB), PartBLen = " + BSize + " With PartB Below:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	PartB = MergeSort(PartB);
    	
    	//code for the sorting and merging begins here:
    	
    	//code to print the arrays
    	//System.out.println("NEW PartA:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	//System.out.println("NEW PartB:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	
    	int li = 0, ai = 0, bi = 0, bspot = 0;
    	boolean breakOuter = false;
    	
    	if (ASize == 0 && BSize > 0) return PartB;
    	else if (BSize == 0 && ASize > 0) return PartA;
    	else if (ASize == BSize && ASize == 1)
    	{
    		if (PartA[0] > PartB[0])
			{
				//is ten less than 9 NO. We need to do a swap.
				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
				//in the list, and the BPointer moves to 20)
				
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
				//then A
				arr[li] = PartA[0];
				li++;
			}
			else
			{
				//then A
				arr[li] = PartA[0];
				li++;
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
			}
    	}
    	else
    	{
	    	//we know that ASize > 1 and BSize > 1
	    	for (ai = 0; ai < ASize; ai += 0)
	    	{
	    		boolean add = false;
	    		if (breakOuter) break;
	    		
	    		boolean addElementAToList = true;
	    		for (bi = bspot; bi < BSize; bi++)
	    		{
	    			if (li == arr.length || li > arr.length)
	    			{
	    				breakOuter = true;
	    				break;
	    			}
	    			
	    			//System.out.println("PartA["+ai+"] = " + PartA[ai]);
	    			//System.out.println("PartB["+bi+"] = " + PartB[bi]);
	    			if (PartA[ai] > PartB[bi])
	    			{
	    				//System.out.println("Add ElementB Immidiately To The List!");
	    				//is ten less than 9 NO. We need to do a swap.
	    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
	    				//in the list, and the BPointer moves to 20)
	    				
	    				//add contents of B to the list
	    				addElementAToList = false;
	    				arr[li] = PartB[bi];
	    				//System.out.println("arr["+li+"] = " + arr[li]);
	    				li++;
	    				bspot++;
	    			}
	    			//else;//do nothing
	    		}//end of bi for loop
	    		
	    		//System.out.println("addElementAToList = " + addElementAToList);
	    		if (addElementAToList)
	    		{
	    			arr[li] = PartA[ai];
	    			//System.out.println("arr["+li+"] = " + arr[li]);
	    			li++;
	    			add = true;
	    		}
	    		
	    		//we only increment, and we only increment this when we found an a element
	    		if (add) ai++;
	    	}//end of ai for loop
    	}
    	
    	//System.out.println("li = " + li);
    	//System.out.println("orig array length = " + arr.length);
    	//System.out.println("ai = " + ai);
    	//System.out.println("ASize = " + ASize);
    	//System.out.println("bi = " + bi);
    	//System.out.println("bspot = " + bspot);
    	//System.out.println("BSize = " + BSize);
    	
    	if (bspot < BSize && BSize > 1)
    	{
    		for (int i = bspot; i < BSize; i++)
    		{
    			arr[li] = PartB[i];
    			//System.out.println("arr["+li+"] = " + arr[li]);
    			li++;
    		}
    	}
    	
    	//System.out.println("NEW ARRAY:");
    	//for (int i = 0; i < arr.length; i++) System.out.println(arr[i]);
    	return arr;
    }
    public long[] MergeSort(long[] arr)
    {
    	if (isSorted(arr)) return arr;
    	else if (arr.length < 2) return arr;
    	//else;//do nothing proceed
    	
    	//code to determine how big the two arrays are going to be
    	int ASize = 0;
    	int BSize = 0;
    	if (arr.length %2 == 0)
    	{
    		ASize = arr.length / 2;
    		BSize = arr.length / 2;
    	}
    	else
    	{
    		ASize = 1 + (arr.length / 2);
    		BSize = arr.length / 2;
    	}
    	
    	long[] PartA = new long[ASize];
    	for (int i = 0; i < ASize; i++) PartA[i] = arr[i];
    	long[] PartB = new long[BSize];
    	for (int i = 0; i < BSize; i++) PartB[i] = arr[ASize + i];
    	//now we have two arrays part A and part B
    	
    	//once we have sorted all of the parts into lengths of 1 each
    	//sort them and start sorting...
    	
    	//mergesort both halves then merge them by sorting them
    	//System.out.println("Calling MergeSort(PartA), PartALen = " + ASize + " With PartA Below:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	PartA = MergeSort(PartA);
    	//System.out.println("Calling MergeSort(PartB), PartBLen = " + BSize + " With PartB Below:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	PartB = MergeSort(PartB);
    	
    	//code for the sorting and merging begins here:
    	
    	//code to print the arrays
    	//System.out.println("NEW PartA:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	//System.out.println("NEW PartB:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	
    	int li = 0, ai = 0, bi = 0, bspot = 0;
    	boolean breakOuter = false;
    	
    	if (ASize == 0 && BSize > 0) return PartB;
    	else if (BSize == 0 && ASize > 0) return PartA;
    	else if (ASize == BSize && ASize == 1)
    	{
    		if (PartA[0] > PartB[0])
			{
				//is ten less than 9 NO. We need to do a swap.
				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
				//in the list, and the BPointer moves to 20)
				
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
				//then A
				arr[li] = PartA[0];
				li++;
			}
			else
			{
				//then A
				arr[li] = PartA[0];
				li++;
				//add contents of B to the list
				arr[li] = PartB[0];
				li++;
			}
    	}
    	else
    	{
	    	//we know that ASize > 1 and BSize > 1
	    	for (ai = 0; ai < ASize; ai += 0)
	    	{
	    		boolean add = false;
	    		if (breakOuter) break;
	    		
	    		boolean addElementAToList = true;
	    		for (bi = bspot; bi < BSize; bi++)
	    		{
	    			if (li == arr.length || li > arr.length)
	    			{
	    				breakOuter = true;
	    				break;
	    			}
	    			
	    			//System.out.println("PartA["+ai+"] = " + PartA[ai]);
	    			//System.out.println("PartB["+bi+"] = " + PartB[bi]);
	    			if (PartA[ai] > PartB[bi])
	    			{
	    				//System.out.println("Add ElementB Immidiately To The List!");
	    				//is ten less than 9 NO. We need to do a swap.
	    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
	    				//in the list, and the BPointer moves to 20)
	    				
	    				//add contents of B to the list
	    				addElementAToList = false;
	    				arr[li] = PartB[bi];
	    				//System.out.println("arr["+li+"] = " + arr[li]);
	    				li++;
	    				bspot++;
	    			}
	    			//else;//do nothing
	    		}//end of bi for loop
	    		
	    		//System.out.println("addElementAToList = " + addElementAToList);
	    		if (addElementAToList)
	    		{
	    			arr[li] = PartA[ai];
	    			//System.out.println("arr["+li+"] = " + arr[li]);
	    			li++;
	    			add = true;
	    		}
	    		
	    		//we only increment, and we only increment this when we found an a element
	    		if (add) ai++;
	    	}//end of ai for loop
    	}
    	
    	//System.out.println("li = " + li);
    	//System.out.println("orig array length = " + arr.length);
    	//System.out.println("ai = " + ai);
    	//System.out.println("ASize = " + ASize);
    	//System.out.println("bi = " + bi);
    	//System.out.println("bspot = " + bspot);
    	//System.out.println("BSize = " + BSize);
    	
    	if (bspot < BSize && BSize > 1)
    	{
    		for (int i = bspot; i < BSize; i++)
    		{
    			arr[li] = PartB[i];
    			//System.out.println("arr["+li+"] = " + arr[li]);
    			li++;
    		}
    	}
    	
    	//System.out.println("NEW ARRAY:");
    	//for (int i = 0; i < arr.length; i++) System.out.println(arr[i]);
    	return arr;
    }
    
    //NOTE: This is NOT meant to deal with any other data type other than numbers and Strings objects.
    //This will just return the list and the isSorted will always return false because it cannot sort it.
    public Object[] MergeSort(Object[] arr)
    {
    	if (isSorted(arr)) return arr;
    	else if (arr.length < 2) return arr;
    	//else;//do nothing proceed
    	
    	//code to determine how big the two arrays are going to be
    	int ASize = 0;
    	int BSize = 0;
    	if (arr.length %2 == 0)
    	{
    		ASize = arr.length / 2;
    		BSize = arr.length / 2;
    	}
    	else
    	{
    		ASize = 1 + (arr.length / 2);
    		BSize = arr.length / 2;
    	}
    	
    	Object[] PartA = new Object[ASize];
    	for (int i = 0; i < ASize; i++) PartA[i] = arr[i];
    	Object[] PartB = new Object[BSize];
    	for (int i = 0; i < BSize; i++) PartB[i] = arr[ASize + i];
    	//now we have two arrays part A and part B
    	
    	//once we have sorted all of the parts into lengths of 1 each
    	//sort them and start sorting...
    	
    	//mergesort both halves then merge them by sorting them
    	//System.out.println("Calling MergeSort(PartA), PartALen = " + ASize + " With PartA Below:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	PartA = MergeSort(PartA);
    	//System.out.println("Calling MergeSort(PartB), PartBLen = " + BSize + " With PartB Below:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	PartB = MergeSort(PartB);
    	
    	//code for the sorting and the merging begins here:
    	
    	//code to print the arrays
    	//System.out.println("NEW PartA:");
    	//for (int i = 0; i < ASize; i++) System.out.println(PartA[i]);
    	//System.out.println("NEW PartB:");
    	//for (int i = 0; i < BSize; i++) System.out.println(PartB[i]);
    	
    	String simpleTypeName = arr[0].getClass().getSimpleName();
    	int li = 0, ai = 0, bi = 0, bspot = 0;
    	boolean breakOuter = false;
    	
    	if (ASize == 0 && BSize > 0) return PartB;
    	else if (BSize == 0 && ASize > 0) return PartA;
    	else if (ASize == BSize && ASize == 1)
    	{
    		//System.out.println(simpleTypeName);
	    	if (simpleTypeName.equals("Integer"))
	    	{
	    		if ((Integer)(PartA[0]) > (Integer)(PartB[0]))
				{
					//is ten less than 9 NO. We need to do a swap.
					//(APointer stays on 10 while 9 (in B) drops down to take the next spot
					//in the list, and the BPointer moves to 20)
					
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
				else
				{
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
	    	}
    		else if (simpleTypeName.equals("Double"))
	    	{
	    		if ((Double)(PartA[0]) > (Double)(PartB[0]))
				{
					//is ten less than 9 NO. We need to do a swap.
					//(APointer stays on 10 while 9 (in B) drops down to take the next spot
					//in the list, and the BPointer moves to 20)
					
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
				else
				{
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
	    	}
	    	else if (simpleTypeName.equals("Float"))
	    	{
	    		if ((Float)(PartA[0]) > (Float)(PartB[0]))
				{
					//is ten less than 9 NO. We need to do a swap.
					//(APointer stays on 10 while 9 (in B) drops down to take the next spot
					//in the list, and the BPointer moves to 20)
					
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
				else
				{
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
	    	}
	    	else if (simpleTypeName.equals("Long"))
	    	{
	    		if ((Long)(PartA[0]) > (Long)(PartB[0]))
				{
					//is ten less than 9 NO. We need to do a swap.
					//(APointer stays on 10 while 9 (in B) drops down to take the next spot
					//in the list, and the BPointer moves to 20)
					
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
				else
				{
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
	    	}
	    	else if (simpleTypeName.equals("String"))
	    	{
	    		//the is sorted checks if A is a string and that if A[i] > B[i] it returns false
	    		//if this is never the case, it will return true.
	    		if (!isSorted((String)(PartA[0]), (String)(PartB[0])))
				{
					//System.out.println("B is added before A");
					//is ten less than 9 NO. We need to do a swap.
					//(APointer stays on 10 while 9 (in B) drops down to take the next spot
					//in the list, and the BPointer moves to 20)
					
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
				else
				{
					//then A
					arr[li] = PartA[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
					//add contents of B to the list
					arr[li] = PartB[0];
					//System.out.println("arr["+li+"] = " + arr[li]);
					li++;
				}
	    	}
	    	else return arr;//we cannot use this code to get a correct result
    	}
    	else
    	{
	    	//we know that ASize > 1 and BSize > 1
	    	for (ai = 0; ai < ASize; ai += 0)
	    	{
	    		boolean add = false;
	    		if (breakOuter) break;
	    		
	    		boolean addElementAToList = true;
	    		for (bi = bspot; bi < BSize; bi++)
	    		{
	    			if (li == arr.length || li > arr.length)
	    			{
	    				breakOuter = true;
	    				break;
	    			}
	    			
	    			//System.out.println("PartA["+ai+"] = " + PartA[ai]);
	    			//System.out.println("PartB["+bi+"] = " + PartB[bi]);
	    			//System.out.println(simpleTypeName);
			    	if (simpleTypeName.equals("Integer"))
			    	{
			    		if ((Integer)(PartA[ai]) > (Integer)(PartB[bi]))
		    			{
		    				//System.out.println("Add ElementB Immidiately To The List!");
		    				//is ten less than 9 NO. We need to do a swap.
		    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
		    				//in the list, and the BPointer moves to 20)
		    				
		    				//add contents of B to the list
		    				addElementAToList = false;
		    				arr[li] = PartB[bi];
		    				//System.out.println("arr["+li+"] = " + arr[li]);
		    				li++;
		    				bspot++;
		    			}
			    	}
			    	else if (simpleTypeName.equals("Double"))
			    	{
			    		if ((Double)(PartA[ai]) > (Double)(PartB[bi]))
		    			{
		    				//System.out.println("Add ElementB Immidiately To The List!");
		    				//is ten less than 9 NO. We need to do a swap.
		    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
		    				//in the list, and the BPointer moves to 20)
		    				
		    				//add contents of B to the list
		    				addElementAToList = false;
		    				arr[li] = PartB[bi];
		    				//System.out.println("arr["+li+"] = " + arr[li]);
		    				li++;
		    				bspot++;
		    			}
			    	}
			    	else if (simpleTypeName.equals("Float"))
			    	{
			    		if ((Float)(PartA[ai]) > (Float)(PartB[bi]))
		    			{
		    				//System.out.println("Add ElementB Immidiately To The List!");
		    				//is ten less than 9 NO. We need to do a swap.
		    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
		    				//in the list, and the BPointer moves to 20)
		    				
		    				//add contents of B to the list
		    				addElementAToList = false;
		    				arr[li] = PartB[bi];
		    				//System.out.println("arr["+li+"] = " + arr[li]);
		    				li++;
		    				bspot++;
		    			}
			    	}
			    	else if (simpleTypeName.equals("Long"))
			    	{
			    		if ((Long)(PartA[ai]) > (Long)(PartB[bi]))
		    			{
		    				//System.out.println("Add ElementB Immidiately To The List!");
		    				//is ten less than 9 NO. We need to do a swap.
		    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
		    				//in the list, and the BPointer moves to 20)
		    				
		    				//add contents of B to the list
		    				addElementAToList = false;
		    				arr[li] = PartB[bi];
		    				//System.out.println("arr["+li+"] = " + arr[li]);
		    				li++;
		    				bspot++;
		    			}
			    	}
			    	else if (simpleTypeName.equals("String"))
			    	{
			    		//the is sorted checks if A is a string and that if A[i] > B[i] it returns false
			    		//if this is never the case, it will return true.
			    		if (!isSorted((String)(PartA[ai]), (String)(PartB[bi])))
						{
			    			//System.out.println("Add ElementB Immidiately To The List!");
		    				//is ten less than 9 NO. We need to do a swap.
		    				//(APointer stays on 10 while 9 (in B) drops down to take the next spot
		    				//in the list, and the BPointer moves to 20)
		    				
		    				//add contents of B to the list
		    				addElementAToList = false;
		    				arr[li] = PartB[bi];
		    				//System.out.println("arr["+li+"] = " + arr[li]);
		    				li++;
		    				bspot++;
		    			}
			    	}
			    	else return arr;//we cannot use this code to get a correct result	
	    		}//end of bi for loop
	    		
	    		//System.out.println("addElementAToList = " + addElementAToList);
	    		if (addElementAToList)
	    		{
	    			arr[li] = PartA[ai];
	    			//System.out.println("arr["+li+"] = " + arr[li]);
	    			li++;
	    			add = true;
	    		}
	    		
	    		//we only increment, and we only increment this when we found an a element
	    		if (add) ai++;
	    	}//end of ai for loop
    	}
    	
    	//System.out.println("li = " + li);
    	//System.out.println("orig array length = " + arr.length);
    	//System.out.println("ai = " + ai);
    	//System.out.println("ASize = " + ASize);
    	//System.out.println("bi = " + bi);
    	//System.out.println("bspot = " + bspot);
    	//System.out.println("BSize = " + BSize);
    	
    	if (bspot < BSize && BSize > 1)
    	{
    		for (int i = bspot; i < BSize; i++)
    		{
    			arr[li] = PartB[i];
    			//System.out.println("arr["+li+"] = " + arr[li]);
    			li++;
    		}
    	}
    	
    	//System.out.println("NEW ARRAY:");
    	//for (int i = 0; i < arr.length; i++) System.out.println(arr[i]);
    	return arr;
    }
}