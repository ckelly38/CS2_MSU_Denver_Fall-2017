/**
 * @(#)HW6.java
 * Dates:
 * 10-16-2017
 * 3:20 PM - 5:31 PM + 10:37 PM - 11:51 PM
 * Today, I set up the driver class for the project. This class reads the range in from the user, then it
 * randomly generates the data. The Mergesort class is used to sort the data using Mergesort.
 * 
 * I need some more help to understand MergeSort, and the other sorts. I also want to know how to make what
 * I have so far type independent (so I don't have to copy everything and rewrite it for all of the other
 * numeric types: Double, double, float ...).
 * 
 * 10-17-2017
 * 6:38 PM - 9:23 PM + 9:49 PM - 12:18 AM
 * Today, I reworked the sorting and merge at the end portion of this. I also tried to get generics to cooporate
 * without writing too many versions of the same methods. I also made a mini program to test this to see if it
 * works inside of the main method.
 * 
 * I still need to finish: the MergeSort for Strings and the other classes and
 * the corresponding isSorted methods. I also need to get this program to call my get user input method again.
 * 
 * 10-18-2017
 * 3:19 PM - 4:40 PM + 6:23 PM - 8:14 PM
 * Today, I finished the program. I also gave the user the chance to enter how big the strings should be.
 * I also improved my sorting program for the strings, and fixed the no reset bug that I found yesterday.
 *
 * The goal of this project is to write a mergesort algorithmn.
 * 
 * @author Chris Kelly
 * @version 1.00 2017/10/16
 */

import java.util.ArrayList;//used on frequency check
import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;
import java.util.InputMismatchException;
import java.util.GregorianCalendar;//java 7 not java 8 on my machine
import java.util.Calendar;//java 7 not java 8 on my machine
public class HW6 {

    public HW6() {
    	
    }
    
    private static int BIG = 0;
    private static int SIZE = 0;
    private static boolean resetSizeAndBig = true;
    //this allows you to set SIZE and BIG with different values
    //if this is false, you only get asked for these values once,
    //and they stay the same for the entire program
    
    //the rest of these variables are used for timing of the sort
    private static long internalStartTime = 0;
    private static long internalEndTime = 0;
    private static long MergeSortStartTime = 0;
    private static long MergeSortEndTime = 0;
    //hours[0],minutes[1],seconds[2],milliseconds[3]
    private static int[] internalStartWallClock = new int[4];
    private static int[] internalEndWallClock = new int[4];
    private static int[] MergeSortStartWallClock = new int[4];
    private static int[] MergeSortEndWallClock = new int[4];
    
    private static int stringSizeGenerated = 6;
    public static void getUserInput(boolean askBig, boolean isNotAString)
    {
    	Scanner scanner = new Scanner(System.in);
    	if (resetSizeAndBig)
    	{
	    	SIZE = 0;
	    	BIG = 0;
    	}
    	
    	//if the data type is a string BIG is not used in the program
    	while(SIZE < 1)
	    {
	    	System.out.print("Enter how big you want the array to be: ");
	    	try
	    	{
	    		SIZE = scanner.nextInt();
	    	}
	    	catch(InputMismatchException e)
	    	{
	    		scanner.reset();
	    		scanner.next();
	    		SIZE = 0;
	    	}
	    	
	    	if (SIZE < 1)
	    	{
	    		System.out.println("ERROR: INVALID INPUT!");
	    	}
	    	else break;
	    }
	    
	    if (askBig)
	    {
	    	while(BIG < 1)
		    {
		    	if (isNotAString) System.out.print("Enter the biggest number that can be in the array: ");
		    	else System.out.print("Enter the size for all of the strings generated: ");
		    	try
		    	{
		    		BIG = scanner.nextInt();
		    	}
		    	catch(InputMismatchException e)
		    	{
		    		scanner.reset();
		    		scanner.next();
		    		BIG = 0;
		    	}
		    	
		    	if (BIG < 1)
		    	{
		    		System.out.println("ERROR: INVALID INPUT!");
		    	}
		    	else break;
		    }//end of while loop
		    if (isNotAString == false) stringSizeGenerated = BIG;
	    }
	    else
	    {
	    	if (isNotAString == false) stringSizeGenerated = 6;
	    }
    }
    public static void getUserInput(boolean askBig)
    {
    	getUserInput(askBig, true);
    }
    public static void getUserInput()
    {
    	getUserInput(true);
    }
    
    //clock methods are below
    //this is where the clocks start and stop the isInternalSort identifies the sort, and the isCPU identifies
    //the clock there are two clocks and two sorts, and you must start and stop them (8 calls to this method)
    public static void startStopSortClock(boolean start, boolean isInternalSort, boolean isCPU)
    {
    	if (isCPU)
		{
			//the long miliseconds
			if (isInternalSort)
			{
				if (start) internalStartTime = System.nanoTime();
				else internalEndTime = System.nanoTime();
				//if (!start) System.out.println("internalEndTime = " + internalEndTime);
				//System.out.println("internalStartTime = " + internalStartTime);
			}
			else
			{
				if (start) MergeSortStartTime = System.nanoTime();
				else MergeSortEndTime = System.nanoTime();
				//if (!start) System.out.println("MergeSortEndTime = " + MergeSortEndTime);
				//System.out.println("MergeSortStartTime = " + MergeSortStartTime);
			}
		}
		else
		{
			final GregorianCalendar gc = new GregorianCalendar();
			//the wall clock then
			if (isInternalSort)
			{
				if (start)
				{
					internalStartWallClock[0] = gc.get(Calendar.HOUR);
    				internalStartWallClock[1] = gc.get(Calendar.MINUTE);
				    internalStartWallClock[2] = gc.get(Calendar.SECOND);
				    internalStartWallClock[3] = gc.get(Calendar.MILLISECOND);
				}
				else
				{
					internalEndWallClock[0] = gc.get(Calendar.HOUR);
    				internalEndWallClock[1] = gc.get(Calendar.MINUTE);
				    internalEndWallClock[2] = gc.get(Calendar.SECOND);
				    internalEndWallClock[3] = gc.get(Calendar.MILLISECOND);
				}
			}
			else
			{
				if (start)
				{
					MergeSortStartWallClock[0] = gc.get(Calendar.HOUR);
    				MergeSortStartWallClock[1] = gc.get(Calendar.MINUTE);
				    MergeSortStartWallClock[2] = gc.get(Calendar.SECOND);
				    MergeSortStartWallClock[3] = gc.get(Calendar.MILLISECOND);
				}
				else
				{
					MergeSortEndWallClock[0] = gc.get(Calendar.HOUR);
    				MergeSortEndWallClock[1] = gc.get(Calendar.MINUTE);
				    MergeSortEndWallClock[2] = gc.get(Calendar.SECOND);
				    MergeSortEndWallClock[3] = gc.get(Calendar.MILLISECOND);
				}
			}
		}
    }
    
    //computes the difference of two times on the same day (it will be wrong if you go over midnight)
    //this methods modifies the stored values for the times (for ease of subtraction)
    //if the start is greater than the end, it will return a negative value (it swaps them and inverts the magnitude)
    //then it returns the result in a String
    //isInternal referrs to the type of sort is it the internal sort (true) or is it the BubbleSort (false)
    public static String getSortWallClockTime(boolean isInternal)
    {
    	String str = "";
    	//returns a string of hours:minutes:seconds.miliseconds for the difference
    	//we will use the GregorianCalendar variables to get the calendar and then be able
    	//to do that
    	//12:19:5.6
    	//-11:20:4.4
    	//=2:23:1.2
    	//start with milliseconds then go to seconds
    	//if (time_unit)B < (time_unit)A: minB+60 and hrB-1 then subtract
    	//else just directly subtract
    	
    	int millidifference = 0;
    	int seconddifference = 0;
    	int minutedifference = 0;
    	int hourdifference = 0;
    	//if (isInternal) millidifference = internalEndMillisecond - internalStartMillisecond;
    	//else millidifference = BubbleSortEndMillisecond - BubbleSortStartMillisecond;
    	
    	//cannot run this across days (will return negative answer)
    	
    	//if current difference is negative, we need to borrow
    	//we need to first check the next number over to see if it is > 0, if it is borrow from
    	//it by subtracting 1 from it and adding the conversion factor to the difference (if
    	//immediately next to it) else we could not borrow from the immediate try the one over from
    	//that by checking if it is > 0, if we can borrow from it, then we subtract one from it (add
    	//the conversion factor to the next one close to it, then check to see if we can borrow from the
    	//next one over, if we can subtract one from that new number and add the conversion factor
    	//to the difference)
    	
    	//  00:00:0.3
    	// -00:00:0.4
    	//=-00:00:0.1
    	
    	//System.out.println("isInternal = " + isInternal);
    	
    	//need to check if startTime is greater than the endTime (needs to be swapped before
    	//subtraction but difference is negative)
    	boolean swapAll = false;
    	//System.out.println("hr:mn:sc.mis (hours:minutes:seconds.milliseconds)");
    	if (isInternal)
    	{
    		//not formatted print statements the return statement is properly formatted
    		//System.out.print(internalEndWallClock[0]+":"+internalEndWallClock[1]+":"+internalEndWallClock[2]+".");
    		//System.out.println(internalEndWallClock[3]);
    		//System.out.print(internalStartWallClock[0]+":"+internalStartWallClock[1]+":");
    		//System.out.println(internalStartWallClock[2]+"."+internalStartWallClock[3]);
    		
    		if (internalStartWallClock[0] > internalEndWallClock[0])
    		{
    			//make difference negative and swap all values
    			swapAll = true;
    		}
    		else if (internalStartWallClock[0] == internalEndWallClock[0])
    		{
    			if (internalStartWallClock[1] > internalEndWallClock[1])
    			{
    				//make difference negative and swap all values
    				swapAll = true;
    			}
    			else if (internalStartWallClock[1] == internalEndWallClock[1])
    			{
    				if (internalStartWallClock[2] > internalEndWallClock[2])
    				{
    					//make difference negative and swap all values
    					swapAll = true;
    				}
    				else if (internalStartWallClock[2] == internalEndWallClock[2])
    				{
    					if (internalStartWallClock[3] > internalEndWallClock[3])
    					{
    						//make difference negative and swap all values
    						swapAll = true;
    					}
    					else if (internalStartWallClock[3] == internalEndWallClock[3])
    					{
    						return " 00:00:00.000";
    					}
    					//else;//do nothing
    				}
    				//else;//do nothing
    			}
    			//else;//do nothing
    		}
    		//else;//do nothing
    		
    		if (swapAll)
    		{
    			for (int i = 0; i < 4; i++)
    			{
    				int temp = -1;
    				if (i == 0)
    				{
    					temp = internalStartWallClock[3];
    					internalStartWallClock[3] = internalEndWallClock[3];
    					internalEndWallClock[3] = temp;
    				}
    				else if (i == 1)
    				{
    					temp = internalStartWallClock[2];
    					internalStartWallClock[2] = internalEndWallClock[2];
    					internalEndWallClock[2] = temp;
    				}
    				else if (i == 2)
    				{
    					temp = internalStartWallClock[1];
    					internalStartWallClock[1] = internalEndWallClock[1];
    					internalEndWallClock[1] = temp;
    				}
    				else
    				{
    					temp = internalStartWallClock[0];
    					internalStartWallClock[0] = internalEndWallClock[0];
    					internalEndWallClock[0] = temp;
    				}
    			}//end of i for loop for the swap
    		}
    		//else;//do nothing
    	}
    	else
    	{
    		//not formatted print statements the return statement is properly formatted
    		//System.out.print(MergeSortEndWallClock[0]+":"+MergeSortEndWallClock[1]+":");
    		//System.out.println(MergeSortEndWallClock[2]+"."+MergeSortEndWallClock[3]);
    		//System.out.print(MergeSortStartWallClock[0]+":"+MergeSortStartWallClock[1]+":");
    		//System.out.println(MergeSortStartWallClock[2]+"."+MergeSortStartWallClock[3]);
    		
    		if (MergeSortStartWallClock[0] > MergeSortEndWallClock[0])
    		{
    			//make difference negative and swap all values
    			swapAll = true;
    		}
    		else if (MergeSortStartWallClock[0] == MergeSortEndWallClock[0])
    		{
    			if (MergeSortStartWallClock[1] > MergeSortEndWallClock[1])
    			{
    				//make difference negative and swap all values
    				swapAll = true;
    			}
    			else if (MergeSortStartWallClock[1] == MergeSortEndWallClock[1])
    			{
    				if (MergeSortStartWallClock[2] > MergeSortEndWallClock[2])
    				{
    					//make difference negative and swap all values
    					swapAll = true;
    				}
    				else if (MergeSortStartWallClock[2] == MergeSortEndWallClock[2])
    				{
    					if (MergeSortStartWallClock[3] > MergeSortEndWallClock[3])
    					{
    						//make difference negative and swap all values
    						swapAll = true;
    					}
    					else if (MergeSortStartWallClock[3] == MergeSortEndWallClock[3])
    					{
    						return " 00:00:00.000";
    					}
    					//else;//do nothing
    				}
    				//else;//do nothing
    			}
    			//else;//do nothing
    		}
    		//else;//do nothing
    		
    		if (swapAll)
    		{
    			for (int i = 0; i < 4; i++)
    			{
    				int temp = -1;
    				if (i == 0)
    				{
    					temp = MergeSortStartWallClock[3];
    					MergeSortStartWallClock[3] = MergeSortEndWallClock[3];
    					MergeSortEndWallClock[3] = temp;
    				}
    				else if (i == 1)
    				{
    					temp = MergeSortStartWallClock[2];
    					MergeSortStartWallClock[2] = MergeSortEndWallClock[2];
    					MergeSortEndWallClock[2] = temp;
    				}
    				else if (i == 2)
    				{
    					temp = MergeSortStartWallClock[1];
    					MergeSortStartWallClock[1] = MergeSortEndWallClock[1];
    					MergeSortEndWallClock[1] = temp;
    				}
    				else
    				{
    					temp = MergeSortStartWallClock[0];
    					MergeSortStartWallClock[0] = MergeSortEndWallClock[0];
    					MergeSortEndWallClock[0] = temp;
    				}
    			}//end of i for loop for the swap
    		}
    		//else;//do nothing
    	}
    	
    	//ms-0;s-1;m-2;h-3
    	int borrowingReturnIndex = -1;
    	int nextBIndex = -1;
    	int difference = 0;
    	int conversionFactor = 0;
    	boolean borrowing = false;
    	boolean add = true;
    	for (int i = 0; i < 4; i += 0)
    	{
    		//System.out.println("i = " + i);
    		
    		if (i < 0 || i > 3) break;//we don't do days,months,or years
    		//else;//do nothing
    		
    		//if (i == 0) System.out.println("Milliseconds");
    		//else if (i == 1) System.out.println("Seconds");
    		//else if (i == 2) System.out.println("Minutes");
    		//else System.out.println("Hours");
    		
    		//first get the numbers being subtracted
    		int b = 0;
    		int a = 0;
    		
    		if (isInternal)
    		{
    			if (i == 0)
    			{
    				internalEndWallClock[3] += conversionFactor;
    				b = internalEndWallClock[3];
    				a = internalStartWallClock[3];
    			}
    			else if (i == 1)
    			{
    				internalEndWallClock[2] += conversionFactor;
    				b = internalEndWallClock[2];
    				a = internalStartWallClock[2];
    			}
    			else if (i == 2)
    			{
    				internalEndWallClock[1] += conversionFactor;
    				b = internalEndWallClock[1];
    				a = internalStartWallClock[1];
    			}
    			else if (i == 3)
    			{
    				internalEndWallClock[0] += conversionFactor;
    				b = internalEndWallClock[0];
    				a = internalStartWallClock[0];
    			}
    			else break;
    		}
    		else
    		{
    			if (i == 0)
    			{
    				MergeSortEndWallClock[3] += conversionFactor;
    				b = MergeSortEndWallClock[3];
    				a = MergeSortStartWallClock[3];
    			}
    			else if (i == 1)
    			{
    				MergeSortEndWallClock[2] += conversionFactor;
    				b = MergeSortEndWallClock[2];
    				a = MergeSortStartWallClock[2];
    			}
    			else if (i == 2)
    			{
    				MergeSortEndWallClock[1] += conversionFactor;
    				b = MergeSortEndWallClock[1];
    				a = MergeSortStartWallClock[1];
    			}
    			else if (i == 3)
    			{
    				MergeSortEndWallClock[0] += conversionFactor;
    				b = MergeSortEndWallClock[0];
    				a = MergeSortStartWallClock[0];
    			}
    			else break;
    		}
    		//now we have the numbers to subtract
    		//System.out.println("b = " + b);
    		//System.out.println("a = " + a);
    	    //a is only taken into account when borrowing is false in the difference
    		
    		//reset the conversion factor after adding
    		conversionFactor = 0;
    		
    		//make sure the code will advance after it is done borrowing
    		//System.out.println("borrowing = " + borrowing);
    		//System.out.println("borrowingReturnIndex = " + borrowingReturnIndex);
    		if (borrowing == true && borrowingReturnIndex > -1 && i == borrowingReturnIndex)
    		{
    			borrowingReturnIndex = -1;
    			borrowing = false;
    			add = true;
    			//System.out.println("\nDone borrowing!");
    			//System.out.println("NEW borrowing = " + borrowing);
    			//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
    			//System.out.println("NEW add = " + add);
    			//System.out.println();
    		}
    		//else;//do nothing
    		
    		//this allows us to check if we actually need to borrow when doing the subtraction
    		//because the difference computed below will be negative if we need to.
    		//we only compute the difference when we are not finding a value to borrow from.
    		if (borrowing == false)
    		{
    			difference = b - a;
    			//System.out.println("difference = " + difference);
    		}
    		//else;//do nothing
    		
    		//assume all examples of (a > b) is reversed, but the sign is fixed before the alogorithmn starts
    		//example of can't borrow from any:
    		//  00:00:0.3 b  (a > b)
    	    // -00:00:0.4 a
    	    //
    	    //  00:00:0.4
    	    // -00:00:0.3
    	    //=-00:00:0.1
    	    
    	    //example borrowing from seconds
    	    // hr:mn:s.mil
			// 12:19:5.3
	    	//-11:20:4.4
	    	//
	    	// 12:19:4.13
	    	//-11:20:4.04
	    	//
	    	// 11:79:4.13
	    	//-11:20:4.04
	    	//=00:59:0.09 (this shows carry place insterted)
	    	//=00:59:0.9 (this is the actual answer)
    	    
    	    //example borrowing from minutes and hours
    	    // hr:mn:se.mil
			// 12:19:00.300
	    	//-11:20:04.400
	    	//
	    	// 12:19:00.1300
	    	//-11:20:04.0400
	    	//=__:__:__.0900 (answer so far)
	    	//
	    	// 12:18:60.1300
	    	//-11:20:04.0400
	    	//=__:__:56.0900 
	    	//
	    	//         c
	    	// 11:78:60.1300
	    	//-11:20:04.0400
	    	//=00:58:56.0900 (with carry places)
	    	//=
	    	//=00:58:56.900 (final answer)
    	    
    		//if (difference < 0)
    		//we need to borrow from the next one over if we can't
    		//if we can't borrow from any make final answer negative...
    		//else if difference >= 0 we don't need to borrow
    		
    		if (borrowing == false)
    		{
    			if (difference < 0)
    			{
    				//we need to check if we can borrow from next
	    			//we need to get the next value
	    			//to do this, set the next b value to b after we advance the difference
	    			//then (check to see if we can borrow from this (b < 0) can't else can)
	    			//if we can, then we need to subtract 1 from the value and add the conversion
	    			//factor on to the index closer to the one where we needed to borrow from
	    			
	    			//conversion factors
	    			//1000 millseconds in 1 second
	    			//60 seconds are in 1 minute
	    			//60 minutes are in 1 hour
	    			
	    			add = true;//default
	    			borrowing = true;
	    			borrowingReturnIndex = i;//index we want to work back to
	    			
	    			//System.out.println("\nWe need to borrow!");
	    			//System.out.println("NEW borrowing = " + borrowing);
	    			//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
	    			//System.out.println("add = " + add);
	    			
	    			i++;//we added here
	    			continue;
    			}
    			else
    			{
    				if (borrowingReturnIndex > -1) borrowingReturnIndex = -1;
    				//else;//do nothing no borrowing is needed
    				//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
    			}
    		}
    		else
    		{
    			//System.out.println("b = " + b);
    			//now that we have are next b is it greater than 0
    			if (b > 0)
    			{
    				//System.out.println("\nWe can borrow from this!");
    				//we can borrow from it, so do so
    				if (i == 1)
    				{
    					if (isInternal)
    					{
    						internalEndWallClock[2] -= 1;
    						//System.out.println("NEW internalEndSecond = " + internalEndWallClock[2]);
    					}
    					else
    					{
    						MergeSortEndWallClock[2] -= 1;
    						//System.out.println("NEW MergeSortEndSecond = " + MergeSortEndWallClock[2]);
    					}
    					conversionFactor = 1000;
    				}
    				else if (i == 2)
    				{
    					if (isInternal)
    					{
    						internalEndWallClock[1] -= 1;
    						//System.out.println("NEW internalEndMinute = " + internalEndWallClock[1]);
    					}
    					else
    					{
    						MergeSortEndWallClock[1] -= 1;
    						//System.out.println("NEW MergeSortEndMinute = " + MergeSortEndWallClock[1]);
    					}
    					conversionFactor = 60;
    				}
    				else if (i == 3)
    				{
    					if (isInternal)
    					{
    						internalEndWallClock[0] -= 1;
    						//System.out.println("NEW internalEndHour = " + internalEndWallClock[0]);
    					}
    					else
    					{
    						MergeSortEndWallClock[0] -= 1;
    						//System.out.println("NEW MergeSortEndHour = " + MergeSortEndWallClock[1]);
    					}
    					conversionFactor = 60;
    				}
    				add = false;
    			}
    			else add = true;
    			//else;//do nothing we cannot borrow from it
    			//System.out.println("conversionFactor = " + conversionFactor);
    			//System.out.println("borrowingReturnIndex = " + borrowingReturnIndex);
    		}
    		
    		//store the magnitude of the difference here in the variables
    		//provided that we are done and not borrowing still
    		if (borrowing == false)
    		{
    			if (borrowingReturnIndex > -1)
    			{
    				//we need to do something here so we work backwards
    				if (i > borrowingReturnIndex) add = false;//works backwards
    				else add = true;//works forwards; controls loop (in/de)crementation
    			}
    			else
    			{
	    			//we are also free to advance the for loop once these values are stored
	    			if (i == 0) millidifference = difference;
	    			else if (i == 1) seconddifference = difference;
	    			else if (i == 2) minutedifference = difference;
	    			else hourdifference = difference;
	    			add = true;
	    			
	    			//System.out.println();
	    			//System.out.println("hourdifference = " + hourdifference);
	    			//System.out.println("minutedifference = " + minutedifference);
	    			//System.out.println("seconddifference = " + seconddifference);
	    			//System.out.println("milliifference = " + millidifference);
	    			//System.out.println("add = " + add);
	    			//System.out.println();
    			}
    		}
    		else
    		{
    			//made it to the end and can't borrow
    			if (i == 3)
    			{
    				//we need to work in reverse and let the program know that the result is negative
    				add = false;
    			}
    			//else;//not sure what to do here
    			
    			//System.out.println("add = " + add);
    		}
    		
    		//end of for loop code
    		if (add) i++;
    		else i--;
    	}//end of i for loop
    	
    	//generate the return the string here
    	if (swapAll) str += "-";
    	else str += " ";
    	
    	if (hourdifference < 10) str += "0" + hourdifference;
    	else str += hourdifference;
    	str += ":";
    	if (minutedifference < 10) str += "0" + minutedifference;
    	else str += minutedifference;
    	str += ":";
    	if (seconddifference < 10) str += "0" + seconddifference;
    	else str += seconddifference;
    	str += ".";
    	if (millidifference < 10) str += "00";
    	else if (millidifference < 100) str += "0";
    	//else;//do nothing
    	str += millidifference;
    	//System.out.println("str = " + str);
    	
    	return str;
    }
    
    public static long getSortCPUTime(boolean isInternal)
    {
    	//this will return the internal time difference in miliseconds
    	//for either sort
    	//the isInternal sort identifies the sorting type
    	if (isInternal) return (long)(internalEndTime - internalStartTime);
    	else return (long)(MergeSortEndTime - MergeSortStartTime);
    }
    
    //generate the arrays here
    private static Random random = new Random();//needed for generating random decimal numbers and integers
    public static int[] generateIntArray()
    {
    	int[] marr = new int[SIZE];
    	for (int i = 0; i < SIZE; i++)
    	{
    		marr[i] = random.nextInt(BIG) + 1;
    	}
    	return marr;
    }
    public static double[] generateDoubleArray()
    {
    	double[] marr = new double[SIZE];
    	for (int i = 0; i < SIZE; i++)
    	{
    		marr[i] = BIG * random.nextDouble() + 1;
    	}
    	return marr;
    }
    public static float[] generateFloatArray()
    {
    	float[] marr = new float[SIZE];
    	for (int i = 0; i < SIZE; i++)
    	{
    		marr[i] = BIG * random.nextFloat() + 1;
    	}
    	return marr;
    }
    public static String[] generateStringArray()
    {
    	final String s = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    	//asscii for 0 is 48; A is 65; a is 97
    	//for (int i = 0; i < s.length(); i++)
    	//{
    	//	System.out.println(s.charAt(i));
    	//	int num = (int)(s.charAt(i));
    	//	System.out.println("num = " + num);
    	//}
    	
    	String[] sarr = new String[SIZE];
    	for (int n = 0; n < SIZE; n++)
    	{
	    	String str = "";
	    	for (int c = 0; c < stringSizeGenerated; c++)
	    	{
	    		//number of characters
	    		//randomly pick an index
	    		str += "" + s.charAt(random.nextInt(s.length()));
	    	}
	    	sarr[n] = str;
    	}
    	return sarr;
    }
    
    //print the arrays
    public static void printIntArray(int[] arr)
    {
    	for (int i = 0; i < arr.length; i++)
    	{
    		System.out.println(arr[i]);
    	}
    	System.out.println();
    }
    public static void printFloatArray(float[] arr)
    {
    	for (int i = 0; i < arr.length; i++)
    	{
    		System.out.println(arr[i]);
    	}
    	System.out.println();
    }
    public static void printDoubleArray(double[] arr)
    {
    	for (int i = 0; i < arr.length; i++)
    	{
    		System.out.println(arr[i]);
    	}
    	System.out.println();
    }
    public static void printStringArray(String[] arr)
    {
    	for (int i = 0; i < arr.length; i++)
    	{
    		System.out.println(arr[i]);
    	}
    	System.out.println();
    }
    
    public static void main(String[] args)
    {
    	//initialize the clocks as a fail safe
    	for (int i = 0; i < 4; i++)
    	{
    		internalStartWallClock[i] = 0;
    		internalEndWallClock[i] = 0;
    		MergeSortStartWallClock[i] = 0;
    		MergeSortEndWallClock[i] = 0;
    	}
    	
    	//begin the program calling here
    	//resetSizeAndBig = true;
    	resetSizeAndBig = false;
    	
    	System.out.println("Testing with ints:");
    	getUserInput();
    	int[] arri = generateIntArray();
    	int[] oarri = new int[arri.length];
    	for (int i = 0; i < arri.length; i++) oarri[i] = arri[i];
    	System.out.println("Copy of Original Array:");
    	printIntArray(oarri);
    	
    	//call internal sort here and time it
    	startStopSortClock(true, true, true);//start the internal CPU clock here
    	startStopSortClock(true, true, false);//start the internal Wall clock here
    	
    	//do the sort here
    	Arrays.sort(oarri);
    	
    	startStopSortClock(false, true, true);//stop the internal CPU clock here
    	startStopSortClock(false, true, false);//stop the internal Wall clock here
    	
    	System.out.println("After Internal Sort Was Called:");
    	printIntArray(oarri);
    	
    	System.out.println("Begin MergeSort Test With Original Array:");
    	printIntArray(arri);
    	
    	Mergesort mi = new Mergesort();
    	startStopSortClock(true, false, true);//start the internal CPU clock here
    	startStopSortClock(true, false, false);//start the internal Wall clock here
    	
    	//call mergesort here
    	arri = mi.MergeSort(arri);
    	
    	startStopSortClock(false, false, true);//start the internal CPU clock here
    	startStopSortClock(false, false, false);//start the internal Wall clock here
    	
    	System.out.println("\nAfter Merge Sort Was Called and Results:");
    	printIntArray(arri);
    	
    	///*
    	//check to see if the MergeSort code worked or not by running all 3 tests below:
    	//checks to see if the list is sorted or not if it is not sorted, do not run the other tests
    	//because we know that they failed. We only run the next test if the current test past....
    	//NOTE: If you want to check the other calls, call them both like the int[] call and
    	//use the Arrays.sort(int[] arr) for it, then copy the results into an array so you can
    	//perform the frequency checks. If you are using strings, I have also provided comments
    	//next to the lines and how to change them should you wish to check them with my testing code.
    	//FINAL NOTE: I tested this sort so many times, to account for random events of the list actually
    	//being sorted to make sure that this works. If you think it doesn't uncomment these checks by simply
    	//putting a comment in front of the multiline comment because A comment commenting a comment is NOT a
    	//comment at all. Try saying: 
    	//"A comment Commenting a comment is not a comment at all" 5 times fast.
    	System.out.print("Is Sorted: ");
    	boolean arrisorted = mi.isSorted(arri);
    	if (arrisorted) System.out.println("Passed!");
    	else System.out.println("Failed!");
    	
    	if (arrisorted)
    	{
	    	//we need to check if every number inside of the original array is inside of the
	    	//returned array
	    	boolean sameNumbers = true;
	    	for (int i = 0; i < oarri.length; i++)
	    	{
	    		boolean found = false;
	    		for (int j = 0; j < arri.length; j++)
	    		{
	    			//if comparing Strings first cast both to Strings,
	    			//then use the "String1.equals(String2)" method
	    			if (oarri[i] == arri[j]) found = true;
	    		}
	    		
	    		if (!found)
	    		{
	    			sameNumbers = false;
	    			break;
	    		}
	    	}
	    	System.out.print("Both arrays have the same numbers: ");
	    	if (sameNumbers) System.out.println("Passed!");
	    	else System.out.println("Failed!");
	    	
	    	if (sameNumbers)
	    	{
	    		System.out.print("Frequency check: ");
	    		boolean sameFreq = true;
	    		//do a frequency check
	    		//first get the frequency counts for all of the numbers including repeats
	    		//for the original array
	    		ArrayList<Integer> ofreq = new ArrayList<Integer>();
	    		for (int i = 0; i < oarri.length; i++)
	    		{
	    			int count = 1;
	    			for (int a = 0; a < oarri.length; a++)
	    			{
	    				if (a == i) continue;
	    				
	    				if (oarri[a] == oarri[i]) count++;
	    			}
	    			ofreq.add(count);
	    		}
	    		//get the frequency counts for the returned array
	    		ArrayList<Integer> afreq = new ArrayList<Integer>();
	    		for (int i = 0; i < arri.length; i++)
	    		{
	    			int count = 1;
	    			for (int a = 0; a < arri.length; a++)
	    			{
	    				if (a == i) continue;
	    				
	    				if (arri[a] == arri[i]) count++;
	    			}
	    			afreq.add(count);
	    		}
	    		//go through the original array comparing its frequency counts with that of the returned
	    		//array for the same number (if the frequency counts are not the same, the test failed)
	    		for (int i = 0; i < oarri.length; i++)
	    		{
	    			//current number is the oarri[i], its frequency is ofreq.get(i)
	    			boolean found = false;
	    			for (int a = 0; a < arri.length; a++)
	    			{
	    				//if comparing Strings first cast both to Strings,
	    				//then use the "String1.equals(String2)" method
	    				if (oarri[i] == arri[a])
	    				{
	    					found = true;
	    					break;
	    				}
	    			}//end of a for loop
	    			if (found)
	    			{
	    				if (ofreq.get(i) != afreq.get(i))
	    				{
	    					sameFreq = false;
	    					break;
	    				}
	    			}
	    			else
	    			{
	    				sameFreq = false;
	    				break;
	    			}
	    		}//end of i for loop
	    		if (sameFreq) System.out.println("Passed!");
	    		else System.out.println("Failed!");
	    		
	    		if (sameFreq)
	    		{
		    		//this assumes that this test is only ran after both sorts were called
		    		//compare to the list that was already sorted and see if the results are the same
		    		//this may be different for strings
		    		boolean sameLists = true;
		    		for (int i = 0; i < oarri.length; i++)
		    		{
		    			if (oarri[i] != arri[i])
	    				{
	    					sameLists = false;
	    					break;
	    				}
		    		}//end of i for loop
		    		
		    		System.out.print("Same as already sorted list: ");
		    		if (sameLists) System.out.println("Passed!");
		    		else System.out.println("Failed!");
	    		}
	    		//else;//do nothing done with all tests
	    	}
    	}
    	System.out.println();
    	//*/
    	
    	System.out.println("Wall clock:");
    	//print the time here for my Bubble sort
    	//print the time here for the Internal sort
    	//Create a new Calendar and then use the Calendar.MINUTE,HOUR,SECOND,etc.
    	//the computeTime() in miliseconds will be really helpful;
    	//we want to find the difference in hours, minutes, and seconds
    	//startStopSortClock(false, true, false);
    	
    	System.out.println("Merge sort:      " + getSortWallClockTime(false));
    	System.out.println("Internal sort:   " + getSortWallClockTime(true));
    	System.out.println("\nCPU clock:");
    	
    	//print the time here for my Bubble sort
    	//print the time here for the Internal sort
    	//http://memorynotfound.com/calculating-elapsed-time-java/
    	//long startTime = System.nanoTime();
    	//long endTime = System.nanoTime();
    	//long elapsedTime = end - start;
    	
    	System.out.println("Merge sort:       " + getSortCPUTime(false));
    	System.out.println("Internal sort:    " + getSortCPUTime(true));
    	System.out.println();
    	
    	//these are just the calls to the other types to see if they also worked...
    	System.out.println("Testing with doubles:");
    	getUserInput();
    	double[] arrd = generateDoubleArray();
    	printDoubleArray(arrd);
    	
    	System.out.println();
    	
    	System.out.println("Testing with floats:");
    	getUserInput();
    	float[] arrf = generateFloatArray();
    	printFloatArray(arrf);
    	
    	System.out.println();
    	
    	System.out.println("Testing the Strings:");
    	getUserInput(false, false);
    	String[] arrs = generateStringArray();
    	printStringArray(arrs);
    	System.out.println("isSorted: " + mi.isSorted(arrs));
    	arrs = (String[])(mi.MergeSort(arrs));
    	printStringArray(arrs);
    	System.out.println("isSorted: " + mi.isSorted(arrs));
    }
}