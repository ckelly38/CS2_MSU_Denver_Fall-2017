/**
 * @(#)HW4.java
 * This is a class that tracks CPU and the Clock time
 * for the BubbleSort and the Array Sort method
 * 
 * Dates:
 * 9-13-2017
 * 4:19 PM - 5:31 PM + 7:24 PM - 7:27 PM + 7:54 PM - 11:22 PM
 * Today, I read the file. I created a method to check for and remove
 * invalid special characters. I also was able to get the word count.
 * I had a lot of trouble trying to get the time from a calendar
 * Everytime I printed out the file, because it was a book, it
 * took 10 minutes! This also caused the application to be
 * unresponsive. I was not happy that this caused me a lot of
 * delays. Plus my clock function for the calendar is not working
 * correctly. I set up for, but haven't written the method that will
 * get the difference between the clock times yet.
 * 
 * PLAN FOR TOMORROW: I will do this, then I will write the sorting
 * methods or call them. Then I will get the clocks to start at the
 * right time and stop when they need to.
 * 
 * 9-14-2017
 * 4:24 PM - 6:35 PM + 7:45 PM - 8:26 PM + 9:19 PM - 10:17 PM
 * Today, I worked on writing the time subtraction algorithmn. I still
 * need to test it. As far as direct subtraction goes, it will work fine
 * (unless you go across days). This however has not been tested using
 * specific values and there could be a problem if it is not written right
 * if this is to be used over a long period of time. I also called the
 * internal Arrays.sort(array_name); and got that to work correctly.
 *
 * PLAN FOR TOMORROW: I need to implement and write the BubbleSort.
 * Then place the timing devices correctly. In that method in the exact
 * same order as the internal sort method call has done. Start and stop
 * the CPU clock then the Wall Clock in that order for both.
 * 
 * 9-15-2017
 * 10:39 AM - 11:11 AM + 1:19 PM - 1:55 PM + 1:57 PM - 4:50 PM + 5:36 PM - 8:59 PM + 10 PM - 12:10 AM
 * Today, I worked on writting BubbleSort. I fixed some logic errors with the
 * subtraction formula for the wall clock time as well as some set up errors with
 * the clocks. I spent the majority of the time working on the Sort until it crashed.
 * I decided at about 6:30 PM to rewrite the entire sorting algorithmn and to write
 * an isInAlphabeticOrder(String a, and String b) method where a and b are assumed to
 * be in order in the array. I ran this again and found out that my remove special characters
 * and spaces algorithmn messed up big time.
 *
 * PLAN FOR TOMORROW: I need to test the SUBTRACTION FORMULA WITH SPECIFIC NUMBERS WITHOUT ACTUALLY
 * TIMING IT, and I need to test BubbleSort on the HW4.txt by printing out everything. Once done
 * with the tests, upload it.
 *
 * 9-16-2017
 * 11:10 AM - 11:31 AM + 12:34 PM - 1:51 PM
 * I found a bug inside of my subtraction/borrowing algorithmn. I am going to work it out. Then I will
 * retest, and submit it if the bugs are worked out.
 * ---------------------------------------------------------------------------------------------------
 * End of HW 4 Time Log
 * 
 * Begin HW 5 Time Log
 * 
 * 9-25-2017
 * 4 PM - 4:53 PM + 4:58 PM - 5:31 PM
 * I first converted all of the words to lower case, then I sorted everything. I created a method
 * that creates the out put file.
 * 
 * @author 
 * @version 1.00 2017/9/13
 */

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.util.GregorianCalendar;//java 7 not java 8 on my machine
import java.util.Calendar;//java 7 not java 8 on my machine
//import java.time;//java 8 (not worked with this otherwise only the
//starting and stopping of the clocks would change) and the import statements
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
public class HW5
{

    private static ArrayList<String> words = new ArrayList<String>();//the original
    private static ArrayList<Integer> wcounts = new ArrayList<Integer>();//the number of times this word was found
    private static String[] internalWords = null;//the one to be sorted
    private static String[] wordsarrayforbubble = null;//this will be sorted using a
    //BubbleSort written by me below
    private static long internalStartTime = 0;
    private static long internalEndTime = 0;
    private static long BubbleSortEndTime = 0;
    private static long BubbleSortStartTime = 0;
    private static int internalStartHour = 0;
    private static int internalStartMinute = 0;
    private static int internalStartSecond = 0;
    private static int internalStartMillisecond = 0;
    private static int internalEndHour = 0;
    private static int internalEndMinute = 0;
    private static int internalEndSecond = 0;
    private static int internalEndMillisecond = 0;
    private static int BubbleSortStartHour = 0;
    private static int BubbleSortStartMinute = 0;
    private static int BubbleSortStartSecond = 0;
    private static int BubbleSortStartMillisecond = 0;
    private static int BubbleSortEndHour = 0;
    private static int BubbleSortEndMinute = 0;
    private static int BubbleSortEndSecond = 0;
    private static int BubbleSortEndMillisecond = 0;
    
    private static final char specialDelimiter = '+';
    private static boolean useDashAsSpace = false;
    //if this is false, this will treat it like a special character that needs to be
    //removed; if this is true, this will still remove the dashes but identify two words
    //on either side of it as such.
    
    public HW5()
    {
    	
    }
    
    //this gets the name of the file from the user
    //if there is a problem, this method prints an
    //error message and uses recursion until the user
    //enters a valid file name which gets returned
    public static String getFileNameFromUser()
    {
    	System.out.print("Filename: ");
    	Scanner scanner = new Scanner(System.in);
    	String fileName = scanner.nextLine();
    	
    	//check if it is valid if it is not, use recursion
    	try
    	{
    		Scanner fileScan = new Scanner(new File(fileName));
    		fileScan.close();
    	}
    	catch(Exception e)
    	{
    		//e.printStackTrace();
    		System.out.println("ERROR: Cannot find or open the file: " + fileName);
    		return getFileNameFromUser();
    	}
    	return fileName;
    }
    
    //clock methods are below
    //this is where the clocks start and stop the isInternalSort identifies the sort, and the isCPU identifies the clock
    //there are two clocks and two sorts, and you must start and stop them (8 calls to this method)
    public static void startStopSortClock(boolean start, boolean isInternalSort, boolean isCPU)
    {
    	if (isCPU)
		{
			//the long miliseconds
			if (isInternalSort)
			{
				if (start) internalStartTime = System.nanoTime();
				else internalEndTime = System.nanoTime();
			}
			else
			{
				if (start) BubbleSortStartTime = System.nanoTime();
				else BubbleSortEndTime = System.nanoTime();
			}
		}
		else
		{
			final GregorianCalendar gc = new GregorianCalendar();
			//the wall clock then
			if (isInternalSort)
			{
				if (start)
				{
					internalStartHour = gc.get(Calendar.HOUR);
    				internalStartMinute = gc.get(Calendar.MINUTE);
				    internalStartSecond = gc.get(Calendar.SECOND);
				    internalStartMillisecond = gc.get(Calendar.MILLISECOND);
				}
				else
				{
					internalEndHour = gc.get(Calendar.HOUR);
    				internalEndMinute = gc.get(Calendar.MINUTE);
				    internalEndSecond = gc.get(Calendar.SECOND);
				    internalEndMillisecond = gc.get(Calendar.MILLISECOND);
				}
			}
			else
			{
				if (start)
				{
					BubbleSortStartHour = gc.get(Calendar.HOUR);
    				BubbleSortStartMinute = gc.get(Calendar.MINUTE);
				    BubbleSortStartSecond = gc.get(Calendar.SECOND);
				    BubbleSortStartMillisecond = gc.get(Calendar.MILLISECOND);
				}
				else
				{
					BubbleSortEndHour = gc.get(Calendar.HOUR);
    				BubbleSortEndMinute = gc.get(Calendar.MINUTE);
				    BubbleSortEndSecond = gc.get(Calendar.SECOND);
				    BubbleSortEndMillisecond = gc.get(Calendar.MILLISECOND);
				}
			}
		}
    }
    
    //computes the difference of two times on the same day (it will be wrong if you go over midnight)
    //this methods modifies the stored values for the times (for ease of subtraction)
    //if the start is greater than the end, it will return a negative value (it swaps them and inverts the magnitude)
    //then it returns the result in a String
    //isInternal referrs to the type of sort is it the internal sort (true) or is it the BubbleSort (false)
    public static String getSortWallClockTime(boolean isInternal)
    {
    	String str = "";
    	//returns a string of hours:minutes:seconds.miliseconds for the difference
    	//we will use the GregorianCalendar variables to get the calendar and then be able
    	//to do that
    	//12:19:5.6
    	//-11:20:4.4
    	//=2:23:1.2
    	//start with milliseconds then go to seconds
    	//if (time_unit)B < (time_unit)A: minB+60 and hrB-1 then subtract
    	//else just directly subtract
    	
    	int millidifference = 0;
    	int seconddifference = 0;
    	int minutedifference = 0;
    	int hourdifference = 0;
    	//if (isInternal) millidifference = internalEndMillisecond - internalStartMillisecond;
    	//else millidifference = BubbleSortEndMillisecond - BubbleSortStartMillisecond;
    	
    	//cannot run this across days (will return negative answer)
    	
    	//if current difference is negative, we need to borrow
    	//we need to first check the next number over to see if it is > 0, if it is borrow from
    	//it by subtracting 1 from it and adding the conversion factor to the difference (if
    	//immediately next to it) else we could not borrow from the immediate try the one over from
    	//that by checking if it is > 0, if we can borrow from it, then we subtract one from it (add
    	//the conversion factor to the next one close to it, then check to see if we can borrow from the
    	//next one over, if we can subtract one from that new number and add the conversion factor
    	//to the difference)
    	
    	//  00:00:0.3
    	// -00:00:0.4
    	//=-00:00:0.1
    	
    	//System.out.println("isInternal = " + isInternal);
    	
    	//need to check if startTime is greater than the endTime (needs to be swapped before
    	//subtraction but difference is negative)
    	boolean swapAll = false;
    	//System.out.println("hr:mn:sc.mis (hours:minutes:seconds.milliseconds)");
    	if (isInternal)
    	{
    		//not formatted print statements the return statement is properly formatted
    		//System.out.println(internalEndHour+":"+internalEndMinute+":"+internalEndSecond+"."+internalEndMillisecond);
    		//System.out.println(internalStartHour+":"+internalStartMinute+":"+internalStartSecond+"."+internalStartMillisecond);
    		
    		if (internalStartHour > internalEndHour)
    		{
    			//make difference negative and swap all values
    			swapAll = true;
    		}
    		else if (internalStartHour == internalEndHour)
    		{
    			if (internalStartMinute > internalEndMinute)
    			{
    				//make difference negative and swap all values
    				swapAll = true;
    			}
    			else if (internalStartMinute == internalEndMinute)
    			{
    				if (internalStartSecond > internalEndSecond)
    				{
    					//make difference negative and swap all values
    					swapAll = true;
    				}
    				else if (internalStartSecond == internalEndSecond)
    				{
    					if (internalStartMillisecond > internalEndMillisecond)
    					{
    						//make difference negative and swap all values
    						swapAll = true;
    					}
    					else if (internalStartMillisecond == internalEndMillisecond)
    					{
    						return " 00:00:00.000";
    					}
    					//else;//do nothing
    				}
    				//else;//do nothing
    			}
    			//else;//do nothing
    		}
    		//else;//do nothing
    		
    		if (swapAll)
    		{
    			for (int i = 0; i < 4; i++)
    			{
    				int temp = -1;
    				if (i == 0)
    				{
    					temp = internalStartMillisecond;
    					internalStartMillisecond = internalEndMillisecond;
    					internalEndMillisecond = temp;
    				}
    				else if (i == 1)
    				{
    					temp = internalStartSecond;
    					internalStartSecond = internalEndSecond;
    					internalEndSecond = temp;
    				}
    				else if (i == 2)
    				{
    					temp = internalStartMinute;
    					internalStartMinute = internalEndMinute;
    					internalEndMinute = temp;
    				}
    				else
    				{
    					temp = internalStartHour;
    					internalStartHour = internalEndHour;
    					internalEndHour = temp;
    				}
    			}//end of i for loop for the swap
    		}
    		//else;//do nothing
    	}
    	else
    	{
    		//not formatted print statements the return statement is properly formatted
    		//System.out.println(BubbleSortEndHour+":"+BubbleSortEndMinute+":"+BubbleSortEndSecond+"."+BubbleSortEndMillisecond);
    		//System.out.println(BubbleSortStartHour+":"+BubbleSortStartMinute+":"+BubbleSortStartSecond+"."+BubbleSortStartMillisecond);
    		
    		if (BubbleSortStartHour > BubbleSortEndHour)
    		{
    			//make difference negative and swap all values
    			swapAll = true;
    		}
    		else if (BubbleSortStartHour == BubbleSortEndHour)
    		{
    			if (BubbleSortStartMinute > BubbleSortEndMinute)
    			{
    				//make difference negative and swap all values
    				swapAll = true;
    			}
    			else if (BubbleSortStartMinute == BubbleSortEndMinute)
    			{
    				if (BubbleSortStartSecond > BubbleSortEndSecond)
    				{
    					//make difference negative and swap all values
    					swapAll = true;
    				}
    				else if (BubbleSortStartSecond == BubbleSortEndSecond)
    				{
    					if (BubbleSortStartMillisecond > BubbleSortEndMillisecond)
    					{
    						//make difference negative and swap all values
    						swapAll = true;
    					}
    					else if (BubbleSortStartMillisecond == BubbleSortEndMillisecond)
    					{
    						return " 00:00:00.000";
    					}
    					//else;//do nothing
    				}
    				//else;//do nothing
    			}
    			//else;//do nothing
    		}
    		//else;//do nothing
    		
    		if (swapAll)
    		{
    			for (int i = 0; i < 4; i++)
    			{
    				int temp = -1;
    				if (i == 0)
    				{
    					temp = BubbleSortStartMillisecond;
    					BubbleSortStartMillisecond = BubbleSortEndMillisecond;
    					BubbleSortEndMillisecond = temp;
    				}
    				else if (i == 1)
    				{
    					temp = BubbleSortStartSecond;
    					BubbleSortStartSecond = BubbleSortEndSecond;
    					BubbleSortEndSecond = temp;
    				}
    				else if (i == 2)
    				{
    					temp = BubbleSortStartMinute;
    					BubbleSortStartMinute = BubbleSortEndMinute;
    					BubbleSortEndMinute = temp;
    				}
    				else
    				{
    					temp = BubbleSortStartHour;
    					BubbleSortStartHour = BubbleSortEndHour;
    					BubbleSortEndHour = temp;
    				}
    			}//end of i for loop for the swap
    		}
    		//else;//do nothing
    	}
    	
    	//ms-0;s-1;m-2;h-3
    	int borrowingReturnIndex = -1;
    	int nextBIndex = -1;
    	int difference = 0;
    	int conversionFactor = 0;
    	boolean borrowing = false;
    	boolean add = true;
    	for (int i = 0; i < 4; i += 0)
    	{
    		//System.out.println("i = " + i);
    		
    		if (i < 0 || i > 3) break;//we don't do days,months,or years
    		//else;//do nothing
    		
    		//if (i == 0) System.out.println("Milliseconds");
    		//else if (i == 1) System.out.println("Seconds");
    		//else if (i == 2) System.out.println("Minutes");
    		//else System.out.println("Hours");
    		
    		//first get the numbers being subtracted
    		int b = 0;
    		int a = 0;
    		
    		if (isInternal)
    		{
    			if (i == 0)
    			{
    				internalEndMillisecond += conversionFactor;
    				b = internalEndMillisecond;
    				a = internalStartMillisecond;
    			}
    			else if (i == 1)
    			{
    				internalEndSecond += conversionFactor;
    				b = internalEndSecond;
    				a = internalStartSecond;
    			}
    			else if (i == 2)
    			{
    				internalEndMinute += conversionFactor;
    				b = internalEndMinute;
    				a = internalStartMinute;
    			}
    			else if (i == 3)
    			{
    				internalEndHour += conversionFactor;
    				b = internalEndHour;
    				a = internalStartHour;
    			}
    			else break;
    		}
    		else
    		{
    			if (i == 0)
    			{
    				BubbleSortEndMillisecond += conversionFactor;
    				b = BubbleSortEndMillisecond;
    				a = BubbleSortStartMillisecond;
    			}
    			else if (i == 1)
    			{
    				BubbleSortEndSecond += conversionFactor;
    				b = BubbleSortEndSecond;
    				a = BubbleSortStartSecond;
    			}
    			else if (i == 2)
    			{
    				BubbleSortEndMinute += conversionFactor;
    				b = BubbleSortEndMinute;
    				a = BubbleSortStartMinute;
    			}
    			else if (i == 3)
    			{
    				BubbleSortEndHour += conversionFactor;
    				b = BubbleSortEndHour;
    				a = BubbleSortStartHour;
    			}
    			else break;
    		}
    		//now we have the numbers to subtract
    		//System.out.println("b = " + b);
    		//System.out.println("a = " + a);
    	    //a is only taken into account when borrowing is false in the difference
    		
    		//reset the conversion factor after adding
    		conversionFactor = 0;
    		
    		//make sure the code will advance after it is done borrowing
    		//System.out.println("borrowing = " + borrowing);
    		//System.out.println("borrowingReturnIndex = " + borrowingReturnIndex);
    		if (borrowing == true && borrowingReturnIndex > -1 && i == borrowingReturnIndex)
    		{
    			borrowingReturnIndex = -1;
    			borrowing = false;
    			add = true;
    			//System.out.println("\nDone borrowing!");
    			//System.out.println("NEW borrowing = " + borrowing);
    			//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
    			//System.out.println("NEW add = " + add);
    			//System.out.println();
    		}
    		//else;//do nothing
    		
    		//this allows us to check if we actually need to borrow when doing the subtraction
    		//because the difference computed below will be negative if we need to.
    		//we only compute the difference when we are not finding a value to borrow from.
    		if (borrowing == false)
    		{
    			difference = b - a;
    			//System.out.println("difference = " + difference);
    		}
    		//else;//do nothing
    		
    		//assume all examples of (a > b) is reversed, but the sign is fixed before the alogorithmn starts
    		//example of can't borrow from any:
    		//  00:00:0.3 b  (a > b)
    	    // -00:00:0.4 a
    	    //
    	    //  00:00:0.4
    	    // -00:00:0.3
    	    //=-00:00:0.1
    	    
    	    //example borrowing from seconds
    	    // hr:mn:s.mil
			// 12:19:5.3
	    	//-11:20:4.4
	    	//
	    	// 12:19:4.13
	    	//-11:20:4.04
	    	//
	    	// 11:79:4.13
	    	//-11:20:4.04
	    	//=00:59:0.09 (this shows carry place insterted)
	    	//=00:59:0.9 (this is the actual answer)
    	    
    	    //example borrowing from minutes and hours
    	    // hr:mn:se.mil
			// 12:19:00.300
	    	//-11:20:04.400
	    	//
	    	// 12:19:00.1300
	    	//-11:20:04.0400
	    	//=__:__:__.0900 (answer so far)
	    	//
	    	// 12:18:60.1300
	    	//-11:20:04.0400
	    	//=__:__:56.0900 
	    	//
	    	//         c
	    	// 11:78:60.1300
	    	//-11:20:04.0400
	    	//=00:58:56.0900 (with carry places)
	    	//=
	    	//=00:58:56.900 (final answer)
    	    
    		//if (difference < 0)
    		//we need to borrow from the next one over if we can't
    		//if we can't borrow from any make final answer negative...
    		//else if difference >= 0 we don't need to borrow
    		
    		if (borrowing == false)
    		{
    			if (difference < 0)
    			{
    				//we need to check if we can borrow from next
	    			//we need to get the next value
	    			//to do this, set the next b value to b after we advance the difference
	    			//then (check to see if we can borrow from this (b < 0) can't else can)
	    			//if we can, then we need to subtract 1 from the value and add the conversion
	    			//factor on to the index closer to the one where we needed to borrow from
	    			
	    			//conversion factors
	    			//1000 millseconds in 1 second
	    			//60 seconds are in 1 minute
	    			//60 minutes are in 1 hour
	    			
	    			add = true;//default
	    			borrowing = true;
	    			borrowingReturnIndex = i;//index we want to work back to
	    			
	    			//System.out.println("\nWe need to borrow!");
	    			//System.out.println("NEW borrowing = " + borrowing);
	    			//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
	    			//System.out.println("add = " + add);
	    			
	    			i++;//we added here
	    			continue;
    			}
    			else
    			{
    				if (borrowingReturnIndex > -1) borrowingReturnIndex = -1;
    				//else;//do nothing no borrowing is needed
    				//System.out.println("NEW borrowingReturnIndex = " + borrowingReturnIndex);
    			}
    		}
    		else
    		{
    			//System.out.println("b = " + b);
    			//now that we have are next b is it greater than 0
    			if (b > 0)
    			{
    				//System.out.println("\nWe can borrow from this!");
    				//we can borrow from it, so do so
    				if (i == 1)
    				{
    					if (isInternal)
    					{
    						internalEndSecond--;
    						//System.out.println("NEW internalEndSecond = " + internalEndSecond);
    					}
    					else
    					{
    						BubbleSortEndSecond--;
    						//System.out.println("NEW BubbleSortEndSecond = " + BubbleSortEndSecond);
    					}
    					conversionFactor = 1000;
    				}
    				else if (i == 2)
    				{
    					if (isInternal)
    					{
    						internalEndMinute--;
    						//System.out.println("NEW internalEndMinute = " + internalEndMinute);
    					}
    					else
    					{
    						BubbleSortEndMinute--;
    						//System.out.println("NEW BubbleSortEndMinute = " + BubbleSortEndMinute);
    					}
    					conversionFactor = 60;
    				}
    				else if (i == 3)
    				{
    					if (isInternal)
    					{
    						internalEndHour--;
    						//System.out.println("NEW internalEndHour = " + internalEndHour);
    					}
    					else
    					{
    						BubbleSortEndHour--;
    						//System.out.println("NEW BubbleSortEndHour = " + BubbleSortEndHour);
    					}
    					conversionFactor = 60;
    				}
    				add = false;
    			}
    			else add = true;
    			//else;//do nothing we cannot borrow from it
    			//System.out.println("conversionFactor = " + conversionFactor);
    			//System.out.println("borrowingReturnIndex = " + borrowingReturnIndex);
    		}
    		
    		//store the magnitude of the difference here in the variables
    		//provided that we are done and not borrowing still
    		if (borrowing == false)
    		{
    			if (borrowingReturnIndex > -1)
    			{
    				//we need to do something here so we work backwards
    				if (i > borrowingReturnIndex) add = false;//works backwards
    				else add = true;//works forwards; controls loop (in/de)crementation
    			}
    			else
    			{
	    			//we are also free to advance the for loop once these values are stored
	    			if (i == 0) millidifference = difference;
	    			else if (i == 1) seconddifference = difference;
	    			else if (i == 2) minutedifference = difference;
	    			else hourdifference = difference;
	    			add = true;
	    			
	    			//System.out.println();
	    			//System.out.println("hourdifference = " + hourdifference);
	    			//System.out.println("minutedifference = " + minutedifference);
	    			//System.out.println("seconddifference = " + seconddifference);
	    			//System.out.println("milliifference = " + millidifference);
	    			//System.out.println("add = " + add);
	    			//System.out.println();
    			}
    		}
    		else
    		{
    			//made it to the end and can't borrow
    			if (i == 3)
    			{
    				//we need to work in reverse and let the program know that the result is negative
    				add = false;
    			}
    			//else;//not sure what to do here
    			
    			//System.out.println("add = " + add);
    		}
    		
    		//end of for loop code
    		if (add) i++;
    		else i--;
    	}//end of i for loop
    	
    	//generate the return the string here
    	if (swapAll) str += "-";
    	else str += " ";
    	
    	if (hourdifference < 10) str += "0" + hourdifference;
    	else str += hourdifference;
    	str += ":";
    	if (minutedifference < 10) str += "0" + minutedifference;
    	else str += minutedifference;
    	str += ":";
    	if (seconddifference < 10) str += "0" + seconddifference;
    	else str += seconddifference;
    	str += ".";
    	if (millidifference < 10) str += "00";
    	else if (millidifference < 100) str += "0";
    	//else;//do nothing
    	str += millidifference;
    	//System.out.println("str = " + str);
    	
    	return str;
    }
    
    public static long getSortCPUTime(boolean isInternal)
    {
    	//this will return the internal time difference in miliseconds
    	//for either sort
    	//the isInternal sort identifies the sorting type
    	if (isInternal) return internalEndTime - internalStartTime;
    	else return BubbleSortEndTime - BubbleSortStartTime;
    }
    
    
    //this helps the read file method it finds invalid characters and removes them then returns the new word
    private static String removeSpecialCharacterFromAWord(String word)
    {
    	String myChars = ", -:;.*!?_";//we are to ignore ,:;* -_!?". (etc.)
    	myChars += '"';
    	for (int i = 0; i < word.length(); i++)
    	{
    		for (int k = 0; k < myChars.length(); k++)
    		{
    			//System.out.println("k = " + k);
    			//System.out.println("len = " + word.length());
    			//System.out.print("word.charAt("+i+") = ");
    			//System.out.println(word.charAt(i));
    			if (myChars.charAt(k) == word.charAt(i))
    			{
    				if (word.charAt(i) == '-' && useDashAsSpace == true)
    				{
    					//go on either side of that to see if the word should be split into more
    					//if it should, I will insert a + and then return it as one, in the readFile
    					//I will remove all of + and add more words...
    					
						int startWordIndex = -1;
    					for (int in = i - 1; in > -1; in--)
    					{
    						if (Character.isLetter(word.charAt(in)))
    						{
    							startWordIndex = in;
    							break;
    						}
    					}
    					int nextWordStartIndex = -1;
    					for (int in = i + 1; in < word.length(); in++)
    					{
    						if (Character.isLetter(word.charAt(in)))
    						{
    							nextWordStartIndex = in;
    							break;
    						}
    					}
    					
    					if (startWordIndex > -1 && nextWordStartIndex > -1)
    					{
    						word = word.substring(0, startWordIndex + 1) + specialDelimiter + word.substring(nextWordStartIndex);
    					}
    					else if (startWordIndex > -1 && nextWordStartIndex < 0)
    					{
    						word = word.substring(0, startWordIndex + 1);
    					}
    					else if (startWordIndex < 0 && nextWordStartIndex > -1)
    					{
    						word = word.substring(nextWordStartIndex);
    					}
    					else word = "";
    				}
    				else
    				{
	    				if (i + 1 < word.length())
	    				{
	    					word = word.substring(0, i) + word.substring(i + 1);
	    				}
	    				else
	    				{
	    					word = word.substring(0, i);
	    				}
    				}
    				i = -1;
    				//System.out.println("REMOVED A CHAR");
    				break;
    			}
    			//else;//do nothing
    		}//end of k for loop
    	}//end of i for loop
    	return word;
    }
    
    //this reads the file and the data into the program
    public static void readFile(String fileName)
    {
    	Scanner fileScan = null;
    	try
    	{
    		fileScan = new Scanner(new File(fileName));
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    		return;
    	}
    	
    	//read the file here and store the words inside an ArrayList
    	//the scanner.next() will be helpful
    	//also, we are to ignore ,:;* -_!?". (etc.)
    	//do not ignore duplicates
    	int i = 0;
    	while(fileScan.hasNext())
    	{
    		String word = fileScan.next();
    		word = removeSpecialCharacterFromAWord(word);
    		word = word.toLowerCase();
    		
    		if (useDashAsSpace)
    		{
	    		while (word.indexOf(specialDelimiter) > -1)
	    		{
	    			if (word.indexOf(specialDelimiter) > -1)
		    		{
		    			String worda = word.substring(0, word.indexOf(specialDelimiter));
		    			//System.out.println("worda = " + worda);
		    			
		    			//adds the split words into the list
		    			if (worda.length() > 0)
		    			{
		    				//go through the entire list of words and see if there is a copy of this found
		    				boolean found = false;
		    				int foundIndex = -1;
		    				for (int k = 0; k < i; k++)
		    				{
		    					if (words.get(k).equals(worda))
		    					{
		    						found = true;
		    						foundIndex = k;
		    						break;
		    					}
		    				}
		    				
		    				if (!found)
		    				{
		    					words.add(i, worda);
		    					wcounts.add(i, 1);
		    					i++;
		    				}
		    				else
		    				{
		    					wcounts.set(foundIndex, wcounts.get(foundIndex) + 1);
		    				}	
		    			}
		    			//else;//do nothing
		    			
		    			word = word.substring(word.indexOf(specialDelimiter) + 1);
		    			//System.out.println("wordb = " + word);
		    			//System.out.println();
		    		}
		    		else break;
	    		}//end of inner while loop
    		}
    		//else;//do nothing
    		
    		//add to the arraylist here
    		//either this adds the word directly to the list OR
    		//it adds the last one to the list after the inner loop ran
    		if (word.length() > 0)//to get rid of blank words
    		{
	    		//go through the entire list of words and see if there is a copy of this found
				boolean found = false;
				int foundIndex = -1;
				for (int k = 0; k < i; k++)
				{
					if (words.get(k).equals(word))
					{
						found = true;
						foundIndex = k;
						break;
					}
				}
				
				if (!found)
				{
					words.add(i, word);
	    			wcounts.add(i, 1);
	    			i++;
				}
				else
				{
					wcounts.set(foundIndex, wcounts.get(foundIndex) + 1);
				}
    		}
    	}//end of while loop
    	
    	//done reading the file so close it
    	fileScan.close();
    	
    	//make the copies of the ArrayList here and then fill them up
    	//these are the lists that will be sorted
    	wordsarrayforbubble = new String[words.size()];
    	internalWords = new String[words.size()];
    	for (i = 0; i < words.size(); i++)
    	{
    		wordsarrayforbubble[i] = words.get(i);
    		internalWords[i] = words.get(i);
    	}
    }
    
    
    //begin sorting methods here
    public static void internalArraySort()
    {
    	startStopSortClock(true, true, true);//start the internal CPU clock here
    	startStopSortClock(true, true, false);//start the internal Wall clock here
    	
    	//do the sort here
    	Arrays.sort(internalWords);
    	
    	startStopSortClock(false, true, true);//stop the internal CPU clock here
    	startStopSortClock(false, true, false);//stop the internal Wall clock here
    }
    
    
    //this is the helper method for the BubbleSort after I wrote this, my code was an n power efficient
    public static boolean isInAlphabeticalOrder(String a, String b)
    {
    	//assuming string a is before b
    	//first check to see if a is inside of b (b.indexOf(a) will be > -1)
    	//if b is inside of a this is false
    	//System.out.println("a = " + a);
    	//System.out.println("b = " + b);
    	
    	if (a.equals(b) || b.equals(a)) return true;
    	//else;//do nothing we need to check the strings
    	
    	//if b is uppercase and a is not, then true; uppercase check is not needed
    	//if they are both the same case we need to check the letters
    	
    	//if (Character.isUpperCase(a.charAt(0)) != Character.isUpperCase(b.charAt(0)))
    	//{
    		//System.out.println("NOT THE SAME CASE");
    		//System.out.println("(Character.isUpperCase(a.charAt(0))) = " + (Character.isUpperCase(a.charAt(0))));
    		//return !(Character.isUpperCase(a.charAt(0)));
    	//}
    	//else
    	//{
    		//they are both the same case
    		int size = -1;
    		if (a.length() < b.length()) size = a.length();
    		else size = b.length();
    		for (int i = 0; i < size; i++)
    		{
    			int aletter = (int)(a.charAt(i));
    			int bletter = (int)(b.charAt(i));
    			//System.out.println("aletter = " + aletter);
    			//System.out.println("bletter = " + bletter);
    			if (aletter > bletter) return false;
    			else if (aletter < bletter) return true;
    			//else;//do nothing
    		}
    		
    		//System.out.println("aLen = " + a.length());
    		//System.out.println("bLen = " + b.length());
    		
    		if (b.length() > a.length()) return true;
    		else if (a.length() > b.length()) return false;
    		else return true;
    	//}
    }
    
    //this is the BubbleSort and uses the helper method
    public static String[] BubbleSort(String[] array)
    {
    	//find the greatest value and then move it up the list
    	//find this as we go, least to greatest
    	//lowercase before uppercase letters
    	
    	//if we have an uppercase letter and a lowercase letter next to each other,
    	//the uppercase swaps with the lowercase one (assuming that they are in that order)
    	//if we have two letters of the same case next to each other
    	//then we get their ascii code number by conversion to an integer
    	//then compare the values, if the one is bigger it is higher than the other
    	//therefore it gets swapped with the other one
    	
    	//start the loop and get the case of the first word and the next words
    	//after we get the case check to see if they are the same
    	//if they are the same case: check to see if the first letter comes before the other
    	//in the alphabet, if they do perform a swap; else check the next letters to see if
    	//they come before each other ... if they don't leave them...
    	//if one word contains the other but one is longer, that one is higher in the alphabet (for a swap)
    	//if the first letters are not of the same case, then upper must be after lower (swap accordingly)
    	
    	for (int n = 0; n < array.length; n++)
    	{
    		for (int k = array.length - 1; k > -1; k--)
    		{
    			if (n == k) continue;
    			//else;//do nothing
    			
    			//System.out.println("n = " + n);
    			//System.out.println("k = " + k);
    			//System.out.println("array[" + n + "] = " + array[n]);
    			//System.out.println("array[" + k + "] = " + array[k]);
    			boolean inorder = false;
    			if (n < k) inorder = isInAlphabeticalOrder(array[n], array[k]);
    			else if (k < n) inorder = isInAlphabeticalOrder(array[k], array[n]);
    			else inorder = true;
    			//System.out.println("inorder = " + inorder);
    			if (inorder);//do nothing
    			else
    			{
    				String temp = array[k];
					array[k] = array[n];
					array[n] = temp;
					
					int temp2 = wcounts.get(k);
					wcounts.set(k, wcounts.get(n));
					wcounts.set(n, temp2);
					
					//System.out.println("SWAPPED A AND B");
					//System.out.println("NEW array[" + n + "] = " + array[n]);
					//System.out.println("NEW array[" + k + "] = " + array[k]);
    			}
    		}//end of k for loop
    		//System.out.println("---------------------------------");
			//prints the array to show progress
			//for (int p = 0; p < array.length; p++)
	    	//{
	    	//	System.out.println("array[" + p + "] = "+ array[p]);
	    	//}
	    	//System.out.println("---------------------------------");
    	}//end of i for loop
    	
    	//prints the array before returning after sorting
    	//for (int p = 0; p < array.length; p++) System.out.println("array[" + p + "] = "+ array[p]);
    	
    	return array;
    	
    	/*wrong, I tried this the first time I really messed up
    	for (int n = 0; n < array.length; n++)
    	{
	    	for (int i = 0; i < array.length; i++)
	    	{
	    		//if (restartTheLoop)
	    		//{
	    		//	i = 0;
	    		//	restartTheLoop = false;
	    		//}
	    		
	    		System.out.println("array[" + i + "] = " + array[i]);
		    	boolean upper = Character.isUpperCase(array[i].charAt(0));
		    	boolean nextUpper = false;
		    	boolean setNextCase = false;
		    	for (int k = 0; k < array.length; k++)
		    	{	
			    	//if (restartTheLoop)
			    	//{
			    	//	i = 0;
			    	//	break;
			    	//}
			    	//else;//do nothing
			    	
			    	if (k == i) continue;
			    	//else;//do nothing
			    	
			    	System.out.println("k = " + k);
			    	System.out.println("i = " + i);
			    	
			    	System.out.println("array[" + k + "] = " + array[k]);
			    	if (k < array.length)
			    	{
			    		nextUpper = Character.isUpperCase(array[k].charAt(0));
			    		setNextCase = true;
			    	}
			    	System.out.println("upper = " + upper);
			    	System.out.println("setNextCase = " + setNextCase);
			    	System.out.println("nextUpper = " + nextUpper);
			    	
			    	if ((upper != nextUpper) && (setNextCase == true))
			    	{
			    		//we know that one of them is upper case
			    		//make sure that this element gets moved the farthest
			    		//down the array
			    		
			    		if (upper && i > k);//do nothing
			    		else if (nextUpper && k > i);//do nothing
			    		else
			    		{
			    			//need to do a swap
			    			String temp = array[k];
							array[k] = array[i];
							array[i] = temp;
							System.out.println("\nSWAP 1\n");
							//restartTheLoop = true;
			    		}
			    	}
			    	else if ((upper == nextUpper) && (setNextCase == true))
			    	{
			    		//they are both the same case
			    		String cword = array[i];
			    		String nextWord = array[k];
			    		System.out.println("cword(i) = " + cword);
			    		System.out.println("nextWord(k) = " + nextWord);
			    		int size = -1;
			    		if (cword.length() < nextWord.length())
			    		{
			    			size = cword.length();
			    		}
			    		else size = nextWord.length();
			    		System.out.println("size = " + size);
			    		
			    		boolean same = true;
			    		for (int wi = 0; wi < size; wi++)
			    		{
				    		int oletter = (int)(Character.toLowerCase((array[k]).charAt(wi)));
				    		int letter = (int)(Character.toLowerCase((array[i]).charAt(wi)));
				    		System.out.println("oletter(k) = " + oletter);
				    		System.out.println("letter(i) = " + letter);
				    		//check to see if they are the same letter
				    		if (oletter == letter);//do nothing
				    		else
				    		{
				    			//we know at some point in the word, the letters are different
				    			//we know that they are also the same casing upper or lower
				    			//we know i and k;
				    			//we want to put them in alphabetical order
				    			//to do this a conditional swap must occur here
				    			//we don't always swap though...
				    			//the smaller letter is lower in the alphabet and the bigger
				    			//letter is higher; the numbers correspond as so.
				    			
				    			if (oletter < letter && k < i);//do nothing
				    			else if (letter < oletter && i < k);//do nothing
				    			else
				    			{
					    			String temp = array[k];
									array[k] = array[i];
									array[i] = temp;
					    			System.out.println("\nSWAP 2\n");
					    			//restartTheLoop = true;
				    			}
				    			
				    			same = false;
				    			break;
				    		}
				    		//else;//do nothing check the next one
			    		}//end of wi for loop
			    		
			    		if (same)
			    		{
			    			//compare the word lengths
			    			//if one is longer than the other, that one is higher
			    			//else do nothing
			    			if (cword.length() > nextWord.length())
			    			{
			    				if (k > i)
			    				{
				    				//need to swap
				    				String temp = array[k];
									array[k] = array[i];
									array[i] = temp;
									System.out.println("\nSWAP 3\n");
									//restartTheLoop = true;
			    				}
			    				//else;//do nothing
			    			}
			    			//else;//do nothing
			    		}
			    		//else;//do nothing
			    	}
			    	//else;//do nothing
			    	System.out.println("NEW array[" + k + "] = " + array[k]);
			    	System.out.println("NEW array[" + i + "] = " + array[i]);
			    	System.out.println();
		    	}
		    	System.out.println("NEW array[" + i + "] = " + array[i]);
			    System.out.println("---------------------------------");
				for (int p = 0; p < array.length; p++)
		    	{
		    		System.out.println("array[" + p + "] = "+ array[p]);
		    	}
		    	System.out.println("---------------------------------");
	    	}
    	}
    	//*/
    }
    
    //this starts the clocks and calls BubbleSort
    public static void doBubbleSortWithClocks()
    {
    	//start, isInternal, isCPU
    	startStopSortClock(true, false, true);//start the internal CPU clock here
    	startStopSortClock(true, false, false);//start the internal Wall clock here
    	
    	//do the sort here
    	wordsarrayforbubble = BubbleSort(wordsarrayforbubble);
    	
    	startStopSortClock(false, false, true);//stop the internal CPU clock here
    	startStopSortClock(false, false, false);//stop the internal Wall clock here
    }
    
    //the out put file is in the format: word    count[new line]
    //this will allign the word counts with each other...
    public static void createOutPutFile()
    {
    	String outFileName = "HW5.txt";
    	//it will be in the format:      word    count[new line]
    	BufferedWriter bw = null;
    	try
    	{
    		File file = new File(outFileName);
    		
    		//if it doesn't exist, create it
    		if (!file.exists())
    		{
    			file.createNewFile();
    		}
    		
    		bw = new BufferedWriter(new FileWriter(file));
    		
    		//do the actual writing here
    		int maxLen = 0;
	    	for (int i = 0; i < wordsarrayforbubble.length; i++)
	    	{
	    		int len = wordsarrayforbubble[i].length();
	    		if (len > maxLen)
	    		{
	    			maxLen = len;
	    		}
	    	}
	    	for (int i = 0; i < wordsarrayforbubble.length; i++)
    		{
    			String str = wordsarrayforbubble[i];
    			int len = str.length();
    			if (len < maxLen)
	    		{
	    			for (int k = 0; k < maxLen - len; k++) str += " ";
	    		}
	    		str += wcounts.get(i);
    			
    			//do the actual writing here
    			bw.write(str);
    			bw.newLine();
    		}
    		//bw.write() does the writing of the contents like a System.out.print("stuff");
    		//bw.newLine() makes a new line there
    		
    		//always close the file when done writing to it
    		bw.close();
    	}
    	catch(Exception e)
    	{
    		e.printStackTrace();
    	}
    }
    
    public static void main(String[] args)
    {
    	//startStopSortClock(true, true, false);
    	String fileName = getFileNameFromUser();
    	//System.out.println("Filename: " + fileName);
    	readFile(fileName);
    	System.out.println("Number of words: " + words.size());
    	
    	//calls Bubble sort here
    	//start the clocks first
    	//then call it
    	//stop the clocks
    	doBubbleSortWithClocks();
    	
    	//calls Internal sort here
    	//start the clocks first
    	//then call it
    	//stop the clocks after
    	internalArraySort();
    	
    	//internalEndHour = 0;
    	//internalEndMinute = 0;
    	//internalEndSecond = 0;
    	//internalEndMillisecond = 3;
    	
    	//internalStartHour = 0;
    	//internalStartMinute = 0;
    	//internalStartSecond = 0;
    	//internalStartMillisecond = 4;
    	
    	//  00:00:00.003
    	// -00:00:00.004
    	//=-00:00:00.001
    	
    	//  12:19:00.300
	    // -11:20:04.400
	    // =00:58:55.900
    	
    	//internalEndHour = 12;
    	//internalEndMinute = 19;
    	//internalEndSecond = 0;
    	//internalEndMillisecond = 300;
    	
    	//internalStartHour = 11;
    	//internalStartMinute = 20;
    	//internalStartSecond = 4;
    	//internalStartMillisecond = 400;
    	
    	///*
    	//do the printing here
    	int maxLen = 0;
    	for (int i = 0; i < wordsarrayforbubble.length; i++)
    	{
    		int len = wordsarrayforbubble[i].length();
    		if (len > maxLen)
    		{
    			maxLen = len;
    		}
    	}
    	//prints the list of words out to the screen
    	for (int i = 0; i < wordsarrayforbubble.length; i++)
    	{
    		System.out.print(wordsarrayforbubble[i]);
    		int len = wordsarrayforbubble[i].length();
    		if (len < maxLen)
    		{
    			for (int k = 0; k < maxLen - len; k++) System.out.print(" ");
    		}
    		System.out.println(" " + wcounts.get(i));
    	}
    	System.out.println();
    	//*/
    	
    	System.out.println("Wall clock:");
    	//print the time here for my Bubble sort
    	//print the time here for the Internal sort
    	//Create a new Calendar and then use the Calendar.MINUTE,HOUR,SECOND,etc.
    	//the computeTime() in miliseconds will be really helpful;
    	//we want to find the difference in hours, minutes, and seconds
    	//startStopSortClock(false, true, false);
    	
    	System.out.println("Bubble sort:     " + getSortWallClockTime(false));
    	System.out.println("Internal sort:   " + getSortWallClockTime(true));
    	System.out.println("\nCPU clock:");
    	
    	//print the time here for my Bubble sort
    	//print the time here for the Internal sort
    	//http://memorynotfound.com/calculating-elapsed-time-java/
    	//long startTime = System.nanoTime();
    	//long endTime = System.nanoTime();
    	//long elapsedTime = end - start;
    	
    	System.out.println("Bubble sort:      " + getSortCPUTime(false));
    	System.out.println("Internal sort:    " + getSortCPUTime(true));
    	
    	createOutPutFile();
    }
}