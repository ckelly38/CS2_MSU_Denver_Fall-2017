/**
 * @(#)HW2.java
 * 
 * BEGIN HW 3 LOG HERE:
 * 
 * Dates:
 * 8-31-2017
 * 3:39 PM - 4:06 PM + 4:24 PM - 5:39 PM + 7:30 - 9:33 PM
 * Today, I set up the data file, set up the user interface, and made skeliton classes
 * for all of the files. I also set up the Boarders class. I also started the
 * readFile() method, but I haven't finished it yet.
 *
 * 9-1-2017
 * 10:00 AM - 10:56 AM + 3:22 - 3:34 PM + 6:42 PM - 7:50 PM + 8:34 PM - 8:50 PM
 * Today, I completed the readFile() method, built a to string and get boarder country
 * name list as a string methods. I wrote methods necessary for printing everything, but
 * it seems that my data file that I read in does NOT have any countries with a population
 * greater than 100 million people. I will verify the integrity of the data file by checking
 * it against the source tomorrow; otherwise, I am all done.
 *
 * 9-4-2017
 * 9:59 AM - 10:19 AM
 * It is not 100 Million, but 35 Million.
 *----------------------------------------------
 * HW 2 LOG BEGINS NOW, (I AM GOING TO MAKE THIS WITHOUT ARRAYLISTS ONLY TO SHOW I KNOW
 * HOW TO WIRTE THIS CLASS)
 * 
 * 9-7-2017
 * 3:10 PM - 5:40 PM
 * Today, I made a file called HW3.java only use arrays instead of ArrayLists or LinkedLists.
 * I had to modify several methods in HW3, but only a couple of methods in the Countries.java.
 * I also made it so the user could enter in a file name or that it would use the data file
 * that the program provides called countries.txt. I did not modify the Boarders.java file.
 * The HW3 really needs to be HW2 and HW2 really is HW3. I will rename the files accordingly.
 * I also caught and corrected a bug in the UI that I thought I had solved, but that I did not
 * test to see if I did--as a result I did not, and turned in a program that could be crashed by
 * entering a letter in for a number when prompting the user for action. I corrected this in both
 * versions of the program. 
 *
 * This is a class that creates two different types of lists.
 * An array and a linked list.
 *
 * @author Chris Kelly
 * @version 1.00 8-31-2017
 */

import java.util.Scanner;
import java.util.InputMismatchException;
//import java.util.LinkedList;
//import java.util.ArrayList;
import java.io.File;
import java.io.FileNotFoundException;
public class HW2
{

    public HW2()
    {
    	
    }
    
    final static int minPopulationInLists = 35000000;
    
    //private static LinkedList<Countries> countryLL;
    private static Countries[] countryArray;
    private static Countries myGermany = new Countries();
    private static Countries[] germanBCList;
    //private static ArrayList<Countries> countriesWithMoreThanNMPeople = new ArrayList<Countries>();
    //private static ArrayList<Countries> germanBCListWithMoreThanNMPeople = new ArrayList<Countries>();
    
    //this method gets the file to be read in by the user as well as its path
    //if the user does not enter a valid file name, the default "countries.txt"
    //(where my data is will be used)
    public static String getFileName()
    {
    	String fileName = "";
    	System.out.print("Enter a vaild file name: ");
    	Scanner scanner = new Scanner(System.in);
    	fileName = scanner.nextLine();
    	//System.out.println("fileName = " + fileName);
    	try
    	{
    		Scanner file = new Scanner(new File(fileName));
    		file.close();
    	}
    	catch(Exception e)
    	{
    		//do nothing
    		fileName = "countries.txt";//by default
    	}
    	//System.out.println("fileName = " + fileName);
    	return fileName;
    }
    
    //this method imports the data and stores it inside the array and the LinkedList
    public static void readFile()
    {
    	//first create the linked list, then store the size of it, then generate and copy everything into the array
    	String fileName = getFileName();
    	try
    	{
    		//we need to get the number of lines here
    		int arraySize = 0;
    		Scanner fileScan = new Scanner(new File(fileName));
    		while(fileScan.hasNext())
    		{
    			String line = fileScan.nextLine();
    			arraySize++;
    		}
    		//System.out.println("arraySize = " + arraySize);
    		fileScan.close();
    		countryArray = new Countries[arraySize];
    		
    		//get boarder country count for all countries
    		int[] mbccounts = new int[arraySize];
    		fileScan = new Scanner(new File(fileName));
    		int mIndex = 0;
    		while (fileScan.hasNext())
    		{
    			if (mIndex < arraySize);//do nothing
    			else break;
    			
    			int count = 0;
    			String line = fileScan.nextLine();
    			
    			//find the {};
    			//fmt {countryName, name2, etc.};
    			line = line.substring(line.indexOf("{") + 1, line.indexOf("};"));
    			//System.out.println("NEW line = " + line);
    			
    			for (int i = 0; i < line.length(); i++)
    			{
    				if (line.substring(i, i + 1).equals(","))
    				{
    					if (count == 0) count = 1;
    					count++;
    				}
    				else;//do nothing
    			}//end of i for loop
    			//System.out.println("count = " + count);
    			
    			mbccounts[mIndex] = count;
    			mIndex++;
    		}//end of while loop
    		fileScan.close();
    		
    		Scanner mfileScanner = new Scanner(new File(fileName));
    		int listIndex = 0;
    		while(mfileScanner.hasNext())
	    	{
	    		String line = mfileScanner.nextLine();
	    		//System.out.println("line: " + line);
	    		//format: countryName: lattitude N-S, longitude E-W, countryArea, countryPopulation, countryGDB, countryYear, {country_name, country_name, etc.};
	    		
	    		Countries myCountry = new Countries();
	    		//find the : then the first comma, then the second comma, etc, until the {} then the;
	    		int startIndex = line.indexOf(":");
	    		myCountry.setCountryName(line.substring(0, startIndex));
	    		//System.out.println(myCountry.getCountryName());
	    		
	    		Countries[] bcs = new Countries[mbccounts[listIndex]];
	    		int bcsIndex = 0;
	    		
	    		int item = 1;//1str,2str,3int,4int,5double,6year
	    		boolean foundStartOfBoarderCountriesList = false;
	    		for (int i = startIndex; i < line.length() && i > -1; i++)
	    		{
	    			//if (bcsIndex < bcs.length);//do nothing
	    			//else break;
	    			
	    			//System.out.println("i = " + i);
	    			//System.out.println(line.substring(i, i + 1));
	    			if (line.substring(i, i + 1).equals(" ") || line.substring(i, i + 1).equals(":") ||
	    				line.substring(i, i + 1).equals(",") || line.substring(i, i + 1).equals(";") ||
	    				line.substring(i, i + 1).equals("}"))
	    			{
	    				//System.out.println("skipped something");
	    				continue;
	    			}
	    			else if (line.substring(i, i + 1).equals("{"))
	    			{
	    				//System.out.println("skipped something");
	    				foundStartOfBoarderCountriesList = true;
	    				continue;
	    			}
	    			//else;//do nothing
	    			
	    			boolean foundNextComma = false;//assuming there is one; will be false if it can't find one
	    			int nextCommaIndex = -1;
	    			boolean findForRan = false;
	    			boolean foundEndOfBCList = false;
	    			for (int k = i + 1; k < line.length() && k > -1; k++)
	    			{
	    				//System.out.println(line.substring(k, k + 1));
	    				if (k == i + 1) findForRan = true;
	    				//else;//do nothing
	    				
	    				if (k + 1 < line.length() && line.substring(k, k + 1).equals(","))
	    				{
	    					foundNextComma = true;
	    					nextCommaIndex = k;
	    					break;
	    				}
	    				else if (k + 1 < line.length() && line.substring(k, k + 1).equals("}"))
	    				{
	    					foundEndOfBCList = true;
	    					nextCommaIndex = k;
	    					break;
	    				}
	    				//else;//do nothing
	    			}//end of k for loop
	    			
	    			//System.out.println("foundNextComma = " + foundNextComma);
	    			//System.out.println("nextCommaIndex = " + nextCommaIndex);
	    			//System.out.println("foundEndOfBCList = " + foundEndOfBCList);
	    			//System.out.println("foundStartOfBoarderCountriesList = " + foundStartOfBoarderCountriesList);
	    			if (foundNextComma == true || foundEndOfBCList == true)
	    			{
	    				String myStr = line.substring(i, nextCommaIndex);
	    				//System.out.println(myStr);
	    				//System.out.println("item = " + item);
	    				if (item == 1) myCountry.setLattitude(myStr);
	    				else if (item == 2) myCountry.setLongitude(myStr);
	    				else if (item == 3 || item == 4 || item == 6)
	    				{
	    					int myValue = Integer.parseInt(myStr);
	    					if (item == 3) myCountry.setCountryArea(myValue);
	    					else if (item == 4) myCountry.setCountryPopulation(myValue);
	    					else myCountry.setCountryYear(myValue);
	    				}
	    				else if (item == 5)
	    				{
	    					myCountry.setCountryGDP(Double.parseDouble(myStr));
	    				}
	    				else if (item < 16 && item > 6)
	    				{
	    					Countries mbc = new Countries();
	    					mbc.setCountryName(myStr);
	    					//myCountry.addCountryToBoarderList(mbc);
	    					bcs[bcsIndex] = mbc;
	    					bcsIndex++;
	    				}
	    				//else;//do nothing
	    				
	    				if (item > 0 && item < 16) i = nextCommaIndex;
	    				//else;//do nothing
	    				//we need to start setting boarder country code here
	    				
	    				item++;
	    			}
	    			//else;//do nothing
	    		}//end of i for loop
	    		
	    		//add the boarder countries array here to the country
	    		myCountry.setBoarderCountries(bcs);
	    		
	    		//add the elements to a list
	    		//countryLL.add(listIndex, myCountry);
	    		countryArray[listIndex] = myCountry;
	    		
	    		listIndex++;
	    	}//end of while loop
    	}
    	catch(FileNotFoundException e)
    	{
    		e.printStackTrace();
    	}
    }
    
    private static void printListOfCountriesBoarder(Countries myC)
    {
    	System.out.println(myC.getBoarderCountryArrayStr());
    }
    
    private static Countries[] generateArrayBothGermanAndNMillionPeople()
    {
    	int marraysize = 0;
    	for (int i = 0; i < germanBCList.length; i++)
    	{
    		Countries myC = (Countries)(germanBCList[i]);
    		//System.out.println(myC);
    		//System.out.println(myC.getCountryPopulation());
    		if (myC.getCountryPopulation() > minPopulationInLists)
    		{
    			//germanBCListWithMoreThanNMPeople.add(myC);
    			marraysize++;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	//System.out.println("marraysize = " + marraysize);
    	Countries[] both = new Countries[marraysize];
    	
    	int in = 0;
    	for (int i = 0; i < countryArray.length; i++)
    	{
    		if (in < marraysize);//do nothing
    		else break;
    		
    		Countries myC = (Countries)(germanBCList[i]);
    		//System.out.println(myC);
    		//System.out.println(myC.getCountryPopulation());
    		if (myC.getCountryPopulation() > minPopulationInLists)
    		{
    			//germanBCListWithMoreThanNMPeople.add(myC);
    			both[in] = myC;
    			in++;
    		}
    		//else;//do nothing
    	}//end of i for loop
    	
    	return both;
    }
    
    private static Countries[] generateArrayNMillionPeople()
    {
    	int marraysize = 0;
    	for (int i = 0; i < countryArray.length; i++)
    	{
    		Countries mc = (Countries)(countryArray[i]);
    		//System.out.println(mc);
    		if (mc.getCountryPopulation() > minPopulationInLists)
    		{
    			//countriesWithMoreThanNMPeople.add(mc);
    			marraysize++;
    		}
    		//else;//do nothing
    	}
    	//System.out.println("marraysize = " + marraysize);
    	Countries[] npeoplearray = new Countries[marraysize];
    	
    	int in = 0;
    	for (int i = 0; i < countryArray.length; i++)
    	{
    		if (in < marraysize);//do nothing
    		else break;
    		
    		Countries mc = (Countries)(countryArray[i]);
    		//System.out.println(mc);
    		if (mc.getCountryPopulation() > minPopulationInLists)
    		{
    			//countriesWithMoreThanNMPeople.add(mc);
    			npeoplearray[in] = mc;
    			in++;
    		}
    		//else;//do nothing
    	}
    	return npeoplearray;
    }
    
    /*
    private static ArrayList<Countries> generateArrayListBothGermanAndNMillionPeople()
    {
    	//System.out.println("germanBCList.length = " + germanBCList.length);
    	for (int i = 0; i < germanBCList.length; i++)
    	{
    		Countries myC = (Countries)(germanBCList[i]);
    		//System.out.println(myC);
    		//System.out.println(myC.getCountryPopulation());
    		if (myC.getCountryPopulation() > minPopulationInLists)
    		{
    			germanBCListWithMoreThanNMPeople.add(myC);
    		}
    		//else;//do nothing
    	}//end of i for loop
    	return germanBCListWithMoreThanNMPeople;
    }
    public static ArrayList<Countries> generateArrayListNMillionPeople()
    {
    	for (int i = 0; i < countryArray.length; i++)
    	{
    		Countries mc = (Countries)(countryArray[i]);
    		//System.out.println(mc);
    		if (mc.getCountryPopulation() > minPopulationInLists)
    		{
    			countriesWithMoreThanNMPeople.add(mc);
    		}
    		//else;//do nothing
    	}
    	return countriesWithMoreThanNMPeople;
    }
    //*/
    public static void main(String[] args)
    {
    	//countryLL = new LinkedList<Countries>();
    	Scanner scanner = new Scanner(System.in);
    	int userPreference = -1;
    	boolean readInDataYet = false;
    	while (userPreference == -1)
    	{
	    	while (userPreference == -1)
	    	{
	    		if (!readInDataYet) System.out.print("1. Import Data,");
	    		if (readInDataYet) System.out.println("\n2. Display a list of all of the " +
	    			"countries that boarder Germany,");
	    		if (readInDataYet) System.out.println("3. Display a list of all of the " +
	    			"countries that have population that is greater than " + (minPopulationInLists / 1000000.0) + " million,");
	    		if (readInDataYet) System.out.print("4. Display a list of all of the " +
	    			"countries that boarder Germany AND have a population greater than " + (minPopulationInLists / 1000000.0) + " million,");
	    		System.out.println(" and\n5. Quit the program.");
	    		
	    		try
	    		{
	    			userPreference = scanner.nextInt();
	    		}
	    		catch(InputMismatchException e)
	    		{
	    			System.out.println("ERROR: Invalid input!");
	    			userPreference = -1;//this provides that the loop will run again
	    			scanner.reset();//resets the scanner buffer
	    			scanner.next();//this allows it to move on from the error
	    			//if we did not reset and do the next here, we have an infinite loop
	    		}
	    		
	    		if (userPreference > 5 || userPreference < 1) userPreference = -1;
	    		else if (userPreference == 1 && readInDataYet) userPreference = -1;
	    		else if (readInDataYet == false && userPreference != 1 &&
	    			userPreference != 5) userPreference = -1;
	    		else break;
	    		System.out.println();
	    	}//end of while loop
    	
    		//use the option and reset unless you quit the program
    		if (userPreference == 1)
    		{
    			readFile();
    			readInDataYet = true;
    			
    			//initialize the array and copy over the data
    			/*
    			countryArray = new Countries[countryLL.size()];
    			for (int i = 0; i < countryLL.size(); i++)
    			{
    				countryArray[i] = countryLL.get(i);
    			}//*/
    			
    			//then check to see if we can find the boarder countries in a list
    			for (int i = 0; i < countryArray.length; i++)// + 1
    			{
    				//System.out.println("i = " + i);
    				Countries myCountry = null;
    				if (i < countryArray.length) myCountry = (Countries)(countryArray[i]);
    				//else;//do nothing
    				
    				Countries[] myBCs = myCountry.getBoarderCountries();
    				for (int k = 0; k < myBCs.length; k++)
    				{
    					//System.out.println("k = " + k);
    					Countries myBC = (Countries)(myBCs[k]);
    					//System.out.println(myBC);
    					//we need to try to find this country's name on the ArrayList
    					//and copy over additional data
    					for (int n = 0; n < countryArray.length; n++)
    					{
    						//System.out.println("n = " + n);
    						Countries mc = (Countries)(countryArray[n]);
    						//System.out.println(mc);
    						if (mc.getCountryName().equals(myBC.getCountryName()))
    						{
    							//System.out.println("old " + myBC.toString());
    							myBC = mc;
    							//System.out.println("new " + myBC.toString());
    							myBCs[k] = myBC;
    							//System.out.println();
    							break;
    						}
    						//else;//do nothing
    					}//end of n for loop
    				}//end of k for loop
    				
    				//update the array in the Countries object
    				myCountry.setBoarderCountries(myBCs);
    				
    			}//end of i for loop
    			
    			//set the value of Germany here
    			for (int i = 0; i < countryArray.length; i++)
    			{
    				Countries mc = (Countries)(countryArray[i]);
    				if (mc.getCountryName().equals("Germany"))
    				{
    					myGermany = mc;
    					break;
    				}
    				//else;//do nothing
    			}
    			//System.out.println(myGermany);
    			
    			germanBCList = myGermany.getBoarderCountries();
    		}
    		else if (userPreference == 2)
    		{
    			printListOfCountriesBoarder(myGermany);
    		}
    		else if (userPreference == 3)
    		{
    			Countries[] justNMillionPeople = generateArrayNMillionPeople();
    			for (int i = 0; i < justNMillionPeople.length; i++)
    			{
    				Countries mc = justNMillionPeople[i];
    				//System.out.println(mc);
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    			
    			/*
    			countriesWithMoreThanNMPeople = generateArrayListNMillionPeople();
    			//System.out.println("countriesWithMoreThanNMPeople_SIZE = " +
    			//	countriesWithMoreThanNMPeople.size());
    			for (int i = 0; i < countriesWithMoreThanNMPeople.size(); i++)
    			{
    				Countries mc = (Countries)(countriesWithMoreThanNMPeople.get(i));
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    			//*/
    		}
    		else if (userPreference == 4)
    		{
    			Countries[] GermanBCWithNMillionPeople = generateArrayBothGermanAndNMillionPeople();
    			for (int i = 0; i < GermanBCWithNMillionPeople.length; i++)
    			{
    				Countries mc = GermanBCWithNMillionPeople[i];
    				//System.out.println(mc);
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    			
    			/*
    			germanBCListWithMoreThanNMPeople = generateArrayListBothGermanAndNMillionPeople();
    			//System.out.println("germanBCListWithMoreThanNMPeople_SIZE = " +
    			//	germanBCListWithMoreThanNMPeople.size());
    			for (int i = 0; i < germanBCListWithMoreThanNMPeople.size(); i++)
    			{
    				Countries mc = (Countries)(germanBCListWithMoreThanNMPeople.get(i));
    				System.out.println(mc.getCountryName());
    			}//end of i for loop
    			//*/
    		}
    		//else;//do nothing quit the program
    		
    		//end of loop code
    		if (userPreference == 5);//do nothing
    		else userPreference = -1;
    	}//end of outer while loop
    }
}