/**
 * @(#)Borders.java
 * This class is used to tell if two countries boarder each other
 * 
 * @author Chris Kelly
 * @version 1.00 2017/8/31
 */


public class Boarders
{
    private Countries myCountry = null;
    private Countries myBoarderC = null;
    
    public Boarders()
    {
    	
    }
    
    public Boarders(Countries mine, Countries bc)
    {
    	myCountry = mine;
    	myBoarderC = bc;
    }
    
    public Countries getMyCountry()
    {
    	return myCountry;
    }
    public Countries getMyBC()
    {
    	return myBoarderC;
    }
    
    //a boarder is where two countries meet A and B, they are boarder countries
    public boolean boardersEachOther(Countries country1, Countries country2)
    {
    	Countries[] num1Array = country1.getBoarderCountries();
    	Countries[] num2Array = country2.getBoarderCountries();
    	boolean foundNum1OnNum2Boarders = false;//if one is true; the other must be true
    	for (int i = 0; i < num2Array.length; i++)
    	{
    		if (num2Array[i].getCountryName().equals(country1.getCountryName()))
    		{
    			foundNum1OnNum2Boarders = true;
    			break;
    		}
    	}//end of i for loop
    	//compare names and a map
    	return foundNum1OnNum2Boarders;
    }
}