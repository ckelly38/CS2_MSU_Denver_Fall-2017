/**
 * @(#)Countries.java
 *
 * @author Chris Kelly
 * @version 1.00 2017/8/31
 */

import java.util.ArrayList;
public class Countries
{
    
    private String countryName = "";
    private String lattitude = "";
    private String longitude = "";
    private int countryArea = 0;
    private int countryPopulation = 0;
    private double countryGDP = 0.0;
    private int countryYear = 0;
    private ArrayList<Countries> myBoarderCountries = new ArrayList<Countries>();
    
    public Countries()
    {
    	countryName = "";
    	lattitude = "";
    	longitude = "";
    	countryArea = 0;
    	countryPopulation = 0;
    	countryGDP = 0.0;
    	countryYear = 0;
    }
    
    public void setCountryName(String name)
    {
    	countryName = name;
    }
    public String getCountryName()
    {
    	return countryName;
    }
    public String getLattitude()
    {
    	return lattitude;
    }
    public void setLattitude(String value)
    {
    	lattitude = value;
    }
    public String getLongitude()
    {
    	return longitude;
    }
    public void setLongitude(String value)
    {
    	longitude = value;
    }
    public int getCountryArea()
    {
    	return countryArea;
    }
    public void setCountryArea(int value)
    {
    	countryArea = value;
    }
    public int getCountryPopulation()
    {
    	return countryPopulation;
    }
    public void setCountryPopulation(int value)
    {
    	countryPopulation = value;
    }
    public int getCountryYear()
    {
    	return countryYear;
    }
    public void setCountryYear(int value)
    {
    	countryYear = value;
    }
    public double getCountryGDP()
    {
    	return countryGDP;
    }
    public void setCountryGDP(double value)
    {
    	countryGDP = value;
    }
    
    public void addCountryToBoarderList(Countries c)
    {
    	myBoarderCountries.add(c);
    }
    
    public Countries[] getBoarderCountries()
    {
    	//convert the arraylist to an array an return it
    	Countries[] boarderCountries = new Countries[myBoarderCountries.size()];
    	for (int i = 0; i < myBoarderCountries.size(); i++)
    	{
    		boarderCountries[i] = myBoarderCountries.get(i);
    	}
    	return boarderCountries;
    }
    
    public void setBoarderCountriesList(Countries[] myArray)
    {
    	for (int i = 0; i < myBoarderCountries.size(); i++)
    	{
    		myBoarderCountries.remove(i);
    	}
    	
    	for (int i = 0; i < myArray.length; i++)
    	{
    		myBoarderCountries.add(i, myArray[i]);
    	}
    	
    	//this searches for and removes duplicates if any are found
    	for (int i = 0; i < myBoarderCountries.size(); i++)
    	{
    		Countries myC = (Countries)(myBoarderCountries.get(i));
    		for (int k = i + 1; k < myBoarderCountries.size(); k++)
    		{
    			Countries myOC = (Countries)(myBoarderCountries.get(k));
    			if (myC.getCountryName().equals(myOC.getCountryName()))
    			{
    				myBoarderCountries.remove(k);
    			}
    			//else;//do nothing
    		}//end of k for loop
    	}//end of i for loop
    }
    
    public String getBoarderCountryListStr()
    {
    	String str = "{";
    	
    	Countries[] bcs = getBoarderCountries();
    	for (int i = 0; i < bcs.length; i++)
    	{
    		str += bcs[i].getCountryName();
    		if ((i + 1) < bcs.length) str += ", ";
    		//else;//do nothing
    	}//end of i for loop
    	
    	str += "}.";
    	return str;
    }
    
    public void printBoarderCountryListStr()
    {
    	System.out.println(getBoarderCountryListStr());
    }
    
    public String toString()
    {
    	String str = countryName + ": " + lattitude + " (lattitude), " +
    		longitude + " (longitude), " + countryArea + " (area), " +
    		countryPopulation + " (population), " + countryGDP + " (GDP), " +
    		countryYear + " (year), " + getBoarderCountryListStr();
    	
    	return str;
    }
}