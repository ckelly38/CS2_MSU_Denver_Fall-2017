/**
 * @(#)myArrayList.java
 * 
 * Chris Kelly
 * 10-14-2017
 * 1:45 PM - 5 PM + 5:45 - 6:16 PM
 * This is an array that can be of any size.
 * 
 * @author 
 * @version 1.00 2017/10/14
 */

import java.util.Arrays;
public class myArrayList<T> {

    private int size = 0;
    private int capacity = 10;
    private int maxCapacity = 10;
    private boolean enforceMaxCapacity = false;
    private boolean alwaysEnforcingMaxCapacity = false;
    private int growthFactor = 2;
    private Object[] myArray = null;
    
    //constructors for the array list
    public myArrayList()
    {
    	alwaysEnforcingMaxCapacity = false;
    	enforceMaxCapacity = false;
    	size = 0;
    	capacity = 10;
    	maxCapacity = capacity;
    	myArray = new Object[capacity];
    	//for (int i = 0; i < capacity; i++) myArray[i] = 0;
    }
    public myArrayList(T[] arr)
    {
    	alwaysEnforcingMaxCapacity = false;
    	enforceMaxCapacity = false;
    	size = 0;
    	capacity = 10;
    	if (arr.length > 0)
    	{
    		setCapacity(arr.length * growthFactor);
    		myArray = new Object[capacity];
    		for (int i = 0; i < arr.length; i++) add(arr[i]);
    	}
    	else
    	{
    		myArray = new Object[capacity];
    		//for (int i = 0; i < capacity; i++) myArray[i] = 0;
    	}
    	maxCapacity = capacity;
    }
    public myArrayList(T[] arr, int maxCapacityValue)
    {
    	enforceMaxCapacity = true;
    	alwaysEnforcingMaxCapacity = false;
    	size = 0;
    	capacity = 10;
    	maxCapacity = maxCapacityValue;
    	if (arr.length > 0)
    	{
    		if (arr.length == maxCapacityValue &&
    			(alwaysEnforce == true || enforceMaxCapacity == true))
    		{
    			setCapacity(arr.length);
    		}
    		else if ((arr.length * growthFactor < maxCapacityValue ||
    			arr.length * growthFactor == maxCapacityValue) &&
    			(alwaysEnforce == true || enforceMaxCapacity == true))
    		{
    			setCapacity(arr.length * growthFactor);
    		}
    		else setCapacity(arr.length);
    		
    		myArray = new Object[capacity];
    		for (int i = 0; i < arr.length; i++) add(arr[i]);
    	}
    	else
    	{
    		myArray = new Object[capacity];
    	}
    }
    public myArrayList(T[] arr, int maxCapacityValue, boolean alwaysEnforce)
    {
    	enforceMaxCapacity = true;
    	maxCapacity = maxCapacityValue;
    	alwaysEnforcingMaxCapacity = alwaysEnforce;
    	size = 0;
    	capacity = 10;
    	if (arr.length > 0)
    	{
    		if (arr.length == maxCapacityValue &&
    			(alwaysEnforce == true || enforceMaxCapacity == true))
    		{
    			setCapacity(arr.length);
    		}
    		else if ((arr.length * growthFactor < maxCapacityValue ||
    			arr.length * growthFactor == maxCapacityValue) &&
    			(alwaysEnforce == true || enforceMaxCapacity == true))
    		{
    			setCapacity(arr.length * growthFactor);
    		}
    		else setCapacity(arr.length);
    		
    		myArray = new Object[capacity];
    		for (int i = 0; i < arr.length; i++) add(arr[i]);
    	}
    	else
    	{
    		myArray = new Object[capacity];
    	}
    }
    
    //gets the size
    public int size()
    {
    	return size;
    }
    
    //gets the element at that index
    public T get(int index)
    {
    	return (T)(myArray[index]);
    }
    
    //gets the max size currently
    //if there is no max capacity being enforced, then the capacity equals the max capacity;
    //if not the getters will change that to be true.
    public int capacity()
    {
    	if (maxCapacity < capacity) maxCapacity = capacity;
    	return capacity;
    }
    public int maxCapacity()
    {
    	if (maxCapacity < capacity()) maxCapacity = capacity();
    	return maxCapacity;
    }
    public boolean isEnforcingMaxCapacity()
    {
    	return enforceMaxCapacity;
    }
    public boolean isAlwaysEnforcingMaxCapacity()
    {
    	return alwaysEnforcingMaxCapacity;
    }
    //Note: once alwaysEnforcingMaxCapacity is true, you cannot change the max, and you cannot go over it
    //by default this is false, and the user must set it to true to have a permanent max. If you enforce
    // a capacity, then you cannot change the capacity until you stop enforcing it.
    public void setCapacity(int value)
    {
    	//System.out.println("inside set capacity with value = " + value);
    	if (value < 1)
    	{
    		throw new ArrayIndexOutOfBoundsException("Capacity size(" + value + ") must be greater than 0");
    	}
    	else if (value > maxCapacity() && isEnforcingMaxCapacity())
    	{
    		throw new ArrayIndexOutOfBoundsException("Capacity size(" + value + ") must be less than " +
    			"or equal to the maxCapacity (" + maxCapacity() + ")!");
    	}
    	else
    	{
    		capacity = value;
    		//System.out.println("size = " + size());
    		//System.out.println("capacity = " + capacity());
    		//System.out.println("maxCapacity = " + maxCapacity());
    		if (size() > capacity())
    		{
    			for (int i = size(); size() > capacity() && i > capacity() && i > -1; i--)
    			{
    				//System.out.println("inside the loop i = " + i);
    				remove(i);
    				i = size() - 1;
    				continue;
    			}
    			//System.out.println("new size = " + size());
    			//printList();
    		}
    	}
    }
    public void setAlwaysEnforcingMaxCapacity(boolean value)
    {
    	if (isAlwaysEnforcingMaxCapacity() == false)
    	{
    		alwaysEnforcingMaxCapacity = value;
    	}
    	//else;//do not set
    }
    public void setEnforcingMaxCapacity(boolean value)
    {
    	if (isAlwaysEnforcingMaxCapacity())
    	{
    		throw new ArrayIndexOutOfBoundsException("Error: You are enforcing a max capacity already set!");
    	}
    	else enforceMaxCapacity = value;
    }
    public void setMaxCapacity(int value)
    {
    	if (isEnforcingMaxCapacity())
    	{
    		throw new ArrayIndexOutOfBoundsException("Error: You are enforcing a max capacity already set!");
    	}
    	else
    	{
    		maxCapacity = value;
    		enforceMaxCapacity = true;
    		if (size() > maxCapacity)
    		{
    			for (int i = maxCapacity + 1; i < size(); i++)
    			{
    				remove(i);
    				i--;
    			}
    		}
    	}
    }
    
    //this adds an element to the end
    public void add(T element)
    {
    	//System.out.println("size = " + size());
    	//System.out.println("capacity = " + capacity());
    	//System.out.println("maxCapacity = " + maxCapacity());
    	//System.out.println("isEnforcingMaxCapacity = " + isEnforcingMaxCapacity());
    	if (size() == capacity() && !isEnforcingMaxCapacity())
    	{
    		setCapacity(capacity * growthFactor);
    		Object[] myArray2 = new Object[capacity()];
    		for (int i = 0; i < size(); i++) myArray2[i] = myArray[i];
    		myArray = myArray2;
    		//can't do this in C++ (we need to reinstantiate and copy over all of the elements)
    		//for (int i = size(); i < capacity(); i++) myArray[i] = 0;
    	}
    	else if (size() < capacity())
    	{
    		myArray[size()] = element;
    		size++;
    	}
    	else
    	{
    		throw new ArrayIndexOutOfBoundsException("Error: You have hit your capacity(" + capacity() +
    			") and you cannot increase it!");
    	}
    }
    //this adds an element to the middle, or beginning, but can also do the end...
    public void add(int index, T element)
    {
    	//System.out.println("index = " + index);
    	//System.out.println("size = " + size());
    	//System.out.println("capacity = " + capacity());
    	//System.out.println("maxCapacity = " + maxCapacity());
    	//System.out.println("isEnforcingMaxCapacity = " + isEnforcingMaxCapacity());
    	if (index < 0 || index > size())
    	{
    		throw new ArrayIndexOutOfBoundsException("The index(" + index + ") cannot be less than 0. NOR " +
    			"can it be greater than the size(" + size() + ")!");
    	}
    	else if (index == size()) add(element);
    	else
    	{
    		//we have an array that will be big enough
    		//start at the end, and copy over all of it to the next one over
    		for (int i = size() - 1; i > index && i > -1; i--) myArray[i + 1] = myArray[i];
    		size++;
    	}
    }
    
    //remove methods are here
    //this only removes what is at the index specified
    public void remove(int index)
    {
    	//we want to copy everything to one index below
    	for (int i = index + 1; i > 0 && i < size(); i++) myArray[i - 1] = myArray[i];
    	//if (index == size() - 1 || index == size()) myArray[index] = 0;
    	size--;
    }
    //this method removes an element or all instances of it
    Class T;
    public void remove(T element, boolean all)
    {
    	boolean found = false;
    	for (int i = 0; i < size(); i++)
    	{
    		if (i > 0) found = false;
    		//else;//do nothing
    		if (T == Integer.class || T == int.class ||
	    		T == Double.class || T == double.class ||
	    		T == Float.class || T == float.class ||
	    		T == Long.class || T == long.class ||
	    		T == Boolean.class || T == boolean.class)
	    	{
	    		if (myArray[i] == element)
	    		{
	    			found = true;
	    		}
	    	}
	    	else
	    	{
	    		if (((Object)(myArray[i])).equals((Object)(element)))
	    		{
	    			found = true;
	    		}
	    	}
	    	
	    	if (found == true)
	    	{
	    		//do the removal here
	    		remove(i);
	    		
	    		//advance the loop
	    		if (all)
	    		{
	    			i = -1;
	    			continue;
	    		}
	    	}
    	}//end of i for loop
    }
    //this clears the entire list and the enforcing of an absolute max
    public void clear(boolean resetMaxEnforcing)
    {
    	if (size() < 1)
    	{
    		if (resetMaxEnforcing)
    		{
    			alwaysEnforcingMaxCapacity = false;
    			enforceMaxCapacity = false;
    			capacity = 10;
    			maxCapacity = 10;
    		}
    		return;
    	}
    	else
    	{
    		remove(size() - 1);
    		clear(resetMaxEnforcing);
    	}
    }
    public void clear()
    {
    	clear(true);
    }
    public void removeAll()
    {
    	clear();
    }
    
    //this prints out the entire array (one element per line)
    public void printList()
    {
    	for(int i = 0; i < size(); i++)
    	{
    		System.out.print("myArray[" + i + "] = ");
    		System.out.println(myArray[i]);
    	}
    	System.out.println();
    }
}