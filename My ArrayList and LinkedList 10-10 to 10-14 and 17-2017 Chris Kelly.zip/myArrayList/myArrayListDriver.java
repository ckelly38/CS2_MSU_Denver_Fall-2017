/**
 * @(#)myArrayListDriver.java
 *
 *
 * @author 
 * @version 1.00 2017/10/14
 */


public class myArrayListDriver {

    public myArrayListDriver() {
    }
    
    public static void main(String[] args)
    {
    	myArrayList<Integer> mal = new myArrayList<Integer>();
    	System.out.println("size = " + mal.size());
    	System.out.println("capacity = " + mal.capacity());
    	for (int i = 0; i < 11; i++) mal.add(i);
    	System.out.println("new size = " + mal.size());
    	System.out.println("new capacity = " + mal.capacity());
    	System.out.println("max capacity = " + mal.maxCapacity());
    	System.out.println("enforcing max = " + mal.isEnforcingMaxCapacity());
    	System.out.println("always enforcing max = " + mal.isAlwaysEnforcingMaxCapacity());
    	mal.printList();
    	mal.remove(0);
    	mal.remove(5);
    	mal.remove(5, false);
    	mal.printList();
    	System.out.println("new size = " + mal.size());
    	mal.setCapacity(7);
    	mal.setMaxCapacity(7);
    	mal.setEnforcingMaxCapacity(true);
    	mal.setAlwaysEnforcingMaxCapacity(true);
    	mal.printList();
    	System.out.println("new size = " + mal.size());
    	
    	boolean exThrown = false;
    	try
    	{
    		mal.add(10);//this isn't legal
    		mal.add(20);
    		mal.add(30);
    		mal.add(40);
    		mal.add(50);
    		mal.add(60);
    	}
    	catch(ArrayIndexOutOfBoundsException e)
    	{
    		exThrown = true;
    	}
    	if (exThrown) System.out.println("Past Test!");
    	else System.out.println("Failed Test!");
    	
    	mal.printList();
    	System.out.println("new size = " + mal.size());
    	System.out.println("new capacity = " + mal.capacity());
    	System.out.println("max capacity = " + mal.maxCapacity());
    	System.out.println("enforcing max = " + mal.isEnforcingMaxCapacity());
    	System.out.println("always enforcing max = " + mal.isAlwaysEnforcingMaxCapacity());
    	
    	mal.clear();//will also reset enforcing max properties
    	mal.printList();
    	System.out.println("new size = " + mal.size());
    	System.out.println("new capacity = " + mal.capacity());
    	System.out.println("max capacity = " + mal.maxCapacity());
    	System.out.println("enforcing max = " + mal.isEnforcingMaxCapacity());
    	System.out.println("always enforcing max = " + mal.isAlwaysEnforcingMaxCapacity());
    }
}